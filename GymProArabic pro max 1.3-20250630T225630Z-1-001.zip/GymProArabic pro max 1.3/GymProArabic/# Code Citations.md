# Code Citations

## License: unknown
https://github.com/LouisvilleMakesGames/LouisvilleMakesGames.org-Source/tree/38ed36842cd318b9c59f14833d5e57f93c8320af/dest/donate.html

```
="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"
```


## License: unknown
https://github.com/cjzubiaga/cjzubiaga.github.io/tree/08d494baaa300c0689dbe20bb6740ef8a6dd8364/index.html

```
toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-
```


## License: unknown
https://github.com/ZeinabIqal/web1/tree/5fa91f08135b439a812435e17431b786562e3620/index.html

```
">
        <li class="nav-item"><a class="nav-link" href="#">الرئيسية</a></li>
        <li class="nav-item"><a class="nav-link"
```


## License: MIT
https://github.com/AirenSoft/OvenPlayer/tree/1d86437319fe8d3b0302a3c3893c0968a325e362/demo/ome_demo.html

```
navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class
```


## License: unknown
https://github.com/alex-vlad/alex-vlad.github.io/tree/0eee6626316e999d4de5d883c6d19ff2e33a7b2d/index.html

```
-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms
```

