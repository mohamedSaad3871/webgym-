import os
import sys
import sqlite3
from flask import Flask
from werkzeug.security import generate_password_hash

# إنشاء تطبيق Flask بسيط
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../../instance/gym_pro.db'

def check_database():
    """التحقق من وجود قاعدة البيانات وإنشائها إذا لم تكن موجودة."""
    db_path = os.path.join('..', '..', 'instance', 'gym_pro.db')
    
    if os.path.exists(db_path):
        print("- قاعدة البيانات موجودة")
        return True
    else:
        print("- قاعدة البيانات غير موجودة")
        # إنشاء المجلد إذا لم يكن موجودًا
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        # إنشاء قاعدة بيانات فارغة
        conn = sqlite3.connect(db_path)
        conn.close()
        print("- تم إنشاء قاعدة بيانات جديدة")
        return True

def create_admin_user():
    """إنشاء مستخدم أدمن في قاعدة البيانات."""
    db_path = os.path.join('..', '..', 'instance', 'gym_pro.db')
    
    if not os.path.exists(db_path):
        print("- قاعدة البيانات غير موجودة")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # التحقق من وجود جدول المستخدمين
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='user'")
        if not cursor.fetchone():
            # إنشاء جدول المستخدمين
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS user (
                id INTEGER PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                is_admin BOOLEAN DEFAULT 0
            )
            ''')
            print("- تم إنشاء جدول المستخدمين")
        
        # التحقق من وجود مستخدم أدمن
        cursor.execute("SELECT COUNT(*) FROM user WHERE is_admin = 1")
        admin_count = cursor.fetchone()[0]
        
        if admin_count > 0:
            print(f"- يوجد {admin_count} مستخدم أدمن في قاعدة البيانات")
        else:
            # إنشاء مستخدم أدمن جديد
            admin_username = "admin"
            admin_email = "admin@gymproarabic.com"
            admin_password = "Admin123!"
            password_hash = generate_password_hash(admin_password)
            
            cursor.execute(
                "INSERT INTO user (username, email, password_hash, is_admin) VALUES (?, ?, ?, ?)",
                (admin_username, admin_email, password_hash, True)
            )
            conn.commit()
            print("- تم إنشاء مستخدم أدمن جديد:")
            print(f"  اسم المستخدم: {admin_username}")
            print(f"  كلمة المرور: {admin_password}")
        
        conn.close()
        return True
    except sqlite3.Error as e:
        print(f"- خطأ في قاعدة البيانات: {e}")
        return False

def check_admin_templates():
    """التحقق من وجود قوالب صفحة الأدمن."""
    template_dir = os.path.join('app', 'templates', 'admin')
    
    if not os.path.exists(template_dir):
        print("- مجلد قوالب الأدمن غير موجود")
        return False
    
    required_templates = [
        'base.html', 
        'index.html', 
        'users.html'
    ]
    
    missing_templates = []
    for template in required_templates:
        template_path = os.path.join(template_dir, template)
        if not os.path.exists(template_path):
            missing_templates.append(template)
    
    if missing_templates:
        print(f"- قوالب مفقودة: {', '.join(missing_templates)}")
        return False
    else:
        print("- جميع قوالب الأدمن المطلوبة موجودة")
        return True

def check_csrf_template():
    """التحقق من وجود قالب خطأ CSRF."""
    csrf_template = os.path.join('app', 'templates', 'csrf_error.html')
    
    if os.path.exists(csrf_template):
        print("- قالب خطأ CSRF موجود")
        return True
    else:
        print("- قالب خطأ CSRF غير موجود")
        return False

def fix_admin_issues():
    """إصلاح مشاكل صفحة الأدمن."""
    print("\n=== أداة إصلاح صفحة الأدمن في GymPro Arabic ===\n")
    
    # التحقق من قاعدة البيانات
    print("1. التحقق من قاعدة البيانات:")
    db_ok = check_database()
    
    # إنشاء مستخدم أدمن
    print("\n2. التحقق من مستخدم الأدمن:")
    admin_ok = create_admin_user() if db_ok else False
    
    # التحقق من قوالب الأدمن
    print("\n3. التحقق من قوالب الأدمن:")
    templates_ok = check_admin_templates()
    
    # التحقق من قالب CSRF
    print("\n4. التحقق من قالب خطأ CSRF:")
    csrf_ok = check_csrf_template()
    
    # ملخص
    print("\n=== ملخص الإصلاح ===")
    if db_ok and admin_ok and templates_ok and csrf_ok:
        print("تم إصلاح جميع المشاكل بنجاح!")
    else:
        print("تم العثور على بعض المشاكل. يرجى مراجعة التفاصيل أعلاه.")
    
    print("\nيمكنك الآن تشغيل التطبيق باستخدام:")
    print("  python wsgi.py")
    print("\nيمكنك الوصول إلى صفحة الأدمن من خلال:")
    print("  http://localhost:5000/admin")
    print("\nبيانات دخول الأدمن الافتراضية:")
    print("  اسم المستخدم: admin")
    print("  كلمة المرور: Admin123!")

if __name__ == '__main__':
    fix_admin_issues() 