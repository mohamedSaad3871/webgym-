"""
This script lists all tables in the SQLite database.
"""
import os
import sqlite3
from app import create_app

def list_tables():
    """List all tables in the database."""
    app = create_app()
    
    # Get the database path from the app config
    db_path = app.config['SQLALCHEMY_DATABASE_URI'].replace('sqlite:///', '')
    
    print(f"Connecting to database at: {db_path}")
    
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    try:
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        if tables:
            print("Tables in the database:")
            for table in tables:
                print(f"- {table[0]}")
                
                # Show columns for each table
                cursor.execute(f"PRAGMA table_info({table[0]})")
                columns = cursor.fetchall()
                print("  Columns:")
                for column in columns:
                    print(f"    - {column[1]} ({column[2]})")
                print()
        else:
            print("No tables found in the database.")
            
    except Exception as e:
        print(f"Error: {e}")
    finally:
        conn.close()

if __name__ == "__main__":
    list_tables()
    print("Database inspection completed.")
