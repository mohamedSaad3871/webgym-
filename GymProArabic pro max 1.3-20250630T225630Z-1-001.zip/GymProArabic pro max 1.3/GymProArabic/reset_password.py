from app import create_app
from app.models.user import User
from app import db
import sys

def reset_password(username, new_password):
    app = create_app()
    
    with app.app_context():
        user = User.query.filter_by(username=username).first()
        
        if not user:
            print(f"Error: User '{username}' not found in the database.")
            return False
        
        user.set_password(new_password)
        db.session.commit()
        print(f"Password for user '{username}' has been reset successfully.")
        return True

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python reset_password.py <username> <new_password>")
        sys.exit(1)
    
    username = sys.argv[1]
    new_password = sys.argv[2]
    
    success = reset_password(username, new_password)
    if not success:
        sys.exit(1)
