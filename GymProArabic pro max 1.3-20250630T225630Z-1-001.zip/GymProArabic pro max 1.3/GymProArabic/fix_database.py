import os
import sys
import sqlite3
from datetime import datetime

# Add the project directory to the path so we can import the app
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

def check_database_exists():
    """Check if the database file exists."""
    db_path = os.path.join('instance', 'gym_pro.db')
    if os.path.exists(db_path):
        print(f"✅ Database file found at {db_path}")
        return True
    else:
        print(f"❌ Database file not found at {db_path}")
        return False

def check_database_tables():
    """Check if all required tables exist in the database."""
    required_tables = [
        'user',
        'exercise',
        'workout',
        'workout_plan',
        'diet_plan',
        'meal',
        'food',
        'tip',
        'supplement',
        'contact_message',
        'settings'
    ]
    
    db_path = os.path.join('instance', 'gym_pro.db')
    if not os.path.exists(db_path):
        print("❌ Cannot check tables: Database file not found")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get list of tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = [row[0] for row in cursor.fetchall()]
        
        missing_tables = [table for table in required_tables if table not in tables]
        
        if missing_tables:
            print(f"❌ Missing tables: {', '.join(missing_tables)}")
            return False
        else:
            print(f"✅ All required tables exist in the database")
            return True
            
    except sqlite3.Error as e:
        print(f"❌ Error checking database tables: {e}")
        return False
    finally:
        if conn:
            conn.close()

def backup_database():
    """Create a backup of the database."""
    db_path = os.path.join('instance', 'gym_pro.db')
    if not os.path.exists(db_path):
        print("❌ Cannot backup: Database file not found")
        return False
        
    try:
        # Create backups directory if it doesn't exist
        backup_dir = os.path.join('instance', 'backups')
        os.makedirs(backup_dir, exist_ok=True)
        
        # Create backup filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = os.path.join(backup_dir, f'gym_pro_{timestamp}.db')
        
        # Connect to source database
        conn = sqlite3.connect(db_path)
        
        # Backup database to new file
        with open(backup_path, 'wb') as f:
            for line in conn.iterdump():
                f.write(f'{line}\n'.encode('utf8'))
                
        conn.close()
        
        print(f"✅ Database backup created at {backup_path}")
        return True
    except Exception as e:
        print(f"❌ Error creating database backup: {e}")
        return False

def check_admin_permissions():
    """Check if admin users have proper permissions."""
    db_path = os.path.join('instance', 'gym_pro.db')
    if not os.path.exists(db_path):
        print("❌ Cannot check admin permissions: Database file not found")
        return False
        
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if user table has is_admin column
        cursor.execute("PRAGMA table_info(user)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'is_admin' not in columns:
            print("❌ User table is missing is_admin column")
            return False
            
        # Check for admin users
        cursor.execute("SELECT COUNT(*) FROM user WHERE is_admin = 1")
        admin_count = cursor.fetchone()[0]
        
        if admin_count == 0:
            print("❌ No admin users found in the database")
            return False
        else:
            print(f"✅ Found {admin_count} admin users in the database")
            return True
            
    except sqlite3.Error as e:
        print(f"❌ Error checking admin permissions: {e}")
        return False
    finally:
        if conn:
            conn.close()

def fix_database_issues():
    """Fix common database issues."""
    print("=== GymPro Arabic Database Fixer ===")
    
    # Check if database exists
    db_exists = check_database_exists()
    
    # Create a backup if database exists
    if db_exists:
        backup_database()
    
    # Check database tables
    tables_ok = check_database_tables() if db_exists else False
    
    # Check admin permissions
    admin_ok = check_admin_permissions() if db_exists else False
    
    print("\n=== Database Diagnosis ===")
    if db_exists and tables_ok and admin_ok:
        print("✅ Database appears to be in good condition.")
    else:
        print("⚠️ Some issues were found with the database. See details above.")
        print("ℹ️ To fix these issues, run the application with 'flask run' to recreate the database.")

if __name__ == '__main__':
    fix_database_issues() 