// إضافة إلى ملف admin/base.html
function checkDatabaseConnection() {
    fetch('/admin/health-check')
        .then(response => response.json())
        .then(data => {
            if (!data.database_ok) {
                showAlert('تحذير: مشكلة في الاتصال بقاعدة البيانات', 'warning');
            }
        })
        .catch(error => {
            console.error('Error checking database:', error);
        });
}

// تشغيل الفحص عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', checkDatabaseConnection);