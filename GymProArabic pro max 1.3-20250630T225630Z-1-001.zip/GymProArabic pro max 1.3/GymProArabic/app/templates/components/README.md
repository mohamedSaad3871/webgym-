# مكونات التصميم المتجاوب لموقع GymPro Arabic
# Responsive Design Components for GymPro Arabic

هذا الدليل يشرح كيفية استخدام المكونات المتجاوبة لتحسين تصميم موقع GymPro Arabic وجعله متوافقًا مع جميع الأجهزة، مع إصلاح مشاكل التباين في الوضع الداكن.

## المكونات المتوفرة
## Available Components

### 1. الشبكة المتجاوبة (Responsive Grid)
### 1. Responsive Grid

استخدم هذا المكون لعرض مجموعة من العناصر في شبكة متجاوبة تتكيف مع حجم الشاشة.

```html
{% include 'components/responsive_grid.html' with 
   items=your_items_list 
   columns_desktop=4 
   columns_tablet=2 
   columns_mobile=1 
%}
```

**الخيارات المتاحة:**
- `items`: قائمة بالعناصر التي تريد عرضها في الشبكة
- `columns_desktop`: عدد الأعمدة على شاشات سطح المكتب (الافتراضي: 3)
- `columns_tablet`: عدد الأعمدة على الأجهزة اللوحية (الافتراضي: 2)
- `columns_mobile`: عدد الأعمدة على الهواتف المحمولة (الافتراضي: 1)

### 2. الهيدر المتجاوب (Responsive Header)
### 2. Responsive Header

استخدم هذا المكون لإنشاء عنوان قسم متجاوب مع إمكانية إضافة خلفية وزر.

```html
{% include 'components/responsive_header.html' with 
   title="عنوان القسم" 
   subtitle="وصف فرعي للقسم" 
   show_button=True 
   button_text="زر العمل" 
   button_url="#" 
%}
```

**الخيارات المتاحة:**
- `title`: عنوان القسم
- `subtitle`: وصف فرعي للقسم (اختياري)
- `show_button`: إظهار زر العمل (True/False)
- `button_text`: نص الزر
- `button_url`: رابط الزر
- `bg_image`: استخدام صورة خلفية (True/False)
- `bg_image_url`: رابط صورة الخلفية
- `text_alignment`: محاذاة النص (center/start/end)
- `text_color`: لون النص (dark/light)

### 3. البطاقة المتجاوبة (Responsive Card)
### 3. Responsive Card

استخدم هذا المكون لإنشاء بطاقات متجاوبة لعرض المحتوى.

```html
{% include 'components/responsive_card.html' with 
   title="عنوان البطاقة" 
   content="محتوى البطاقة" 
   image_url="/static/img/example.jpg" 
   button_text="زر العمل" 
   button_url="#" 
   show_button=True
%}
```

**الخيارات المتاحة:**
- `title`: عنوان البطاقة
- `content`: محتوى البطاقة (يمكن استخدام HTML)
- `image_url`: رابط الصورة (اختياري)
- `button_text`: نص الزر
- `button_url`: رابط الزر
- `show_button`: إظهار زر العمل (True/False)
- `card_type`: نوع البطاقة (default/feature/outline/minimal)
- `dark_mode`: تفعيل وضع البطاقة الداكن (True/False)

### 4. الفوتر المتجاوب (Responsive Footer)
### 4. Responsive Footer

استخدم هذا المكون لإنشاء فوتر متجاوب للموقع.

```html
{% include 'components/responsive_footer.html' %}
```

### 5. الجدول المتجاوب (Responsive Table)
### 5. Responsive Table

استخدم هذا المكون لإنشاء جداول متجاوبة تعمل على جميع الأجهزة.

```html
{% include 'components/responsive_table.html' with 
   headers=["العنوان 1", "العنوان 2", "العنوان 3"]
   rows=[
     ["قيمة 1-1", "قيمة 1-2", "قيمة 1-3"],
     ["قيمة 2-1", "قيمة 2-2", "قيمة 2-3"]
   ]
   dark_mode=True
%}
```

**الخيارات المتاحة:**
- `headers`: قائمة بعناوين الأعمدة
- `rows`: قائمة بالصفوف، كل صف هو قائمة بالقيم
- `dark_mode`: تفعيل وضع الجدول الداكن (True/False)
- `striped`: جدول متناوب الألوان (True/False)
- `hover`: تأثير التحويم على الصفوف (True/False)
- `bordered`: جدول بحدود (True/False)
- `responsive_type`: نوع الاستجابة للأجهزة المحمولة (card/scroll/stack)

## فئات CSS المساعدة
## CSS Helper Classes

تم إضافة العديد من فئات CSS المساعدة لتحسين تباين النصوص وإصلاح مشاكل الوضع الداكن:

### فئات تحسين التباين
### Contrast Enhancement Classes

- `text-contrast-dark`: نص بتباين عالي على خلفية داكنة
- `text-contrast-light`: نص بتباين عالي على خلفية فاتحة
- `text-contrast-brand`: نص بتباين عالي على خلفية البراند
- `card-text-contrast`: تحسين تباين النص في البطاقات
- `heading-contrast`: تحسين تباين العناوين
- `link-contrast`: تحسين تباين الروابط
- `table-text-contrast`: تحسين تباين النص في الجداول
- `form-text-contrast`: تحسين تباين النص في النماذج

### فئات الخلفية
### Background Classes

- `text-bg-dark-overlay`: خلفية شبه شفافة داكنة للنص
- `text-bg-light-overlay`: خلفية شبه شفافة فاتحة للنص
- `dark-overlay`: عنصر مع طبقة داكنة شفافة

### فئات أخرى
### Other Classes

- `text-on-image`: تحسين وضوح النص على الصور
- `btn-text-contrast`: تحسين وضوح النص في الأزرار
- `alert-text-contrast`: تحسين وضوح النص في الإنذارات
- `list-text-contrast`: تحسين وضوح النص في القوائم

## أمثلة على الاستخدام
## Usage Examples

### مثال على استخدام الشبكة المتجاوبة مع البطاقات
### Example of Responsive Grid with Cards

```html
{% set card_items = [] %}
{% for item in data %}
    {% set card_content %}
        {% include 'components/responsive_card.html' with 
            title=item.title 
            content=item.description 
            image_url=item.image 
            button_url=item.url 
            button_text="عرض التفاصيل"
            dark_mode=True
        %}
    {% endset %}
    {% set _ = card_items.append(card_content) %}
{% endfor %}

{% include 'components/responsive_grid.html' with 
    items=card_items 
    columns_desktop=3 
    columns_tablet=2 
    columns_mobile=1 
%}
```

### مثال على استخدام الهيدر المتجاوب مع الجدول المتجاوب
### Example of Responsive Header with Responsive Table

```html
{% include 'components/responsive_header.html' with 
    title="جدول التمارين الأسبوعي" 
    subtitle="برنامج تدريبي متكامل لمدة أسبوع" 
    text_color="light"
    bg_image=True
    bg_image_url="/static/img/workout-bg.jpg"
%}

{% include 'components/responsive_table.html' with 
    headers=["اليوم", "التمارين", "المجموعات", "التكرارات"]
    rows=[
        ["الاثنين", "تمارين الصدر والترايسبس", "4", "12-10"],
        ["الثلاثاء", "تمارين الظهر والبايسبس", "4", "12-10"],
        ["الأربعاء", "راحة", "-", "-"],
        ["الخميس", "تمارين الأكتاف", "4", "12-10"],
        ["الجمعة", "تمارين الأرجل", "4", "12-10"],
        ["السبت", "تمارين البطن والكارديو", "3", "15-12"],
        ["الأحد", "راحة", "-", "-"]
    ]
    dark_mode=True
    responsive_type="card"
%}
```

## نصائح إضافية
## Additional Tips

1. استخدم فئة `text-contrast-dark` لتحسين وضوح النص على الخلفيات الداكنة.
2. استخدم فئة `dark-overlay` للعناصر التي تحتوي على صور خلفية لتحسين وضوح النص.
3. استخدم فئة `card-text-contrast` لتحسين وضوح النص في البطاقات في الوضع الداكن.
4. استخدم `responsive_type="card"` للجداول على الأجهزة المحمولة للحصول على تجربة أفضل.
5. استخدم فئة `text-bg-dark-overlay` لإضافة خلفية شبه شفافة للنص على الصور. 