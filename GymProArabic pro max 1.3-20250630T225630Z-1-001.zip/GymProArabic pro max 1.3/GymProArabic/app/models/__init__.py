# This file is intentionally left empty to mark the directory as a Python package

from app import db

# Import all models
from app.models.user import User
from app.models.workout import Exercise, Workout, WorkoutPlan
from app.models.diet import Food, Meal, DietPlan
from app.models.tip import Tip, ContactMessage
from app.models.supplement import Supplement
from app.models.settings import Settings, initialize_settings
from app.models.calculator import Calculator
