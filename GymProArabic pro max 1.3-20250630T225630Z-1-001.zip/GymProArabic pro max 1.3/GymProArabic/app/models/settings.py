from app import db
from datetime import datetime

class Settings(db.Model):
    """Model for site settings."""
    __tablename__ = 'settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __repr__(self):
        return f'<Setting {self.key}>'
    
    @classmethod
    def get(cls, key, default=None):
        """Get a setting value by key."""
        setting = cls.query.filter_by(key=key).first()
        if setting:
            return setting.value
        return default
    
    @classmethod
    def set(cls, key, value):
        """Set a setting value by key."""
        setting = cls.query.filter_by(key=key).first()
        if setting:
            setting.value = value
        else:
            setting = cls(key=key, value=value)
            db.session.add(setting)
        db.session.commit()
        return setting
    
    @classmethod
    def get_all(cls):
        """Get all settings as a dictionary."""
        try:
            settings = cls.query.all()
            if settings is None:
                return {}  # إرجاع قاموس فارغ بدلاً من None
            return {s.key: s.value for s in settings}
        except Exception as e:
            print(f"خطأ في استرجاع الإعدادات: {e}")
            return {}  # إرجاع قاموس فارغ في حالة حدوث خطأ
    
    @classmethod
    def get_grouped_settings(cls):
        """Get settings grouped by prefix."""
        settings = cls.get_all()
        result = {}
        
        # التحقق من أن settings ليست None قبل محاولة التكرار عليها
        if not settings:
            return result  # إرجاع قاموس فارغ
        
        for key, value in settings.items():
            if '_' in key:
                prefix, name = key.split('_', 1)
                if prefix not in result:
                    result[prefix] = {}
                result[prefix][name] = value
            else:
                if 'general' not in result:
                    result['general'] = {}
                result['general'][key] = value
        
        return result

# Define default settings
DEFAULT_SETTINGS = {
    'site_name': 'GymPro Arabic',
    'site_description': 'موقع رياضي عربي متخصص في التمارين الرياضية والتغذية السليمة',
    'contact_email': 'contact@gymproarabic.com',
    'social_facebook': '',
    'social_instagram': '',
    'social_twitter': '',
    'social_youtube': '',
    'primary_color': '#4e73df',
    'secondary_color': '#1cc88a',
    'enable_dark_mode': 'false',
    'logo_url': '/static/images/logo.png',
    'favicon_url': '/static/images/favicon.ico',
    'meta_keywords': 'رياضة, تمارين, لياقة بدنية, تغذية, صحة',
    'items_per_page': '10',
    'maintenance_mode': 'false',
    'analytics_code': ''
}

def initialize_settings():
    """Initialize default settings if they don't exist."""
    try:
        for key, value in DEFAULT_SETTINGS.items():
            if Settings.get(key) is None:
                Settings.set(key, value)
    except Exception as e:
        print(f"خطأ في تهيئة الإعدادات: {e}")
        # محاولة إنشاء جدول الإعدادات إذا لم يكن موجودًا
        db.create_all() 