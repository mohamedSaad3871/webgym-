from app import db
from datetime import datetime

class Food(db.Model):
    """Model for food items."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    calories = db.Column(db.Integer)
    protein = db.Column(db.Float)  # in grams
    carbs = db.Column(db.Float)    # in grams
    fat = db.Column(db.Float)      # in grams
    fiber = db.Column(db.Float)    # in grams
    serving_size = db.Column(db.String(50))
    food_group = db.Column(db.String(50))  # protein, carbs, fats, vegetables, fruits, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    meal_foods = db.relationship('MealFood', back_populates='food', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Food {self.name}>'

class Meal(db.Model):
    """Model for meals (breakfast, lunch, dinner, snacks)."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    meal_type = db.Column(db.String(20))  # breakfast, lunch, dinner, snack
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    foods = db.relationship('MealFood', back_populates='meal', cascade='all, delete-orphan')
    diet_meals = db.relationship('DietMeal', back_populates='meal', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Meal {self.name}>'
    
    @property
    def total_calories(self):
        """Calculate total calories for the meal."""
        return sum(meal_food.quantity * meal_food.food.calories for meal_food in self.foods)
    
    @property
    def total_protein(self):
        """Calculate total protein for the meal."""
        return sum(meal_food.quantity * meal_food.food.protein for meal_food in self.foods)
    
    @property
    def total_carbs(self):
        """Calculate total carbs for the meal."""
        return sum(meal_food.quantity * meal_food.food.carbs for meal_food in self.foods)
    
    @property
    def total_fat(self):
        """Calculate total fat for the meal."""
        return sum(meal_food.quantity * meal_food.food.fat for meal_food in self.foods)

class MealFood(db.Model):
    """Association model between meals and foods."""
    id = db.Column(db.Integer, primary_key=True)
    meal_id = db.Column(db.Integer, db.ForeignKey('meal.id'), nullable=False)
    food_id = db.Column(db.Integer, db.ForeignKey('food.id'), nullable=False)
    quantity = db.Column(db.Float, default=1.0)  # Number of servings
    notes = db.Column(db.Text)
    
    # Relationships
    meal = db.relationship('Meal', back_populates='foods')
    food = db.relationship('Food', back_populates='meal_foods')
    
    def __repr__(self):
        return f'<MealFood {self.meal.name} - {self.food.name}>'

class DietPlan(db.Model):
    """Model for diet plans."""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    goal = db.Column(db.String(50))  # weight loss, muscle gain, maintenance
    calories_target = db.Column(db.Integer)
    protein_target = db.Column(db.Integer)  # in grams
    carbs_target = db.Column(db.Integer)    # in grams
    fat_target = db.Column(db.Integer)      # in grams
    duration_days = db.Column(db.Integer, default=7)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    days = db.relationship('DietDay', back_populates='plan', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<DietPlan {self.title}>'

class DietDay(db.Model):
    """Model for days in a diet plan."""
    id = db.Column(db.Integer, primary_key=True)
    plan_id = db.Column(db.Integer, db.ForeignKey('diet_plan.id'), nullable=False)
    day_number = db.Column(db.Integer)  # 1-7 for days of the week
    notes = db.Column(db.Text)
    
    # Relationships
    plan = db.relationship('DietPlan', back_populates='days')
    meals = db.relationship('DietMeal', back_populates='day', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<DietDay {self.plan.title} - Day {self.day_number}>'
    
    @property
    def total_calories(self):
        """Calculate total calories for the day."""
        return sum(diet_meal.meal.total_calories for diet_meal in self.meals)
    
    @property
    def total_protein(self):
        """Calculate total protein for the day."""
        return sum(diet_meal.meal.total_protein for diet_meal in self.meals)
    
    @property
    def total_carbs(self):
        """Calculate total carbs for the day."""
        return sum(diet_meal.meal.total_carbs for diet_meal in self.meals)
    
    @property
    def total_fat(self):
        """Calculate total fat for the day."""
        return sum(diet_meal.meal.total_fat for diet_meal in self.meals)

class DietMeal(db.Model):
    """Association model between diet days and meals."""
    id = db.Column(db.Integer, primary_key=True)
    day_id = db.Column(db.Integer, db.ForeignKey('diet_day.id'), nullable=False)
    meal_id = db.Column(db.Integer, db.ForeignKey('meal.id'), nullable=False)
    meal_time = db.Column(db.String(20))  # morning, noon, evening, etc.
    notes = db.Column(db.Text)
    
    # Relationships
    day = db.relationship('DietDay', back_populates='meals')
    meal = db.relationship('Meal', back_populates='diet_meals')
    
    def __repr__(self):
        return f'<DietMeal {self.day.plan.title} - Day {self.day.day_number} - {self.meal.name}>'
