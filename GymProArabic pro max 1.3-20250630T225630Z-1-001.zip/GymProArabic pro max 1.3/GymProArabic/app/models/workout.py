from app import db
from datetime import datetime

class Exercise(db.Model):
    """Model for exercises."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    muscle_group = db.Column(db.String(50))
    difficulty = db.Column(db.String(20))  # beginner, intermediate, advanced
    instructions = db.Column(db.Text)
    image_url = db.Column(db.String(255))
    video_url = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    workout_exercises = db.relationship('WorkoutExercise', back_populates='exercise', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Exercise {self.name}>'

class Workout(db.Model):
    """Model for workout plans."""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    difficulty = db.Column(db.String(20))
    duration_minutes = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    exercises = db.relationship('WorkoutExercise', back_populates='workout', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<Workout {self.title}>'

class WorkoutExercise(db.Model):
    """Association model between workouts and exercises."""
    id = db.Column(db.Integer, primary_key=True)
    workout_id = db.Column(db.Integer, db.ForeignKey('workout.id'), nullable=False)
    exercise_id = db.Column(db.Integer, db.ForeignKey('exercise.id'), nullable=False)
    sets = db.Column(db.Integer)
    reps = db.Column(db.String(50))  # Could be a range like "8-12"
    rest_seconds = db.Column(db.Integer)
    notes = db.Column(db.Text)
    order = db.Column(db.Integer)  # To maintain the order of exercises in a workout
    
    # Relationships
    workout = db.relationship('Workout', back_populates='exercises')
    exercise = db.relationship('Exercise', back_populates='workout_exercises')
    
    def __repr__(self):
        return f'<WorkoutExercise {self.workout.title} - {self.exercise.name}>'

class WorkoutPlan(db.Model):
    """Model for weekly workout plans."""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    difficulty = db.Column(db.String(20))
    duration_weeks = db.Column(db.Integer, default=1)
    goal = db.Column(db.String(50))  # weight loss, muscle gain, etc.
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    days = db.relationship('WorkoutDay', back_populates='plan', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<WorkoutPlan {self.title}>'

class WorkoutDay(db.Model):
    """Model for days in a workout plan."""
    id = db.Column(db.Integer, primary_key=True)
    plan_id = db.Column(db.Integer, db.ForeignKey('workout_plan.id'), nullable=False)
    day_number = db.Column(db.Integer)  # 1-7 for days of the week
    workout_id = db.Column(db.Integer, db.ForeignKey('workout.id'))
    is_rest_day = db.Column(db.Boolean, default=False)
    notes = db.Column(db.Text)
    
    # Relationships
    plan = db.relationship('WorkoutPlan', back_populates='days')
    workout = db.relationship('Workout')
    
    def __repr__(self):
        return f'<WorkoutDay {self.plan.title} - Day {self.day_number}>'
