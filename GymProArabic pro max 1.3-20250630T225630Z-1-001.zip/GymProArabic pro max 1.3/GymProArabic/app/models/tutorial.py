from app import db
from datetime import datetime
import re

class ExerciseTutorial(db.Model):
    """Model for exercise tutorials showing correct form."""
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    muscle_group = db.Column(db.String(50), nullable=False)  # chest, back, legs, biceps, triceps, shoulders, abs
    reps_range = db.Column(db.String(50))  # e.g., "8-12"
    tips = db.Column(db.Text)
    thumbnail_url = db.Column(db.String(255))
    video_url = db.Column(db.String(255))
    video_type = db.Column(db.String(20), default='youtube')  # youtube or mp4
    order = db.Column(db.Integer, default=0)  # For ordering within muscle group
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<ExerciseTutorial {self.title}>'
    
    @property
    def embed_url(self):
        """Get the embeddable video URL."""
        if self.video_type == 'youtube':
            # Supported YouTube URL formats:
            # https://youtube.com/watch?v=VIDEO_ID
            # https://youtu.be/VIDEO_ID
            # https://www.youtube.com/embed/VIDEO_ID
            youtube_regex = r'(?:youtube\.com\/(?:watch\?v=|embed\/)|youtu\.be\/)([^&\?\/]+)'
            match = re.search(youtube_regex, self.video_url or '')
            if match:
                video_id = match.group(1)
                return f'https://www.youtube.com/embed/{video_id}'
            return self.video_url  # Return as is if no match
        return self.video_url  # Return as is for non-YouTube videos
