from app import db
from datetime import datetime

class Supplement(db.Model):
    """Model for nutritional supplements."""
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    benefits = db.Column(db.Text)
    recommended_dosage = db.Column(db.String(100))
    when_to_take = db.Column(db.Text)
    supplement_type = db.Column(db.String(50))  # protein, pre-workout, vitamins, etc.
    image_url = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Supplement {self.name}>'
