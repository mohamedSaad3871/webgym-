from flask import render_template, request, redirect, url_for, flash
from datetime import datetime
from app.supplements import supplements_bp
from app.models.supplement import Supplement
from app import db
from app.utils.url_helpers import get_supplement_id, slugify, is_valid_url

@supplements_bp.route('/')
def index():
    """Supplements main page."""
    # Sample supplements data (in a real app, this would come from the database)
    supplements = [
        {
            'id': 1,
            'name': 'بروتين مصل اللبن (Whey Protein)',
            'description': 'بروتين سريع الامتصاص مستخلص من اللبن، مثالي لاستعادة العضلات بعد التمرين.',
            'benefits': 'يساعد في بناء العضلات وإصلاحها، يوفر الأحماض الأمينية الأساسية، سهل الهضم.',
            'recommended_dosage': '20-30 جرام (1-2 مغرفة) مع الماء أو الحليب.',
            'when_to_take': 'بعد التمرين مباشرة، أو كوجبة خفيفة بين الوجبات الرئيسية.',
            'category': 'بروتين',
            'image_url': 'img/supplements/whey_protein.jpg',
            'slug': 'whey-protein'  # إضافة slug لكل مكمل
        },
        {
            'id': 2,
            'name': 'كرياتين مونوهيدرات (Creatine Monohydrate)',
            'description': 'مكمل طبيعي يساعد في إنتاج الطاقة للعضلات أثناء التمارين عالية الكثافة.',
            'benefits': 'زيادة القوة والأداء، زيادة حجم العضلات، تحسين استعادة العضلات.',
            'recommended_dosage': '3-5 جرام يومياً.',
            'when_to_take': 'يمكن تناوله في أي وقت من اليوم، ويفضل مع وجبة تحتوي على الكربوهيدرات.',
            'category': 'قوة وأداء',
            'image_url': 'img/supplements/creatine.jpg',
            'slug': 'creatine'
        },
        {
            'id': 3,
            'name': 'أحماض أمينية متفرعة السلسلة (BCAA)',
            'description': 'مجموعة من الأحماض الأمينية الأساسية (ليوسين، أيزوليوسين، فالين) التي تساعد في بناء العضلات.',
            'benefits': 'تقليل تحلل العضلات، تحسين استعادة العضلات، تقليل التعب أثناء التمرين.',
            'recommended_dosage': '5-10 جرام.',
            'when_to_take': 'قبل أو أثناء أو بعد التمرين.',
            'category': 'استعادة العضلات',
            'image_url': 'img/supplements/bcaa.jpg',
            'slug': 'bcaa'
        },
        {
            'id': 4,
            'name': 'مكملات ما قبل التمرين (Pre-Workout)',
            'description': 'مزيج من المكونات المصممة لزيادة الطاقة والتركيز والأداء أثناء التمرين.',
            'benefits': 'زيادة الطاقة والتركيز، تحسين تدفق الدم إلى العضلات، زيادة القدرة على التحمل.',
            'recommended_dosage': 'حسب توصيات المنتج (عادة 1 مغرفة).',
            'when_to_take': '20-30 دقيقة قبل التمرين.',
            'category': 'طاقة وأداء',
            'image_url': 'img/supplements/pre_workout.jpg',
            'slug': 'pre-workout'
        },
        {
            'id': 5,
            'name': 'أوميغا 3 (Omega-3)',
            'description': 'أحماض دهنية أساسية توجد بشكل طبيعي في الأسماك الدهنية والمكسرات.',
            'benefits': 'تقليل الالتهابات، دعم صحة القلب، تحسين صحة المفاصل، دعم وظائف المخ.',
            'recommended_dosage': '1-3 جرام يومياً.',
            'when_to_take': 'مع الوجبات لتحسين الامتصاص.',
            'category': 'صحة عامة',
            'image_url': 'img/supplements/omega3.jpg',
            'slug': 'omega-3'
        },
        {
            'id': 6,
            'name': 'جلوتامين (Glutamine)',
            'description': 'حمض أميني غير أساسي يلعب دوراً مهماً في استعادة العضلات والجهاز المناعي.',
            'benefits': 'تسريع استعادة العضلات، دعم الجهاز المناعي، تحسين صحة الأمعاء.',
            'recommended_dosage': '5-10 جرام يومياً.',
            'when_to_take': 'بعد التمرين أو قبل النوم.',
            'category': 'استعادة العضلات',
            'image_url': 'img/supplements/glutamine.jpg',
            'slug': 'glutamine'
        }
    ]
    
    # إضافة slug لكل مكمل إذا لم يكن موجودًا
    for supplement in supplements:
        if 'slug' not in supplement:
            supplement['slug'] = get_supplement_id(supplement['name'])
    
    return render_template('supplements/index_dark.html', 
                          title='المكملات الغذائية | جيم برو العربية',
                          supplements=supplements,
                          now=datetime.now())

@supplements_bp.route('/<string:supplement_slug>')
def detail_by_slug(supplement_slug):
    """Supplement detail page using slug (preferred method)."""
    # قائمة المكملات مع slugs
    supplement_slugs = {
        'whey-protein': 1,
        'creatine': 2,
        'bcaa': 3,
        'pre-workout': 4,
        'omega-3': 5,
        'glutamine': 6,
        # أسماء مختلفة للمكمل نفسه
        'fish-oil': 5,
        'protein': 1
    }
    
    # تحويل slug إلى رقم المكمل
    numeric_id = supplement_slugs.get(supplement_slug)
    
    if numeric_id is None:
        flash('المكمل الغذائي غير موجود', 'danger')
        return redirect(url_for('supplements.index'))
    
    # استخدام المسار الحالي مع الرقم
    return supplement_detail(numeric_id)

@supplements_bp.route('/detail/<string:supplement_id>')
def detail(supplement_id):
    """Supplement detail page for string IDs - for backward compatibility."""
    # قاموس للربط بين الأسماء النصية وأرقام المكملات
    supplement_ids = {
        'whey_protein': 1,
        'creatine': 2,
        'bcaa': 3,
        'pre_workout': 4,
        'fish_oil': 5,
        'omega3': 5,
        'glutamine': 6,
        'multivitamin': 7
    }
    
    # تحويل الاسم النصي إلى رقم المكمل
    numeric_id = supplement_ids.get(supplement_id)
    
    if numeric_id is None:
        # محاولة استخدام get_supplement_id للحصول على معرف
        for name, id_num in supplement_ids.items():
            if supplement_id.lower().replace('-', '_') == name.lower():
                numeric_id = id_num
                break
    
    if numeric_id is None:
        flash('المكمل الغذائي غير موجود', 'danger')
        return redirect(url_for('supplements.index'))
    
    # استخدام المسار الحالي مع الرقم
    return supplement_detail(numeric_id)

@supplements_bp.route('/<int:supplement_id>')
def supplement_detail(supplement_id):
    """Supplement detail page."""
    # Sample supplements data (in a real app, this would come from the database)
    supplements = {
        1: {
            'id': 1,
            'name': 'بروتين مصل اللبن (Whey Protein)',
            'description': 'بروتين مصل اللبن هو بروتين عالي الجودة مستخلص من اللبن أثناء عملية صناعة الجبن. يعتبر من أكثر المكملات الغذائية شيوعاً بين الرياضيين ولاعبي كمال الأجسام نظراً لقيمته الغذائية العالية وسهولة امتصاصه.',
            'benefits': '''
            <ul>
                <li>يساعد في بناء وإصلاح أنسجة العضلات بعد التمرين</li>
                <li>يحتوي على جميع الأحماض الأمينية الأساسية اللازمة لنمو العضلات</li>
                <li>سريع الامتصاص مما يجعله مثالياً بعد التمرين</li>
                <li>يساعد في التعافي من التمارين الشاقة</li>
                <li>يمكن أن يساعد في إنقاص الوزن عن طريق زيادة الشعور بالشبع</li>
            </ul>
            ''',
            'recommended_dosage': '20-30 جرام (1-2 مغرفة) مع الماء أو الحليب.',
            'when_to_take': '''
            <ul>
                <li><strong>بعد التمرين:</strong> خلال 30 دقيقة بعد التمرين لتعزيز استعادة العضلات</li>
                <li><strong>بين الوجبات:</strong> كوجبة خفيفة غنية بالبروتين</li>
                <li><strong>وجبة الإفطار:</strong> لبدء اليوم بكمية جيدة من البروتين</li>
                <li><strong>قبل النوم:</strong> يمكن تناول بروتين بطيء الامتصاص (كازين) للحصول على إمداد مستمر من الأحماض الأمينية أثناء النوم</li>
            </ul>
            ''',
            'category': 'بروتين',
            'image_url': 'img/supplements/whey_protein.jpg',
            'types': [
                'بروتين مركز (WPC): نسبة بروتين 70-80%',
                'بروتين معزول (WPI): نسبة بروتين 90% أو أكثر، منخفض الدهون واللاكتوز',
                'بروتين مهدرج (WPH): سهل الهضم والامتصاص'
            ],
            'side_effects': 'قد يسبب انتفاخ أو اضطرابات في المعدة لدى الأشخاص الذين يعانون من حساسية اللاكتوز. ينصح باختيار بروتين معزول (WPI) في هذه الحالة.',
            'slug': 'whey-protein'
        },
        2: {
            'id': 2,
            'name': 'كرياتين مونوهيدرات (Creatine Monohydrate)',
            'description': 'الكرياتين هو مركب طبيعي يتواجد في العضلات ويلعب دوراً أساسياً في إنتاج الطاقة خلال التمارين عالية الكثافة والقصيرة المدة. يعتبر من أكثر المكملات الغذائية المدروسة علمياً وأثبتت فعاليتها.',
            'benefits': '''
            <ul>
                <li>زيادة القوة العضلية والقدرة على رفع الأوزان الثقيلة</li>
                <li>تحسين الأداء في التمارين عالية الكثافة</li>
                <li>زيادة حجم العضلات من خلال احتباس الماء في العضلات</li>
                <li>تسريع استعادة العضلات بعد التمرين</li>
                <li>تحسين أداء الدماغ</li>
            </ul>
            ''',
            'recommended_dosage': '''
            <p><strong>طريقة التحميل:</strong> 20 جرام يومياً (مقسمة على 4 جرعات) لمدة 5-7 أيام، ثم 3-5 جرام يومياً للصيانة.</p>
            <p><strong>الطريقة المباشرة:</strong> 3-5 جرام يومياً بشكل مستمر.</p>
            ''',
            'when_to_take': '''
            <ul>
                <li>يمكن تناوله في أي وقت من اليوم</li>
                <li>يفضل تناوله مع وجبة تحتوي على الكربوهيدرات لتحسين الامتصاص</li>
                <li>البعض يفضل تناوله قبل التمرين للحصول على الطاقة، والبعض الآخر بعد التمرين للمساعدة في الاستشفاء</li>
            </ul>
            ''',
            'category': 'قوة وأداء',
            'image_url': 'img/supplements/creatine.jpg',
            'types': [
                'كرياتين مونوهيدرات: الأكثر شيوعاً ودراسة وفعالية',
                'كرياتين HCL: يدعي أنه أكثر قابلية للذوبان',
                'كرياتين إيثيل إستر: يدعي أنه أفضل امتصاصاً'
            ],
            'side_effects': 'قد يسبب احتباس الماء في الجسم، وبعض الأشخاص قد يعانون من تشنجات في المعدة. ينصح بشرب كمية كافية من الماء عند تناول الكرياتين.',
            'slug': 'creatine'
        },
        3: {
            'id': 3,
            'name': 'أحماض أمينية متفرعة السلسلة (BCAA)',
            'description': 'الأحماض الأمينية متفرعة السلسلة (BCAA) هي ثلاثة أحماض أمينية أساسية: الليوسين، الأيزوليوسين، والفالين. تشكل حوالي 35% من الأحماض الأمينية في عضلات الجسم وتلعب دوراً مهماً في بناء البروتين وإنتاج الطاقة.',
            'benefits': '''
            <ul>
                <li>تقليل تحلل العضلات أثناء التمارين الشاقة</li>
                <li>تحفيز بناء البروتين في العضلات</li>
                <li>تقليل التعب العضلي وتحسين الأداء</li>
                <li>تسريع استعادة العضلات بعد التمرين</li>
                <li>توفير مصدر للطاقة أثناء التمرين</li>
            </ul>
            ''',
            'recommended_dosage': '5-10 جرام يومياً، بنسبة 2:1:1 من الليوسين:الأيزوليوسين:الفالين.',
            'when_to_take': '''
            <ul>
                <li><strong>قبل التمرين:</strong> للمساعدة في منع تحلل العضلات</li>
                <li><strong>أثناء التمرين:</strong> للحد من التعب وتوفير الطاقة</li>
                <li><strong>بعد التمرين:</strong> للمساعدة في استعادة العضلات</li>
                <li><strong>بين الوجبات:</strong> للحفاظ على مستويات الأحماض الأمينية في الدم</li>
            </ul>
            ''',
            'category': 'استعادة العضلات',
            'image_url': 'img/supplements/bcaa.jpg',
            'types': [
                'BCAA بنسبة 2:1:1 (الأكثر شيوعاً)',
                'BCAA بنسبة 4:1:1 (نسبة أعلى من الليوسين)',
                'BCAA بنسبة 8:1:1 (نسبة عالية جداً من الليوسين)'
            ],
            'side_effects': 'عموماً آمنة للاستخدام، لكن قد تسبب بعض الاضطرابات الهضمية لدى بعض الأشخاص.',
            'slug': 'bcaa'
        },
        4: {
            'id': 4,
            'name': 'مكملات ما قبل التمرين (Pre-Workout)',
            'description': 'مكملات ما قبل التمرين هي مزيج من المكونات المصممة لتعزيز الطاقة والتركيز والأداء أثناء التمرين. تحتوي عادة على الكافيين، البيتا ألانين، الكرياتين، الأرجينين، وغيرها من المكونات.',
            'benefits': '''
            <ul>
                <li>زيادة الطاقة والتركيز أثناء التمرين</li>
                <li>تحسين تدفق الدم إلى العضلات (مضخة العضلات)</li>
                <li>زيادة القدرة على التحمل وتأخير التعب</li>
                <li>تحسين الأداء العام خلال التمرين</li>
                <li>زيادة حرق الدهون (في بعض المنتجات)</li>
            </ul>
            ''',
            'recommended_dosage': 'تختلف حسب المنتج، عادة 1 مغرفة (5-10 جرام) مخلوطة مع الماء.',
            'when_to_take': '''
            <ul>
                <li>20-30 دقيقة قبل بدء التمرين</li>
                <li>يفضل عدم تناولها في وقت متأخر من اليوم لتجنب اضطرابات النوم بسبب الكافيين</li>
            </ul>
            ''',
            'category': 'طاقة وأداء',
            'image_url': 'img/supplements/pre_workout.jpg',
            'types': [
                'مكملات تحتوي على الكافيين (للطاقة والتركيز)',
                'مكملات خالية من الكافيين (لمن لديهم حساسية من الكافيين)',
                'مكملات تركز على مضخة العضلات (تحتوي على الأرجينين، السيترولين، إلخ)'
            ],
            'side_effects': 'قد تسبب زيادة ضربات القلب، الأرق، العصبية، والصداع بسبب محتوى الكافيين. ينصح بالبدء بجرعة منخفضة لاختبار التحمل.',
            'slug': 'pre-workout'
        },
        5: {
            'id': 5,
            'name': 'أوميغا 3 (Omega-3)',
            'description': 'أوميغا 3 هي أحماض دهنية أساسية لا يستطيع الجسم إنتاجها بنفسه ويجب الحصول عليها من الغذاء أو المكملات. تشمل EPA و DHA (الموجودة في الأسماك) و ALA (الموجودة في المصادر النباتية).',
            'benefits': '''
            <ul>
                <li>تقليل الالتهابات في الجسم وتسريع الاستشفاء</li>
                <li>دعم صحة القلب والأوعية الدموية</li>
                <li>تحسين صحة المفاصل وتقليل آلام المفاصل</li>
                <li>دعم وظائف المخ والصحة العقلية</li>
                <li>تحسين صحة العين والبشرة</li>
            </ul>
            ''',
            'recommended_dosage': '1-3 جرام من EPA و DHA مجتمعين يومياً.',
            'when_to_take': '''
            <ul>
                <li>مع الوجبات لتحسين الامتصاص</li>
                <li>يمكن تقسيم الجرعة على مدار اليوم</li>
            </ul>
            ''',
            'category': 'صحة عامة',
            'image_url': 'img/supplements/omega3.jpg',
            'types': [
                'زيت السمك: غني بـ EPA و DHA',
                'زيت الكريل: مصدر بديل للـ EPA و DHA مع امتصاص أفضل',
                'مصادر نباتية: تحتوي على ALA (بذور الكتان، بذور الشيا، الجوز)'
            ],
            'side_effects': 'قد تسبب طعم السمك في الفم، حرقة المعدة، أو اضطرابات هضمية خفيفة. يفضل اختيار منتجات عالية الجودة ومنقاة.',
            'slug': 'omega-3'
        },
        6: {
            'id': 6,
            'name': 'جلوتامين (Glutamine)',
            'description': 'الجلوتامين هو حمض أميني غير أساسي يعتبر الأكثر وفرة في العضلات والدم. يلعب دوراً مهماً في استعادة العضلات، ودعم الجهاز المناعي، وصحة الجهاز الهضمي.',
            'benefits': '''
            <ul>
                <li>تسريع استعادة العضلات بعد التمارين الشاقة</li>
                <li>تقليل تحلل العضلات أثناء التمرين</li>
                <li>دعم وتقوية الجهاز المناعي</li>
                <li>تحسين صحة الأمعاء ووظائف الجهاز الهضمي</li>
                <li>المساعدة في التعافي من الإصابات والعمليات الجراحية</li>
            </ul>
            ''',
            'recommended_dosage': '5-10 جرام يومياً.',
            'when_to_take': '''
            <ul>
                <li><strong>بعد التمرين:</strong> للمساعدة في استعادة العضلات</li>
                <li><strong>قبل النوم:</strong> لدعم استعادة العضلات أثناء النوم</li>
                <li><strong>على معدة فارغة:</strong> لتحسين الامتصاص</li>
            </ul>
            ''',
            'category': 'استعادة العضلات',
            'image_url': 'img/supplements/glutamine.jpg',
            'types': [
                'L-جلوتامين: الشكل الحر الأكثر شيوعاً',
                'جلوتامين ببتيد: مرتبط بأحماض أمينية أخرى لتحسين الامتصاص',
                'N-أسيتيل جلوتامين: شكل أكثر استقراراً'
            ],
            'side_effects': 'عموماً آمن للاستخدام، لكن قد يسبب اضطرابات هضمية خفيفة لدى بعض الأشخاص.',
            'slug': 'glutamine'
        }
    }
    
    supplement = supplements.get(supplement_id)
    if not supplement:
        flash('المكمل الغذائي غير موجود', 'danger')
        return redirect(url_for('supplements.index'))
    
    # إضافة slug للمكمل إذا لم يكن موجودًا
    if 'slug' not in supplement:
        supplement['slug'] = get_supplement_id(supplement['name'])
    
    return render_template('supplements/detail_dark.html', 
                           title=f'{supplement["name"]} | جيم برو العربية',
                           supplement=supplement,
                           now=datetime.now())
