from flask import Blueprint

supplements_bp = Blueprint('supplements', __name__)

from app.supplements import routes
