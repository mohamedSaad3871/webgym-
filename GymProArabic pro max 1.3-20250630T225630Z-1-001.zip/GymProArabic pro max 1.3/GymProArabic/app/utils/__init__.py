"""
وحدة المساعدة العامة للتطبيق
تحتوي على أدوات ووظائف مساعدة للاستخدام في جميع أنحاء التطبيق
"""

from app.utils.url_helpers import (
    slugify,
    get_supplement_id,
    get_workout_id,
    is_valid_url,
    get_fixed_route
) 