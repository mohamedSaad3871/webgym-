"""
وحدة المساعدة في إنشاء وإدارة الروابط
توفر وظائف لتحويل النصوص العربية إلى معرفات URL ملائمة
والتعامل مع الروابط المفقودة أو المكسورة
"""

def slugify(text):
    """
    تحويل النص إلى slug مناسب للاستخدام في URLs
    
    مثال:
    >>> slugify("بروتين مصل اللبن")
    "protein-whey"
    """
    # قاموس للكلمات العربية الشائعة وترجمتها بالإنجليزية
    arabic_to_english = {
        'بروتين': 'protein',
        'مصل': 'whey',
        'اللبن': 'whey',
        'كرياتين': 'creatine',
        'أحماض': 'acids',
        'أمينية': 'amino',
        'متفرعة': 'branched',
        'السلسلة': 'chain',
        'جلوتامين': 'glutamine',
        'أوميغا': 'omega',
        'حرق': 'burn',
        'الدهون': 'fat',
        'عضلات': 'muscle',
        'تضخيم': 'bulk',
        # يمكن إضافة المزيد من الكلمات حسب الحاجة
    }
    
    # تقسيم النص إلى كلمات
    words = text.split()
    
    # تحويل كل كلمة إلى ما يقابلها بالإنجليزية إذا كانت موجودة في القاموس
    english_words = []
    for word in words:
        if word in arabic_to_english:
            english_words.append(arabic_to_english[word])
    
    # إذا لم نجد أي ترجمات، نستخدم معرف مبني على رقم عشوائي
    if not english_words:
        import random
        import time
        # إنشاء معرف عشوائي باستخدام الوقت الحالي
        return f"item-{int(time.time())}-{random.randint(1000, 9999)}"
    
    # دمج الكلمات المترجمة مع شرطات بينها
    return "-".join(english_words)

def get_supplement_id(name):
    """
    تحويل اسم المكمل الغذائي إلى معرف مناسب للاستخدام في URLs
    
    مثال:
    >>> get_supplement_id("بروتين مصل اللبن (Whey Protein)")
    "whey-protein"
    """
    # قاموس للمكملات الغذائية الشائعة
    supplements_map = {
        'بروتين مصل اللبن': 'whey-protein',
        'كرياتين': 'creatine',
        'أحماض أمينية متفرعة السلسلة': 'bcaa',
        'مكملات ما قبل التمرين': 'pre-workout',
        'أوميغا 3': 'omega-3',
        'جلوتامين': 'glutamine',
    }
    
    # البحث عن المكمل في القاموس
    for arabic_name, english_id in supplements_map.items():
        if arabic_name in name:
            return english_id
    
    # إذا لم يتم العثور على المكمل في القاموس، استخدم slugify
    return slugify(name)

def get_workout_id(name):
    """
    تحويل اسم التمرين إلى معرف مناسب للاستخدام في URLs
    """
    # قاموس للتمارين الشائعة
    workouts_map = {
        'تمارين الصدر': 'chest-workouts',
        'تمارين الظهر': 'back-workouts',
        'تمارين الساقين': 'leg-workouts',
        'تمارين الكتف': 'shoulder-workouts',
        'تمارين البطن': 'abs-workouts',
        'تمارين الذراعين': 'arm-workouts',
        # يمكن إضافة المزيد من التمارين حسب الحاجة
    }
    
    # البحث عن التمرين في القاموس
    for arabic_name, english_id in workouts_map.items():
        if arabic_name in name:
            return english_id
    
    # إذا لم يتم العثور على التمرين في القاموس، استخدم slugify
    return slugify(name)

def is_valid_url(url):
    """
    التحقق من صحة URL
    """
    # تحقق بسيط من شكل URL
    if not url:
        return False
    
    if url.startswith('#') and len(url) == 1:
        return False
    
    return True

def get_fixed_route(route_name, **kwargs):
    """
    تحسين استخدام url_for مع معالجة الأخطاء
    
    مثال:
    >>> get_fixed_route('supplements.detail', supplement_id='unknown')
    "supplements.index"
    """
    from flask import url_for
    
    try:
        return url_for(route_name, **kwargs)
    except Exception:
        # إذا فشل إنشاء URL، عد إلى الصفحة الرئيسية للقسم
        parts = route_name.split('.')
        if len(parts) > 1:
            return url_for(f"{parts[0]}.index")
        
        # إذا لم ينجح ذلك، عد إلى الصفحة الرئيسية للموقع
        return url_for('main.index') 