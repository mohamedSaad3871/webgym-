from flask import render_template, redirect, url_for, flash, request, jsonify, current_app
from app.admin import admin_bp
from app.models.user import User
from app.models.tip import Tip, ContactMessage
from app.models.workout import Exercise, Workout, WorkoutPlan
from app.models.tutorial import ExerciseTutorial
from app.models.diet import Food, Meal, DietPlan
from app.models.supplement import Supplement
from app import db
from flask_login import login_required, current_user
from functools import wraps
import os
from werkzeug.utils import secure_filename
import uuid
from datetime import datetime, timedelta
from app.models.settings import Settings, initialize_settings

def admin_required(f):
    """Decorator to check if the current user is an admin."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('يجب أن تكون مسؤولاً للوصول إلى هذه الصفحة', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/')
@login_required
@admin_required
def index():
    """Admin dashboard."""
    # Count of various entities
    users_count = User.query.count()
    exercises_count = Exercise.query.count()
    workouts_count = Workout.query.count()
    diet_plans_count = DietPlan.query.count()
    tips_count = Tip.query.count()
    supplements_count = Supplement.query.count()
    messages_count = ContactMessage.query.count()
    unread_messages_count = ContactMessage.query.filter_by(is_read=False).count()
    
    # Get recent messages
    recent_messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).limit(5).all()
    
    # Use the final fixed template with simplified JavaScript to prevent loop issues
    return render_template('admin/index_final.html', 
                           title='لوحة التحكم | GymPro Arabic',
                           users_count=users_count,
                           exercises_count=exercises_count,
                           workouts_count=workouts_count,
                           diet_plans_count=diet_plans_count,
                           tips_count=tips_count,
                           supplements_count=supplements_count,
                           messages_count=messages_count,
                           unread_messages_count=unread_messages_count,
                           recent_messages=recent_messages)

@admin_bp.route('/users')
@login_required
@admin_required
def users():
    """Manage users."""
    users = User.query.all()
    return render_template('admin/users.html', 
                          title='إدارة المستخدمين | GymPro Arabic',
                          users=users)

@admin_bp.route('/users/<int:user_id>/toggle_admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin(user_id):
    """Toggle admin status for a user."""
    user = User.query.get_or_404(user_id)
    
    # Prevent removing admin status from the last admin
    if user.is_admin and User.query.filter_by(is_admin=True).count() <= 1:
        flash('لا يمكن إزالة صلاحيات المسؤول من المسؤول الوحيد', 'danger')
        return redirect(url_for('admin.users'))
    
    user.is_admin = not user.is_admin
    db.session.commit()
    
    flash(f'تم تحديث صلاحيات المستخدم {user.username} بنجاح', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_user(user_id):
    """Delete a user."""
    user = User.query.get_or_404(user_id)
    
    # Prevent deleting the last admin
    if user.is_admin and User.query.filter_by(is_admin=True).count() <= 1:
        flash('لا يمكن حذف المسؤول الوحيد', 'danger')
        return redirect(url_for('admin.users'))
    
    # Prevent self-deletion
    if user.id == current_user.id:
        flash('لا يمكنك حذف حسابك الخاص من هنا', 'danger')
        return redirect(url_for('admin.users'))
    
    db.session.delete(user)
    db.session.commit()
    
    flash(f'تم حذف المستخدم {user.username} بنجاح', 'success')
    return redirect(url_for('admin.users'))

@admin_bp.route('/exercises')
@login_required
@admin_required
def exercises():
    """Manage exercises."""
    exercises = Exercise.query.all()
    return render_template('admin/exercises.html', 
                          title='إدارة التمارين | GymPro Arabic',
                          exercises=exercises)

@admin_bp.route('/exercises/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_exercise():
    """Add a new exercise."""
    if request.method == 'POST':
        try:
            name = request.form.get('name')
            description = request.form.get('description')
            muscle_group = request.form.get('muscle_group')
            difficulty = request.form.get('difficulty')
            instructions = request.form.get('instructions')
            
            # Handle image upload
            image_url = None
            video_url = None
            
            if 'image' in request.files:
                image_file = request.files['image']
                if image_file and image_file.filename:
                    image_url, message = save_file(image_file, 'exercises')
                    if not image_url:
                        flash(f'خطأ في رفع الصورة: {message}', 'danger')
                        return redirect(request.url)
            
            if 'video' in request.files:
                video_file = request.files['video']
                if video_file and video_file.filename:
                    video_url, message = save_file(video_file, 'exercises')
                    if not video_url:
                        flash(f'خطأ في رفع الفيديو: {message}', 'danger')
                        return redirect(request.url)
            
            if not name:
                flash('يرجى إدخال اسم التمرين', 'danger')
                return redirect(url_for('admin.add_exercise'))
            
            # Create exercise
            exercise = Exercise(
                name=name,
                description=description,
                muscle_group=muscle_group,
                difficulty=difficulty,
                instructions=instructions,
                image_url=image_url,
                video_url=video_url
            )
            
            db.session.add(exercise)
            db.session.commit()
            
            flash('تم إضافة التمرين بنجاح!', 'success')
            return redirect(url_for('admin.exercises'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'خطأ في إضافة التمرين: {str(e)}', 'danger')
    
    return render_template('admin/add_exercise.html', 
                          title='إضافة تمرين جديد | GymPro Arabic')

@admin_bp.route('/exercises/<int:exercise_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_exercise(exercise_id):
    """Edit an exercise."""
    exercise = Exercise.query.get_or_404(exercise_id)
    
    if request.method == 'POST':
        exercise.name = request.form.get('name')
        exercise.description = request.form.get('description')
        exercise.muscle_group = request.form.get('muscle_group')
        exercise.difficulty = request.form.get('difficulty')
        exercise.instructions = request.form.get('instructions')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'exercises')
            if result:
                exercise.image_url = result
            else:
                flash(message, 'danger')
        else:
            # Keep existing URL or update from text field
            new_image_url = request.form.get('image_url')
            if new_image_url:
                exercise.image_url = new_image_url
        
        # Handle video upload
        if 'video_file' in request.files and request.files['video_file'].filename != '':
            video_file = request.files['video_file']
            result, message = save_file(video_file, 'exercises', max_size_mb=50)
            if result:
                exercise.video_url = result
            else:
                flash(message, 'danger')
        else:
            # Keep existing URL or update from text field
            new_video_url = request.form.get('video_url')
            if new_video_url:
                exercise.video_url = new_video_url
        
        db.session.commit()
        
        flash(f'تم تحديث التمرين {exercise.name} بنجاح', 'success')
        return redirect(url_for('admin.exercises'))
    
    return render_template('admin/edit_exercise.html', 
                          title='تعديل تمرين | GymPro Arabic',
                          exercise=exercise)

@admin_bp.route('/exercises/<int:exercise_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_exercise(exercise_id):
    """Delete an exercise."""
    exercise = Exercise.query.get_or_404(exercise_id)
    
    db.session.delete(exercise)
    db.session.commit()
    
    flash(f'تم حذف التمرين {exercise.name} بنجاح', 'success')
    return redirect(url_for('admin.exercises'))

@admin_bp.route('/tips')
@login_required
@admin_required
def tips():
    """Manage tips."""
    tips = Tip.query.all()
    return render_template('admin/tips.html', 
                          title='إدارة النصائح | GymPro Arabic',
                          tips=tips)

@admin_bp.route('/tips/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_tip():
    """Add a new tip."""
    if request.method == 'POST':
        title = request.form.get('title')
        content = request.form.get('content')
        category = request.form.get('category')
        summary = request.form.get('summary')
        tags = request.form.get('tags')
        is_featured = 'is_featured' in request.form
        image_url = request.form.get('image_url')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'tips')
            if result:
                image_url = result
            else:
                flash(message, 'danger')
        elif not image_url:
            # If no file was uploaded and no URL was provided, use a default image or leave empty
            image_url = ''
        
        if not title or not content:
            flash('يرجى إدخال العنوان والمحتوى', 'danger')
            return redirect(url_for('admin.add_tip'))
        
        tip = Tip(
            title=title,
            content=content,
            category=category,
            summary=summary,
            tags=tags,
            is_featured=is_featured,
            image_url=image_url
        )
        
        db.session.add(tip)
        db.session.commit()
        
        flash(f'تم إضافة النصيحة {title} بنجاح', 'success')
        return redirect(url_for('admin.tips'))
    
    return render_template('admin/add_tip.html', 
                          title='إضافة نصيحة جديدة | GymPro Arabic')

@admin_bp.route('/tips/<int:tip_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_tip(tip_id):
    """Edit a tip."""
    tip = Tip.query.get_or_404(tip_id)
    
    if request.method == 'POST':
        tip.title = request.form.get('title')
        tip.content = request.form.get('content')
        tip.category = request.form.get('category')
        tip.summary = request.form.get('summary')
        tip.tags = request.form.get('tags')
        tip.is_featured = 'is_featured' in request.form
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'tips')
            if result:
                tip.image_url = result
            else:
                flash(message, 'danger')
        else:
            # Keep existing URL or update from text field
            new_image_url = request.form.get('image_url')
            if new_image_url:
                tip.image_url = new_image_url
        
        db.session.commit()
        
        flash(f'تم تحديث النصيحة {tip.title} بنجاح', 'success')
        return redirect(url_for('admin.tips'))
    
    return render_template('admin/edit_tip.html', 
                          title='تعديل نصيحة | GymPro Arabic',
                          tip=tip)

@admin_bp.route('/tips/<int:tip_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_tip(tip_id):
    """Delete a tip."""
    tip = Tip.query.get_or_404(tip_id)
    
    db.session.delete(tip)
    db.session.commit()
    
    flash(f'تم حذف النصيحة {tip.title} بنجاح', 'success')
    return redirect(url_for('admin.tips'))

@admin_bp.route('/supplements')
@login_required
@admin_required
def supplements():
    """Manage supplements."""
    supplements = Supplement.query.all()
    return render_template('admin/supplements.html', 
                          title='إدارة المكملات الغذائية | GymPro Arabic',
                          supplements=supplements)

@admin_bp.route('/supplements/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_supplement():
    """Add a new supplement."""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        supplement_type = request.form.get('type')
        benefits = request.form.get('benefits')
        recommended_dosage = request.form.get('dosage')
        when_to_take = request.form.get('usage')
        # price and order are not in the model
        # price = request.form.get('price')
        # order = request.form.get('order')
        # is_featured is not in the model
        # is_featured = 'is_featured' in request.form
        image_url = request.form.get('image_url')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'supplements')
            if result:
                image_url = result
            else:
                flash(message, 'danger')
        elif not image_url:
            # If no file was uploaded and no URL was provided, use a default image or leave empty
            image_url = ''
        
        if not name or not description:
            flash('يرجى إدخال اسم ووصف المكمل الغذائي', 'danger')
            return redirect(url_for('admin.add_supplement'))
        
        supplement = Supplement(
            name=name,
            description=description,
            supplement_type=supplement_type,
            benefits=benefits,
            recommended_dosage=recommended_dosage,
            when_to_take=when_to_take,
            image_url=image_url
        )
        
        db.session.add(supplement)
        db.session.commit()
        
        flash(f'تم إضافة المكمل الغذائي {name} بنجاح', 'success')
        return redirect(url_for('admin.supplements'))
    
    return render_template('admin/add_supplement.html', 
                          title='إضافة مكمل غذائي جديد | GymPro Arabic')

@admin_bp.route('/supplements/<int:supplement_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_supplement(supplement_id):
    """Edit a supplement."""
    supplement = Supplement.query.get_or_404(supplement_id)
    
    if request.method == 'POST':
        supplement.name = request.form.get('name')
        supplement.description = request.form.get('description')
        supplement.supplement_type = request.form.get('type')
        supplement.benefits = request.form.get('benefits')
        supplement.recommended_dosage = request.form.get('dosage')
        supplement.when_to_take = request.form.get('usage')
        # is_featured is not in the model
        # supplement.is_featured = 'is_featured' in request.form
        
        # These fields are not in the model, so we'll ignore them
        # price = request.form.get('price')
        # order = request.form.get('order')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'supplements')
            if result:
                supplement.image_url = result
            else:
                flash(message, 'danger')
        else:
            # Keep existing URL or update from text field
            new_image_url = request.form.get('image_url')
            if new_image_url:
                supplement.image_url = new_image_url
        
        db.session.commit()
        
        flash(f'تم تحديث المكمل الغذائي {supplement.name} بنجاح', 'success')
        return redirect(url_for('admin.supplements'))
    
    return render_template('admin/edit_supplement.html', 
                          title='تعديل مكمل غذائي | GymPro Arabic',
                          supplement=supplement)

@admin_bp.route('/supplements/<int:supplement_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_supplement(supplement_id):
    """Delete a supplement."""
    supplement = Supplement.query.get_or_404(supplement_id)
    
    db.session.delete(supplement)
    db.session.commit()
    
    flash(f'تم حذف المكمل الغذائي {supplement.name} بنجاح', 'success')
    return redirect(url_for('admin.supplements'))

@admin_bp.route('/messages')
@login_required
@admin_required
def messages():
    """View contact messages."""
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('admin/messages.html', 
                          title='الرسائل الواردة | GymPro Arabic',
                          messages=messages)

@admin_bp.route('/messages/<int:message_id>/toggle_read', methods=['POST'])
@login_required
@admin_required
def toggle_message_read(message_id):
    """Toggle read status for a message."""
    message = ContactMessage.query.get_or_404(message_id)
    
    message.is_read = not message.is_read
    db.session.commit()
    
    flash('تم تحديث حالة الرسالة بنجاح', 'success')
    return redirect(url_for('admin.messages'))

@admin_bp.route('/messages/<int:message_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_message(message_id):
    """Delete a message."""
    message = ContactMessage.query.get_or_404(message_id)
    
    db.session.delete(message)
    db.session.commit()
    
    flash('تم حذف الرسالة بنجاح', 'success')
    return redirect(url_for('admin.messages'))

@admin_bp.route('/upload-image', methods=['POST'])
@login_required
@admin_required
def upload_image():
    """Upload an image from the WYSIWYG editor."""
    if 'file' not in request.files:
        return jsonify({'error': 'لا يوجد ملف مرفق'}), 400
        
    file = request.files['file']
    section = request.form.get('section', 'images')
    
    if file.filename == '':
        return jsonify({'error': 'لم يتم اختيار ملف'}), 400
        
    # Save the file
    result, message = save_file(file, section, max_size_mb=5)
    if not result:
        return jsonify({'error': message}), 400
    
    return jsonify({'url': result, 'success': True})

@admin_bp.route('/upload-video', methods=['POST'])
@login_required
@admin_required
def upload_video():
    """Upload a video file."""
    if 'video' not in request.files:
        return jsonify({'error': 'لا يوجد ملف مرفق'}), 400
        
    file = request.files['video']
    section = request.form.get('section', 'videos')
    
    if file.filename == '':
        return jsonify({'error': 'لم يتم اختيار ملف'}), 400
        
    # Save the file
    result, message = save_file(file, section, max_size_mb=50)
    if not result:
        return jsonify({'error': message}), 400
    
    return jsonify({'url': result, 'filename': os.path.basename(result), 'success': True})

@admin_bp.route('/update-order', methods=['POST'])
@login_required
@admin_required
def update_order():
    """Update the display order of items."""
    data = request.json
    
    if not data or 'items' not in data or 'model' not in data:
        return jsonify({'error': 'Invalid data'}), 400
    
    items = data['items']
    model_name = data['model']
    
    # Map model names to actual models
    models = {
        'exercise': Exercise,
        'workout': Workout,
        'diet_plan': DietPlan,
        'tip': Tip,
        'supplement': Supplement
    }
    
    if model_name not in models:
        return jsonify({'error': 'Invalid model'}), 400
    
    model = models[model_name]
    
    # Update order for each item
    for item_data in items:
        item_id = item_data.get('id')
        order = item_data.get('order')
        
        if item_id and order is not None:
            item = model.query.get(item_id)
            if item:
                item.display_order = order
    
    db.session.commit()
    
    return jsonify({'success': True})

@admin_bp.route('/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def settings():
    """Admin settings page."""
    # Initialize default settings if they don't exist
    initialize_settings()
    
    if request.method == 'POST':
        form_type = request.form.get('form_type', 'general')
        
        if form_type == 'general':
            # Update general settings
            site_name = request.form.get('site_name')
            site_description = request.form.get('site_description')
            contact_email = request.form.get('contact_email')
            social_facebook = request.form.get('social_facebook')
            social_instagram = request.form.get('social_instagram')
            social_twitter = request.form.get('social_twitter')
            social_youtube = request.form.get('social_youtube')
            
            Settings.set('site_name', site_name)
            Settings.set('site_description', site_description)
            Settings.set('contact_email', contact_email)
            Settings.set('social_facebook', social_facebook)
            Settings.set('social_instagram', social_instagram)
            Settings.set('social_twitter', social_twitter)
            Settings.set('social_youtube', social_youtube)
            
            flash('تم حفظ الإعدادات العامة بنجاح', 'success')
            
        elif form_type == 'appearance':
            # Update appearance settings
            primary_color = request.form.get('primary_color')
            secondary_color = request.form.get('secondary_color')
            enable_dark_mode = 'true' if request.form.get('enable_dark_mode') else 'false'
            
            Settings.set('primary_color', primary_color)
            Settings.set('secondary_color', secondary_color)
            Settings.set('enable_dark_mode', enable_dark_mode)
            
            flash('تم حفظ إعدادات المظهر بنجاح', 'success')
            
        elif form_type == 'logo':
            # Update logo URL
            logo_url = request.form.get('logo_url')
            if logo_url:
                Settings.set('logo_url', logo_url)
            
            # For AJAX requests, return JSON response
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': True})
            
            flash('تم تحديث شعار الموقع بنجاح', 'success')
        
        # For normal form submissions, redirect to settings page
        if not request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return redirect(url_for('admin.settings'))
        else:
            return jsonify({'success': True})
    
    # Get all settings
    settings_dict = Settings.get_all()
    
    # Convert settings to object for template access
    class SettingsObject:
        pass
    
    settings_obj = SettingsObject()
    for key, value in settings_dict.items():
        setattr(settings_obj, key, value)
    
    return render_template('admin/settings.html', 
                          title='إعدادات الموقع | GymPro Arabic',
                          settings=settings_obj)

@admin_bp.route('/clear-cache', methods=['POST'])
@login_required
@admin_required
def clear_cache():
    """Clear cache files."""
    try:
        # Clear Flask-Caching cache if used
        # cache.clear()
        
        # Or clear file-based cache directory
        cache_dir = os.path.join(current_app.static_folder, 'cache')
        if os.path.exists(cache_dir):
            for file in os.listdir(cache_dir):
                file_path = os.path.join(cache_dir, file)
                try:
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/create-backup', methods=['POST'])
@login_required
@admin_required
def create_backup():
    """Create a database backup."""
    try:
        # Get database URI from config
        db_uri = current_app.config['SQLALCHEMY_DATABASE_URI']
        
        if 'sqlite' in db_uri:
            # For SQLite, just copy the file
            import shutil
            db_path = db_uri.replace('sqlite:///', '')
            if not os.path.isabs(db_path):
                db_path = os.path.join(current_app.root_path, '..', db_path)
            
            # Create backups directory if it doesn't exist
            backup_dir = os.path.join(current_app.root_path, '..', 'backups')
            os.makedirs(backup_dir, exist_ok=True)
            
            # Create backup filename with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = os.path.join(backup_dir, f'gym_pro_backup_{timestamp}.db')
            
            # Copy database file
            shutil.copy2(db_path, backup_file)
            
            return jsonify({'success': True, 'file': backup_file})
        else:
            # For other databases, more complex backup would be needed
            # This is a simplified example
            return jsonify({'success': True, 'message': 'Backup functionality is not implemented for non-SQLite databases'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/media-library')
@login_required
@admin_required
def media_library():
    """Media library page."""
    # Get all media files
    images_dir = os.path.join(current_app.static_folder, 'uploads', 'images')
    videos_dir = os.path.join(current_app.static_folder, 'uploads', 'videos')
    
    images = []
    videos = []
    
    if os.path.exists(images_dir):
        for file in os.listdir(images_dir):
            if os.path.isfile(os.path.join(images_dir, file)) and file.lower().endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp')):
                file_path = os.path.join(images_dir, file)
                file_size = os.path.getsize(file_path) / 1024  # Size in KB
                file_date = datetime.fromtimestamp(os.path.getmtime(file_path))
                
                images.append({
                    'name': file,
                    'url': url_for('static', filename=f'uploads/images/{file}'),
                    'size': file_size,
                    'date': file_date
                })
    
    if os.path.exists(videos_dir):
        for file in os.listdir(videos_dir):
            if os.path.isfile(os.path.join(videos_dir, file)) and file.lower().endswith(('.mp4', '.webm', '.ogg')):
                file_path = os.path.join(videos_dir, file)
                file_size = os.path.getsize(file_path) / 1024 / 1024  # Size in MB
                file_date = datetime.fromtimestamp(os.path.getmtime(file_path))
                
                videos.append({
                    'name': file,
                    'url': url_for('static', filename=f'uploads/videos/{file}'),
                    'size': file_size,
                    'date': file_date
                })
    
    return render_template('admin/media_library.html',
                          title='مكتبة الوسائط | GymPro Arabic',
                          images=sorted(images, key=lambda x: x['date'], reverse=True),
                          videos=sorted(videos, key=lambda x: x['date'], reverse=True))

@admin_bp.route('/delete-media', methods=['POST'])
@login_required
@admin_required
def delete_media():
    """Delete an uploaded media file."""
    data = request.json
    
    if not data or 'filename' not in data or 'type' not in data:
        return jsonify({'error': 'Invalid data'}), 400
    
    filename = data['filename']
    media_type = data['type']  # 'image' or 'video'
    
    if not filename or not media_type:
        return jsonify({'error': 'Invalid filename or type'}), 400
    
    # Sanitize filename to prevent directory traversal
    filename = os.path.basename(filename)
    
    # Determine the path based on media type
    if media_type == 'image':
        file_path = os.path.join(current_app.static_folder, 'uploads', 'images', filename)
    elif media_type == 'video':
        file_path = os.path.join(current_app.static_folder, 'uploads', 'videos', filename)
    else:
        return jsonify({'error': 'Invalid media type'}), 400
    
    # Check if file exists
    if not os.path.exists(file_path):
        return jsonify({'error': 'File not found'}), 404
    
    # Delete the file
    try:
        os.remove(file_path)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Helper functions for media uploads
def allowed_file(filename, file_type='image'):
    """Check if the uploaded file is an allowed type with enhanced validation."""
    if not filename or '.' not in filename:
        return False
        
    # Get file extension
    extension = filename.rsplit('.', 1)[1].lower()
    
    if file_type == 'image':
        allowed_extensions = {'jpg', 'jpeg', 'png', 'gif', 'webp'}
    elif file_type == 'video':
        allowed_extensions = {'mp4', 'avi', 'mov', 'wmv'}
    else:
        return False
        
    return extension in allowed_extensions

def save_file(file, section, max_size_mb=10):
    """Save an uploaded file with enhanced validation and error handling."""
    if not file or file.filename == '':
        return None, "لم يتم اختيار ملف"
    
    # Check file size (convert MB to bytes)
    file.seek(0, 2)  # Seek to end of file
    file_size = file.tell()
    file.seek(0)  # Reset to beginning
    
    if file_size > max_size_mb * 1024 * 1024:
        return None, f"حجم الملف كبير جداً. الحد الأقصى {max_size_mb} ميجابايت"
    
    # Determine file type
    file_type = 'video' if file.filename.lower().endswith(('.mp4', '.avi', '.mov', '.wmv')) else 'image'
    
    # Check if file type is allowed
    if not allowed_file(file.filename, file_type):
        return None, "نوع الملف غير مدعوم"
    
    try:
        # Generate unique filename
        filename = secure_filename(file.filename)
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        
        # Ensure upload directory exists
        upload_folder = os.path.join(current_app.static_folder, 'uploads', section)
        os.makedirs(upload_folder, exist_ok=True)
        
        # Save the file
        file_path = os.path.join(upload_folder, unique_filename)
        file.save(file_path)
        
        # Return URL for the uploaded file
        return url_for('static', filename=f'uploads/{section}/{unique_filename}'), "تم رفع الملف بنجاح"
        
    except Exception as e:
        return None, f"خطأ في رفع الملف: {str(e)}"

@admin_bp.route('/workouts')
@login_required
@admin_required
def workouts():
    """Manage workouts."""
    from app.models.workout import Workout
    
    # Get filter parameters
    search = request.args.get('search', '')
    target_muscle = request.args.get('target_muscle', '')
    difficulty = request.args.get('difficulty', '')
    
    # Base query
    query = Workout.query
    
    # Apply filters
    if search:
        query = query.filter(Workout.name.like(f'%{search}%'))
    if target_muscle:
        query = query.filter(Workout.target_muscle == target_muscle)
    if difficulty:
        query = query.filter(Workout.difficulty == difficulty)
    
    # Get workouts
    workouts = query.order_by(Workout.order).all()
    
    return render_template('admin/workouts.html', 
                          title='إدارة التمارين | GymPro Arabic',
                          workouts=workouts)

@admin_bp.route('/workouts/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_workout():
    """Add a new workout."""
    from app.models.workout import Workout
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        target_muscle = request.form.get('target_muscle')
        difficulty = request.form.get('difficulty')
        instructions = request.form.get('instructions')
        equipment = request.form.get('equipment')
        calories_burned = request.form.get('calories_burned')
        order = request.form.get('order', 1)
        is_featured = 'is_featured' in request.form
        
        # Handle image upload
        image_url = None
        if 'image' in request.files and request.files['image'].filename:
            image_file = request.files['image']
            result, message = save_file(image_file, 'images')
            if result:
                image_url = result.replace('/static/', '')
            else:
                flash(message, 'danger')
        
        # Handle video upload
        video_url = None
        if 'video' in request.files and request.files['video'].filename:
            video_file = request.files['video']
            result, message = save_file(video_file, 'videos', max_size_mb=50)
            if result:
                video_url = result.replace('/static/', '')
            else:
                flash(message, 'danger')
        
        if not name:
            flash('يرجى إدخال اسم التمرين', 'danger')
            return redirect(url_for('admin.add_workout'))
        
        # Get the highest order value
        max_order = db.session.query(db.func.max(Workout.order)).scalar() or 0
        
        workout = Workout(
            name=name,
            description=description,
            target_muscle=target_muscle,
            difficulty=difficulty,
            instructions=instructions,
            equipment=equipment,
            calories_burned=calories_burned,
            image_url=image_url,
            video_url=video_url,
            order=order if order else max_order + 1,
            is_featured=is_featured
        )
        
        db.session.add(workout)
        db.session.commit()
        
        flash(f'تم إضافة التمرين {name} بنجاح', 'success')
        return redirect(url_for('admin.workouts'))
    
    return render_template('admin/add_workout.html', 
                          title='إضافة تمرين جديد | GymPro Arabic')

@admin_bp.route('/workouts/<int:workout_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_workout(workout_id):
    """Edit a workout."""
    from app.models.workout import Workout
    workout = Workout.query.get_or_404(workout_id)
    
    if request.method == 'POST':
        workout.name = request.form.get('name')
        workout.description = request.form.get('description')
        workout.target_muscle = request.form.get('target_muscle')
        workout.difficulty = request.form.get('difficulty')
        workout.instructions = request.form.get('instructions')
        workout.equipment = request.form.get('equipment')
        workout.calories_burned = request.form.get('calories_burned')
        workout.order = request.form.get('order', workout.order)
        workout.is_featured = 'is_featured' in request.form
        
        # Handle image upload
        if 'image' in request.files and request.files['image'].filename:
            image_file = request.files['image']
            result, message = save_file(image_file, 'images')
            if result:
                workout.image_url = result.replace('/static/', '')
            else:
                flash(message, 'danger')
        
        # Handle video upload
        if 'video' in request.files and request.files['video'].filename:
            video_file = request.files['video']
            result, message = save_file(video_file, 'videos', max_size_mb=50)
            if result:
                workout.video_url = result.replace('/static/', '')
            else:
                flash(message, 'danger')
        
        db.session.commit()
        
        flash(f'تم تحديث التمرين {workout.name} بنجاح', 'success')
        return redirect(url_for('admin.workouts'))
    
    return render_template('admin/edit_workout.html', 
                          title='تعديل تمرين | GymPro Arabic',
                          workout=workout)

@admin_bp.route('/workouts/<int:workout_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_workout(workout_id):
    """Delete a workout."""
    from app.models.workout import Workout
    workout = Workout.query.get_or_404(workout_id)
    
    # Delete associated image and video files if they exist
    if workout.image_url:
        image_path = os.path.join(current_app.static_folder, workout.image_url)
        if os.path.exists(image_path):
            os.remove(image_path)
    
    if workout.video_url:
        video_path = os.path.join(current_app.static_folder, workout.video_url)
        if os.path.exists(video_path):
            os.remove(video_path)
    
    db.session.delete(workout)
    db.session.commit()
    
    flash(f'تم حذف التمرين {workout.name} بنجاح', 'success')
    return redirect(url_for('admin.workouts'))

@admin_bp.route('/diet-plans')
@login_required
@admin_required
def diet_plans():
    """Manage diet plans."""
    diet_plans = DietPlan.query.all()
    return render_template('admin/diet_plans.html', 
                          title='إدارة خطط التغذية | GymPro Arabic',
                          diet_plans=diet_plans)

@admin_bp.route('/diet-plans/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_diet_plan():
    """Add a new diet plan."""
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        calories = request.form.get('calories')
        protein = request.form.get('protein')
        carbs = request.form.get('carbs')
        fat = request.form.get('fat')
        duration = request.form.get('duration')
        target = request.form.get('target')
        image_url = request.form.get('image_url')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'diet-plans')
            if result:
                image_url = result
            else:
                flash(message, 'danger')
        
        if not name or not description:
            flash('يرجى إدخال اسم ووصف الخطة الغذائية', 'danger')
            return redirect(url_for('admin.add_diet_plan'))
        
        diet_plan = DietPlan(
            name=name,
            description=description,
            calories=calories,
            protein=protein,
            carbs=carbs,
            fat=fat,
            duration=duration,
            target=target,
            image_url=image_url
        )
        
        db.session.add(diet_plan)
        db.session.commit()
        
        flash(f'تم إضافة الخطة الغذائية {name} بنجاح', 'success')
        return redirect(url_for('admin.diet_plans'))
    
    return render_template('admin/add_diet_plan.html', 
                          title='إضافة خطة غذائية جديدة | GymPro Arabic')

@admin_bp.route('/diet-plans/<int:diet_plan_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_diet_plan(diet_plan_id):
    """Edit a diet plan."""
    diet_plan = DietPlan.query.get_or_404(diet_plan_id)
    
    if request.method == 'POST':
        diet_plan.name = request.form.get('name')
        diet_plan.description = request.form.get('description')
        diet_plan.calories = request.form.get('calories')
        diet_plan.protein = request.form.get('protein')
        diet_plan.carbs = request.form.get('carbs')
        diet_plan.fat = request.form.get('fat')
        diet_plan.duration = request.form.get('duration')
        diet_plan.target = request.form.get('target')
        
        # Handle image upload
        if 'image_file' in request.files and request.files['image_file'].filename != '':
            image_file = request.files['image_file']
            result, message = save_file(image_file, 'diet-plans')
            if result:
                diet_plan.image_url = result
            else:
                flash(message, 'danger')
        else:
            # Keep existing URL or update from text field
            new_image_url = request.form.get('image_url')
            if new_image_url:
                diet_plan.image_url = new_image_url
        
        db.session.commit()
        
        flash(f'تم تحديث الخطة الغذائية {diet_plan.name} بنجاح', 'success')
        return redirect(url_for('admin.diet_plans'))
    
    return render_template('admin/edit_diet_plan.html', 
                          title='تعديل خطة غذائية | GymPro Arabic',
                          diet_plan=diet_plan)

@admin_bp.route('/diet-plans/<int:diet_plan_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_diet_plan(diet_plan_id):
    """Delete a diet plan."""
    diet_plan = DietPlan.query.get_or_404(diet_plan_id)
    
    db.session.delete(diet_plan)
    db.session.commit()
    
    flash(f'تم حذف الخطة الغذائية {diet_plan.name} بنجاح', 'success')
    return redirect(url_for('admin.diet_plans'))

@admin_bp.route('/calculators')
@login_required
@admin_required
def calculators():
    """Manage fitness calculators."""
    from app.models.calculator import Calculator
    calculators = Calculator.query.order_by(Calculator.order).all()
    return render_template('admin/calculators.html', 
                          title='إدارة الحاسبات | GymPro Arabic',
                          calculators=calculators)

@admin_bp.route('/calculators/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_calculator():
    """Add a new calculator."""
    from app.models.calculator import Calculator
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        icon = request.form.get('icon')
        url_slug = request.form.get('url_slug')
        type = request.form.get('type')
        formula = request.form.get('formula')
        instructions = request.form.get('instructions')
        order = request.form.get('order', 0)
        is_active = True if request.form.get('is_active') else False
        
        if not name or not url_slug or not type:
            flash('يرجى إدخال اسم ونوع ورابط الحاسبة', 'danger')
            return redirect(url_for('admin.add_calculator'))
        
        # Check if URL slug is unique
        existing_calculator = Calculator.query.filter_by(url_slug=url_slug).first()
        if existing_calculator:
            flash('الرابط المختصر مستخدم بالفعل، يرجى اختيار رابط آخر', 'danger')
            return redirect(url_for('admin.add_calculator'))
        
        calculator = Calculator(
            name=name,
            description=description,
            icon=icon,
            url_slug=url_slug,
            type=type,
            formula=formula,
            instructions=instructions,
            order=order,
            is_active=is_active
        )
        
        db.session.add(calculator)
        db.session.commit()
        
        flash(f'تم إضافة الحاسبة {name} بنجاح', 'success')
        return redirect(url_for('admin.calculators'))
    
    return render_template('admin/add_calculator.html', 
                          title='إضافة حاسبة جديدة | GymPro Arabic')

@admin_bp.route('/calculators/<int:calculator_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_calculator(calculator_id):
    """Edit a calculator."""
    from app.models.calculator import Calculator
    calculator = Calculator.query.get_or_404(calculator_id)
    
    if request.method == 'POST':
        calculator.name = request.form.get('name')
        calculator.description = request.form.get('description')
        calculator.icon = request.form.get('icon')
        new_url_slug = request.form.get('url_slug')
        calculator.type = request.form.get('type')
        calculator.formula = request.form.get('formula')
        calculator.instructions = request.form.get('instructions')
        calculator.order = request.form.get('order', 0)
        calculator.is_active = True if request.form.get('is_active') else False
        
        # Check if URL slug is changed and if it's unique
        if new_url_slug != calculator.url_slug:
            existing_calculator = Calculator.query.filter_by(url_slug=new_url_slug).first()
            if existing_calculator:
                flash('الرابط المختصر مستخدم بالفعل، يرجى اختيار رابط آخر', 'danger')
                return redirect(url_for('admin.edit_calculator', calculator_id=calculator.id))
            calculator.url_slug = new_url_slug
        
        db.session.commit()
        
        flash(f'تم تحديث الحاسبة {calculator.name} بنجاح', 'success')
        return redirect(url_for('admin.calculators'))
    
    return render_template('admin/edit_calculator.html', 
                          title='تعديل حاسبة | GymPro Arabic',
                          calculator=calculator)

@admin_bp.route('/calculators/<int:calculator_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_calculator(calculator_id):
    """Delete a calculator."""
    from app.models.calculator import Calculator
    calculator = Calculator.query.get_or_404(calculator_id)
    
    db.session.delete(calculator)
    db.session.commit()
    
    flash(f'تم حذف الحاسبة {calculator.name} بنجاح', 'success')
    return redirect(url_for('admin.calculators'))

# Duplicate delete_calculator function removed to fix endpoint conflict

# Exercise Tutorials Management
@admin_bp.route('/tutorials')
@login_required
@admin_required
def tutorials():
    """Manage exercise tutorials."""
    tutorials = ExerciseTutorial.query.order_by(ExerciseTutorial.muscle_group, ExerciseTutorial.order).all()
    
    # Group tutorials by muscle group
    tutorials_by_group = {}
    for tutorial in tutorials:
        if tutorial.muscle_group not in tutorials_by_group:
            tutorials_by_group[tutorial.muscle_group] = []
        tutorials_by_group[tutorial.muscle_group].append(tutorial)
    
    # Define muscle group names in Arabic
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    return render_template(
        'admin/tutorials.html',
        title='إدارة شروحات التمارين | GymPro Arabic',
        tutorials_by_group=tutorials_by_group,
        muscle_groups=muscle_groups
    )

@admin_bp.route('/videos')
@login_required
@admin_required
def videos():
    """Manage videos in the system."""
    # Get all tutorial videos
    tutorials = ExerciseTutorial.query.order_by(ExerciseTutorial.created_at.desc()).all()
    
    # Group videos by type (YouTube/MP4)
    youtube_videos = [t for t in tutorials if t.video_type == 'youtube']
    mp4_videos = [t for t in tutorials if t.video_type == 'mp4']
    
    # Define muscle group names in Arabic
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    return render_template(
        'admin/videos.html',
        title='إدارة الفيديوهات | GymPro Arabic',
        youtube_videos=youtube_videos,
        mp4_videos=mp4_videos,
        muscle_groups=muscle_groups,
        tutorials_count=len(tutorials),
        youtube_count=len(youtube_videos),
        mp4_count=len(mp4_videos)
    )

@admin_bp.route('/tutorials/add', methods=['GET', 'POST'])
@login_required
@admin_required
def add_tutorial():
    """Add a new exercise tutorial."""
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        muscle_group = request.form.get('muscle_group')
        reps_range = request.form.get('reps_range')
        tips = request.form.get('tips')
        video_url = request.form.get('video_url')
        video_type = request.form.get('video_type', 'youtube')
        thumbnail_url = request.form.get('thumbnail_url')
        
        # Validate required fields
        if not title or not muscle_group:
            flash('يرجى إدخال عنوان ومجموعة العضلات', 'danger')
            return redirect(url_for('admin.add_tutorial'))
        
        # Handle thumbnail upload
        if 'thumbnail_file' in request.files and request.files['thumbnail_file'].filename != '':
            thumbnail_file = request.files['thumbnail_file']
            result, message = save_file(thumbnail_file, 'tutorials')
            if result:
                thumbnail_url = result
            else:
                flash(message, 'danger')
        
        # Handle video upload if it's an MP4 file
        if video_type == 'mp4' and 'video_file' in request.files and request.files['video_file'].filename != '':
            video_file = request.files['video_file']
            result, message = save_file(video_file, 'tutorials/videos', max_size_mb=100)
            if result:
                video_url = result
            else:
                flash(message, 'danger')
        
        # Get the highest order number for this muscle group and add 1
        highest_order = db.session.query(db.func.max(ExerciseTutorial.order)).filter(
            ExerciseTutorial.muscle_group == muscle_group
        ).scalar() or 0
        
        tutorial = ExerciseTutorial(
            title=title,
            description=description,
            muscle_group=muscle_group,
            reps_range=reps_range,
            tips=tips,
            thumbnail_url=thumbnail_url,
            video_url=video_url,
            video_type=video_type,
            order=highest_order + 1
        )
        
        db.session.add(tutorial)
        db.session.commit()
        
        flash('تم إضافة شرح التمرين بنجاح', 'success')
        return redirect(url_for('admin.tutorials'))
    
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    return render_template(
        'admin/add_tutorial.html',
        title='إضافة شرح تمرين جديد | GymPro Arabic',
        muscle_groups=muscle_groups
    )

@admin_bp.route('/tutorials/<int:tutorial_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_tutorial(tutorial_id):
    """Edit an exercise tutorial."""
    tutorial = ExerciseTutorial.query.get_or_404(tutorial_id)
    
    if request.method == 'POST':
        tutorial.title = request.form.get('title')
        tutorial.description = request.form.get('description')
        tutorial.muscle_group = request.form.get('muscle_group')
        tutorial.reps_range = request.form.get('reps_range')
        tutorial.tips = request.form.get('tips')
        tutorial.video_type = request.form.get('video_type', 'youtube')
        
        # Handle thumbnail upload
        if 'thumbnail_file' in request.files and request.files['thumbnail_file'].filename != '':
            thumbnail_file = request.files['thumbnail_file']
            result, message = save_file(thumbnail_file, 'tutorials')
            if result:
                tutorial.thumbnail_url = result
            else:
                flash(message, 'danger')
        else:
            new_thumbnail_url = request.form.get('thumbnail_url')
            if new_thumbnail_url:
                tutorial.thumbnail_url = new_thumbnail_url
        
        # Handle video upload if it's an MP4 file
        if tutorial.video_type == 'mp4' and 'video_file' in request.files and request.files['video_file'].filename != '':
            video_file = request.files['video_file']
            result, message = save_file(video_file, 'tutorials/videos', max_size_mb=100)
            if result:
                tutorial.video_url = result
            else:
                flash(message, 'danger')
        else:
            new_video_url = request.form.get('video_url')
            if new_video_url:
                tutorial.video_url = new_video_url
        
        db.session.commit()
        
        flash('تم تحديث شرح التمرين بنجاح', 'success')
        return redirect(url_for('admin.tutorials'))
    
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    return render_template(
        'admin/edit_tutorial.html',
        title='تعديل شرح التمرين | GymPro Arabic',
        tutorial=tutorial,
        muscle_groups=muscle_groups
    )

@admin_bp.route('/tutorials/<int:tutorial_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_tutorial(tutorial_id):
    """Delete an exercise tutorial."""
    tutorial = ExerciseTutorial.query.get_or_404(tutorial_id)
    
    db.session.delete(tutorial)
    db.session.commit()
    
    flash('تم حذف شرح التمرين بنجاح', 'success')
    return redirect(url_for('admin.tutorials'))
