from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, SelectField, IntegerField, FloatField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional, ValidationError
from app.models.user import User

class BaseForm(FlaskForm):
    """النموذج الأساسي مع إعدادات CSRF محسنة."""
    class Meta:
        csrf = True
        csrf_time_limit = 3600  # 1 hour
        csrf_error_message = "خطأ في تأمين النموذج. يرجى تحديث الصفحة والمحاولة مرة أخرى."

class LoginForm(BaseForm):
    """نموذج تسجيل الدخول."""
    username = StringField('اسم المستخدم', validators=[DataRequired(message='يرجى إدخال اسم المستخدم')])
    password = PasswordField('كلمة المرور', validators=[DataRequired(message='يرجى إدخال كلمة المرور')])
    remember_me = BooleanField('تذكرني')
    submit = SubmitField('تسجيل الدخول')

class RegisterForm(BaseForm):
    """نموذج تسجيل مستخدم جديد."""
    username = StringField('اسم المستخدم', validators=[
        DataRequired(message='يرجى إدخال اسم المستخدم'),
        Length(min=3, max=25, message='يجب أن يكون اسم المستخدم بين 3 و 25 حرفًا')
    ])
    email = StringField('البريد الإلكتروني', validators=[
        DataRequired(message='يرجى إدخال البريد الإلكتروني'),
        Email(message='يرجى إدخال بريد إلكتروني صحيح')
    ])
    password = PasswordField('كلمة المرور', validators=[
        DataRequired(message='يرجى إدخال كلمة المرور'),
        Length(min=6, message='يجب أن تكون كلمة المرور 6 أحرف على الأقل')
    ])
    confirm_password = PasswordField('تأكيد كلمة المرور', validators=[
        DataRequired(message='يرجى تأكيد كلمة المرور'),
        EqualTo('password', message='كلمات المرور غير متطابقة')
    ])
    submit = SubmitField('تسجيل')

    def validate_username(self, username):
        """التحقق من أن اسم المستخدم غير مستخدم بالفعل."""
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('اسم المستخدم مستخدم بالفعل، يرجى اختيار اسم آخر')

    def validate_email(self, email):
        """التحقق من أن البريد الإلكتروني غير مستخدم بالفعل."""
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('البريد الإلكتروني مستخدم بالفعل، يرجى استخدام بريد آخر')

class ProfileForm(BaseForm):
    """نموذج تعديل الملف الشخصي."""
    name = StringField('الاسم', validators=[Optional()])
    age = IntegerField('العمر', validators=[Optional()])
    gender = SelectField('الجنس', choices=[
        ('', 'اختر الجنس'),
        ('male', 'ذكر'),
        ('female', 'أنثى')
    ], validators=[Optional()])
    weight = FloatField('الوزن (كغم)', validators=[Optional()])
    height = FloatField('الطول (سم)', validators=[Optional()])
    activity_level = SelectField('مستوى النشاط', choices=[
        ('', 'اختر مستوى النشاط'),
        ('sedentary', 'خامل (قليل أو لا يوجد تمرين)'),
        ('light', 'خفيف (تمرين خفيف 1-3 أيام/أسبوع)'),
        ('moderate', 'متوسط (تمرين متوسط 3-5 أيام/أسبوع)'),
        ('active', 'نشط (تمرين قوي 6-7 أيام/أسبوع)'),
        ('very_active', 'نشط جدًا (تمرين قوي يوميًا أو تمرين مرتين يوميًا)')
    ], validators=[Optional()])
    submit = SubmitField('حفظ التغييرات')