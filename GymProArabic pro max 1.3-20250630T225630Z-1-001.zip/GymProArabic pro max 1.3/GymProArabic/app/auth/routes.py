from flask import render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from app.auth import auth_bp
from app.models.user import User
from app import db
from app.auth.forms import LoginForm, RegisterForm, ProfileForm
from urllib.parse import urlparse
from datetime import datetime
import logging

# إعداد التسجيل للتشخيص
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login route with enhanced error handling and CSRF protection."""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        try:
            username = form.username.data.strip()
            password = form.password.data
            
            logger.debug(f"Login attempt for user: {username}")
            
            # Try to find user by username or email
            user = User.query.filter(
                (User.username == username) | (User.email == username)
            ).first()
            
            if user and user.check_password(password):
                login_user(user, remember=form.remember_me.data)
                logger.debug(f"Successful login for user: {user.username}")
                
                next_page = request.args.get('next')
                if not next_page or urlparse(next_page).netloc != '':
                    next_page = url_for('admin.index') if user.is_admin else url_for('main.index')
                
                flash('تم تسجيل الدخول بنجاح!', 'success')
                return redirect(next_page)
            else:
                logger.warning(f"Failed login attempt for: {username}")
                flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'danger')
        except Exception as e:
            logger.error(f"Login error: {str(e)}")
            flash('حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى.', 'danger')
    
    # Check form errors
    if form.errors:
        logger.debug(f"Form validation errors: {form.errors}")
    
    return render_template('auth/login_dark.html', 
                         title='تسجيل الدخول | جيم برو العربية', 
                         form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    """User logout route."""
    logout_user()
    flash('تم تسجيل الخروج بنجاح', 'success')
    return redirect(url_for('main.index'))

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """User registration route."""
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = RegisterForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        
        db.session.add(user)
        db.session.commit()
        
        flash('تم التسجيل بنجاح! يمكنك الآن تسجيل الدخول.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register_dark.html', title='التسجيل | جيم برو العربية', form=form)

@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    """User profile route."""
    form = ProfileForm()
    
    if request.method == 'GET':
        # Pre-populate form with current user data
        form.name.data = current_user.name
        form.age.data = current_user.age
        form.gender.data = current_user.gender
        form.weight.data = current_user.weight
        form.height.data = current_user.height
        form.activity_level.data = current_user.activity_level
    
    if form.validate_on_submit():
        current_user.name = form.name.data
        current_user.age = form.age.data
        current_user.gender = form.gender.data
        current_user.weight = form.weight.data
        current_user.height = form.height.data
        current_user.activity_level = form.activity_level.data
        
        db.session.commit()
        
        flash('تم تحديث الملف الشخصي بنجاح!', 'success')
        return redirect(url_for('auth.profile'))
    
    return render_template('auth/profile.html', title='الملف الشخصي | GymPro Arabic', form=form)

@auth_bp.route('/csrf-example', methods=['GET'])
def csrf_example():
    """CSRF protection example page."""
    form = LoginForm()  # نستخدم نموذج تسجيل الدخول كمثال للعرض
    return render_template('auth/csrf_example.html', title='مثال على حماية CSRF | GymPro Arabic', form=form)
