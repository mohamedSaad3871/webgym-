from flask import render_template, request, jsonify, flash
from datetime import datetime
from app.calculators import calculators_bp
from flask_login import current_user

@calculators_bp.route('/')
def index():
    """Main calculators page with links to all calculators."""
    return render_template('calculators/index_dark.html', title='الحاسبات الرياضية | GymPro Arabic', now=datetime.now())

@calculators_bp.route('/bmi', methods=['GET', 'POST'])
def bmi():
    """BMI (Body Mass Index) calculator."""
    result = None
    category = None
    
    if request.method == 'POST':
        try:
            weight = float(request.form.get('weight', 0))
            height = float(request.form.get('height', 0))  # Height in cm
            
            # Validate input ranges
            if weight < 20 or weight > 300:
                flash('الرجاء إدخال وزن صحيح بين 20 و 300 كجم', 'error')
                return render_template('calculators/bmi_dark.html', title='حاسبة مؤشر كتلة الجسم | GymPro Arabic')
            
            if height < 100 or height > 250:
                flash('الرجاء إدخال طول صحيح بين 100 و 250 سم', 'error')
                return render_template('calculators/bmi_dark.html', title='حاسبة مؤشر كتلة الجسم | GymPro Arabic')
            
            # Convert height to meters for BMI calculation
            height = height / 100
            
            bmi = weight / (height * height)
            result = round(bmi, 2)
            
            # Categorize BMI result
            if bmi < 18.5:
                category = 'نقص في الوزن'
            elif 18.5 <= bmi < 25:
                category = 'وزن طبيعي'
            elif 25 <= bmi < 30:
                category = 'زيادة في الوزن'
            elif 30 <= bmi < 35:
                category = 'سمنة درجة أولى'
            elif 35 <= bmi < 40:
                category = 'سمنة درجة ثانية'
            else:
                category = 'سمنة مفرطة'
                
            flash('تم حساب مؤشر كتلة الجسم بنجاح', 'success')
            
        except (ValueError, ZeroDivisionError) as e:
            current_app.logger.error(f"Error calculating BMI: {e}")
            flash('الرجاء إدخال قيم صحيحة', 'error')
            result = None
            category = None
                
        except (ValueError, ZeroDivisionError):
            result = None
    
    return render_template('calculators/bmi_dark.html', title='حاسبة مؤشر كتلة الجسم | GymPro Arabic', 
                           result=result, category=category, now=datetime.now())

@calculators_bp.route('/bmr', methods=['GET', 'POST'])
def bmr():
    """BMR (Basal Metabolic Rate) calculator."""
    result = None
    
    if request.method == 'POST':
        try:
            weight = float(request.form.get('weight'))
            height = float(request.form.get('height'))
            age = int(request.form.get('age'))
            gender = request.form.get('gender')
            
            if gender == 'male':
                # Mifflin-St Jeor Equation for men
                bmr = 10 * weight + 6.25 * height - 5 * age + 5
            else:
                # Mifflin-St Jeor Equation for women
                bmr = 10 * weight + 6.25 * height - 5 * age - 161
                
            result = round(bmr)
                
        except ValueError:
            result = None
    
    return render_template('calculators/bmr_dark.html', title='حاسبة معدل الأيض الأساسي | GymPro Arabic', 
                           result=result, now=datetime.now())

@calculators_bp.route('/tdee', methods=['GET', 'POST'])
def tdee():
    """TDEE (Total Daily Energy Expenditure) calculator."""
    result = None
    weight_loss_mild = None
    weight_loss_moderate = None
    weight_gain_mild = None
    weight_gain_moderate = None

    if request.method == 'POST':
        try:
            weight = float(request.form.get('weight', 0))
            height = float(request.form.get('height', 0))
            age = int(request.form.get('age', 0))
            gender = request.form.get('gender')
            activity = request.form.get('activity')

            # Validate input ranges
            if not all([weight, height, age, gender, activity]):
                flash('الرجاء تعبئة جميع الحقول', 'error')
                return render_template('calculators/tdee_dark.html', title='حاسبة السعرات اليومية | GymPro Arabic')

            if weight < 20 or weight > 300:
                flash('الرجاء إدخال وزن صحيح بين 20 و 300 كجم', 'error')
                return render_template('calculators/tdee_dark.html', title='حاسبة السعرات اليومية | GymPro Arabic')
            
            if height < 100 or height > 250:
                flash('الرجاء إدخال طول صحيح بين 100 و 250 سم', 'error')
                return render_template('calculators/tdee_dark.html', title='حاسبة السعرات اليومية | GymPro Arabic')
            
            if age < 5 or age > 120:
                flash('الرجاء إدخال عمر صحيح بين 5 و 120 سنة', 'error')
                return render_template('calculators/tdee_dark.html', title='حاسبة السعرات اليومية | GymPro Arabic')
            
            # Calculate BMR first using Mifflin-St Jeor Equation
            if gender == 'male':
                bmr = 10 * weight + 6.25 * height - 5 * age + 5
            else:
                bmr = 10 * weight + 6.25 * height - 5 * age - 161
            
            # Activity multipliers
            activity_multipliers = {
                'sedentary': 1.2,  # Little or no exercise
                'light': 1.375,    # Light exercise 1-3 days/week
                'moderate': 1.55,  # Moderate exercise 3-5 days/week
                'active': 1.725,   # Hard exercise 6-7 days/week
                'very_active': 1.9 # Very hard exercise & physical job or 2x training
            }
            
            tdee = bmr * activity_multipliers.get(activity, 1.2)
            result = round(tdee)
            
            # Weight loss and gain calories
            weight_loss_mild = round(tdee - 250)
            weight_loss_moderate = round(tdee - 500)
            weight_gain_mild = round(tdee + 250)
            weight_gain_moderate = round(tdee + 500)

            flash('تم حساب السعرات الحرارية اليومية بنجاح!', 'success')

        except (ValueError, TypeError) as e:
            current_app.logger.error(f"Error in TDEE calculation: {e}")
            flash('الرجاء إدخال قيم رقمية صحيحة.', 'error')
            result = None
            weight_loss_mild = None
            weight_loss_moderate = None
            weight_gain_mild = None
            weight_gain_moderate = None

    return render_template('calculators/tdee_dark.html', title='حاسبة السعرات اليومية | GymPro Arabic',
                           result=result, now=datetime.now(),
                           weight_loss_mild=weight_loss_mild,
                           weight_loss_moderate=weight_loss_moderate,
                           weight_gain_mild=weight_gain_mild,
                           weight_gain_moderate=weight_gain_moderate)

@calculators_bp.route('/interactive')
def interactive_calculators():
    """Interactive calculators page with all calculators in one page."""
    return render_template('calculators/interactive_calculators.html', title='الحاسبات التفاعلية | GymPro Arabic', now=datetime.now())
