from flask import Blueprint

calculators_bp = Blueprint('calculators', __name__)

from app.calculators import routes
