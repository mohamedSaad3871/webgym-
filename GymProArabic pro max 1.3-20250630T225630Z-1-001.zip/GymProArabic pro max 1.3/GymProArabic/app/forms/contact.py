from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField
from wtforms.validators import DataRequired, Email, Length

class ContactForm(FlaskForm):
    """Contact form for user messages."""
    name = StringField('الاسم', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('البريد الإلكتروني', validators=[DataRequired(), Email()])
    subject = StringField('الموضوع', validators=[Length(max=200)])
    message = TextAreaField('الرسالة', validators=[DataRequired(), Length(min=10)])
    submit = SubmitField('إرسال') 