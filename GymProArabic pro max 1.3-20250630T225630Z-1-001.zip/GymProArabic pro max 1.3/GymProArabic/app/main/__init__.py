from flask import Blueprint

# Create the blueprint with the name 'main'
main_bp = Blueprint('main', __name__)

# Import routes after blueprint creation to avoid circular imports
from app.main import routes
