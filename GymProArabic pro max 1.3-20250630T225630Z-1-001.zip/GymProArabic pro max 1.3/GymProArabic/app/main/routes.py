from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, abort
from flask_login import current_user, login_required
from app.models.user import User
from app.models.contact import Contact
from app.forms.contact import ContactForm
from app import db
import os
from datetime import datetime

# Import the blueprint from __init__.py
from app.main import main_bp

# Define routes using the imported blueprint
@main_bp.route('/')
def index():
    """Homepage route."""
    return render_template('index_dark.html', title='الصفحة الرئيسية | GymPro Arabic', now=datetime.now())

@main_bp.route('/contact', methods=['GET', 'POST'])
def contact():
    """Contact page route."""
    form = ContactForm()
    if form.validate_on_submit():
        contact_message = Contact(
            name=form.name.data,
            email=form.email.data,
            subject=form.subject.data,
            message=form.message.data
        )
        db.session.add(contact_message)
        db.session.commit()
        flash('تم إرسال رسالتك بنجاح. سنرد عليك في أقرب وقت ممكن.', 'success')
        return redirect(url_for('main.contact'))
    return render_template('contact.html', title='اتصل بنا | GymPro Arabic', form=form, now=datetime.now())

@main_bp.route('/about')
def about():
    """About page route."""
    return render_template('about.html', title='من نحن | GymPro Arabic', now=datetime.now())

@main_bp.route('/responsive-demo')
def responsive_demo():
    """عرض توضيحي للتصميم المتجاوب"""
    return render_template('responsive_demo.html', title='عرض توضيحي للتصميم المتجاوب', now=datetime.now())
