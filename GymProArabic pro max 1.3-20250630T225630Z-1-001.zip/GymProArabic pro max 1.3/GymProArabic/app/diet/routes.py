from flask import render_template, request, redirect, url_for, flash, jsonify
from datetime import datetime
from app.diet import diet_bp
from app.models.diet import Food, Meal, MealFood, DietPlan, DietDay, DietMeal
from app import db
from flask_login import login_required, current_user
import random

@diet_bp.route('/')
def index():
    """Diet plan main page."""
    return render_template('diet/index_dark.html', title='الخطط الغذائية | GymPro Arabic', now=datetime.now())

@diet_bp.route('/detail/<int:plan_id>')
def detail(plan_id):
    """Show details for a specific diet plan."""
    # In a real app, you would fetch the plan from the database
    # For now, we'll create a hardcoded sample plan based on the ID
    
    if plan_id == 1:
        plan = {
            'id': 1,
            'title': 'خطة بناء العضلات',
            'description': 'خطة غذائية عالية البروتين لبناء العضلات وزيادة الكتلة العضلية.',
            'calories': 3000,
            'protein': 180,
            'carbs': 350,
            'fat': 85,
            'meals': generate_sample_meal_plan(3000, 180, 350, 85)
        }
    elif plan_id == 2:
        plan = {
            'id': 2,
            'title': 'خطة غذائية لإنقاص الوزن',
            'description': 'خطة غذائية متوازنة لفقدان الوزن بطريقة صحية مع الحفاظ على الكتلة العضلية.',
            'calories': 1800,
            'protein': 150,
            'carbs': 180,
            'fat': 50,
            'meals': generate_sample_meal_plan(1800, 150, 180, 50)
        }
    elif plan_id == 3:
        plan = {
            'id': 3,
            'title': 'خطة كيتو دايت',
            'description': 'خطة غذائية منخفضة الكربوهيدرات وعالية الدهون لتحفيز حرق الدهون.',
            'calories': 2200,
            'protein': 135,
            'carbs': 50,
            'fat': 170,
            'meals': generate_sample_meal_plan(2200, 135, 50, 170)
        }
    else:
        flash('الخطة الغذائية غير موجودة', 'error')
        return redirect(url_for('diet.index'))
    
    return render_template('diet/detail.html', 
                          title=f'{plan["title"]} | GymPro Arabic',
                          plan=plan,
                          now=datetime.now())

@diet_bp.route('/weight-loss-plan', methods=['GET', 'POST'])
def weight_loss_plan():
    """Custom weight loss plan generator."""
    if request.method == 'POST':
        try:
            age = int(request.form.get('age'))
            weight = float(request.form.get('weight'))
            height = float(request.form.get('height'))
            gender = request.form.get('gender')
            activity = request.form.get('activity')
            
            # Calculate BMR
            if gender == 'male':
                bmr = 10 * weight + 6.25 * height - 5 * age + 5
            else:
                bmr = 10 * weight + 6.25 * height - 5 * age - 161
            
            # Activity multipliers
            activity_multipliers = {
                'sedentary': 1.2,
                'light': 1.375,
                'moderate': 1.55,
                'active': 1.725,
                'very_active': 1.9
            }
            
            # Calculate TDEE
            tdee = bmr * activity_multipliers.get(activity, 1.2)
            
            # Calculate weight loss calories (500 calorie deficit)
            weight_loss_calories = max(1200, round(tdee - 500))
            
            # Calculate macros
            protein_g = round(weight * 1.6)  # 1.6g per kg bodyweight
            fat_g = round(weight_loss_calories * 0.25 / 9)  # 25% of calories from fat
            carbs_g = round((weight_loss_calories - (protein_g * 4) - (fat_g * 9)) / 4)
            
            # Generate a sample meal plan
            meal_plan = generate_sample_meal_plan(weight_loss_calories, protein_g, carbs_g, fat_g)
            
            return render_template('diet/weight_loss_result.html', 
                                  title='خطة التخسيس | GymPro Arabic',
                                  calories=weight_loss_calories,
                                  protein=protein_g,
                                  carbs=carbs_g,
                                  fat=fat_g,
                                  meal_plan=meal_plan)
            
        except ValueError:
            flash('يرجى التأكد من إدخال قيم صحيحة', 'danger')
    
    return render_template('diet/weight_loss_plan.html', title='خطة التخسيس | GymPro Arabic', now=datetime.now())

@diet_bp.route('/meal-generator', methods=['GET', 'POST'])
def meal_generator():
    """Daily meal generator based on calorie needs."""
    if request.method == 'POST':
        try:
            calories = int(request.form.get('calories'))
            
            # Set default macros based on balanced diet
            protein_percent = float(request.form.get('protein_percent', 30))
            carbs_percent = float(request.form.get('carbs_percent', 45))
            fat_percent = float(request.form.get('fat_percent', 25))
            
            # Calculate macros in grams
            protein_g = round((calories * protein_percent / 100) / 4)
            carbs_g = round((calories * carbs_percent / 100) / 4)
            fat_g = round((calories * fat_percent / 100) / 9)
            
            # Generate a sample meal plan
            meal_plan = generate_sample_meal_plan(calories, protein_g, carbs_g, fat_g)
            
            return render_template('diet/meal_generator_result_dark.html', 
                                  title='مولد الوجبات | GymPro Arabic',
                                  calories=calories,
                                  protein=protein_g,
                                  carbs=carbs_g,
                                  fat=fat_g,
                                  meal_plan=meal_plan)
            
        except ValueError:
            flash('يرجى التأكد من إدخال قيم صحيحة', 'danger')
    
    return render_template('diet/meal_generator.html', title='مولد الوجبات | GymPro Arabic', now=datetime.now())

def generate_sample_meal_plan(total_calories, protein_g, carbs_g, fat_g):
    """Generate a sample meal plan based on calories and macros."""
    # This is a simplified version. In a real app, you would use the database
    # to fetch real food items and create a balanced meal plan.
    
    # Sample meal plan structure
    meal_plan = {
        'breakfast': {
            'name': 'وجبة الإفطار',
            'calories': round(total_calories * 0.25),
            'protein': round(protein_g * 0.25),
            'carbs': round(carbs_g * 0.3),
            'fat': round(fat_g * 0.25),
            'items': [
                {'name': 'بيض مسلوق', 'quantity': '2 حبة'},
                {'name': 'خبز أسمر', 'quantity': '1 شريحة'},
                {'name': 'أفوكادو', 'quantity': '1/4 حبة'},
                {'name': 'شاي أخضر', 'quantity': '1 كوب'}
            ],
            'tips': [
                'تناول الإفطار خلال ساعة من الاستيقاظ لتنشيط التمثيل الغذائي',
                'يمكنك إضافة القليل من الفلفل الأسود للبيض لتعزيز عملية الأيض'
            ]
        },
        'lunch': {
            'name': 'وجبة الغداء',
            'calories': round(total_calories * 0.35),
            'protein': round(protein_g * 0.4),
            'carbs': round(carbs_g * 0.4),
            'fat': round(fat_g * 0.3),
            'items': [
                {'name': 'صدر دجاج مشوي', 'quantity': '120 جرام'},
                {'name': 'أرز بني', 'quantity': '1/2 كوب'},
                {'name': 'سلطة خضراء', 'quantity': '1 طبق'},
                {'name': 'زيت زيتون', 'quantity': '1 ملعقة صغيرة'}
            ],
            'tips': [
                'تناول البروتين أولاً ثم الخضروات ثم الكربوهيدرات',
                'مضغ الطعام جيداً يساعد على الهضم وتقليل كمية الطعام المتناولة'
            ]
        },
        'dinner': {
            'name': 'وجبة العشاء',
            'calories': round(total_calories * 0.25),
            'protein': round(protein_g * 0.25),
            'carbs': round(carbs_g * 0.2),
            'fat': round(fat_g * 0.25),
            'items': [
                {'name': 'سمك مشوي', 'quantity': '100 جرام'},
                {'name': 'بطاطا حلوة', 'quantity': '1/2 حبة متوسطة'},
                {'name': 'خضروات مشوية', 'quantity': '1 طبق'}
            ],
            'tips': [
                'تناول العشاء قبل النوم بثلاث ساعات على الأقل',
                'تقليل الكربوهيدرات في وجبة العشاء يساعد على نوم أفضل'
            ]
        },
        'snacks': {
            'name': 'وجبات خفيفة',
            'calories': round(total_calories * 0.15),
            'protein': round(protein_g * 0.1),
            'carbs': round(carbs_g * 0.1),
            'fat': round(fat_g * 0.2),
            'items': [
                {'name': 'لبن زبادي قليل الدسم', 'quantity': '1 علبة'},
                {'name': 'مكسرات غير مملحة', 'quantity': '15 جرام'},
                {'name': 'تفاحة', 'quantity': '1 حبة متوسطة'}
            ],
            'tips': [
                'توزيع الوجبات الخفيفة بين الوجبات الرئيسية يساعد على استقرار مستوى السكر في الدم',
                'تناول البروتين مع الفاكهة يبطئ امتصاص السكر'
            ]
        }
    }
    
    return meal_plan
