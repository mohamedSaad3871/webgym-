from flask import Blueprint

diet_bp = Blueprint('diet', __name__, template_folder='../templates')

from app.diet import routes
