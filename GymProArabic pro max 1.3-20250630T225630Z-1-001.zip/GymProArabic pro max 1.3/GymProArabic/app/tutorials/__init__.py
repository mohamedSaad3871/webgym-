from flask import Blueprint

tutorials_bp = Blueprint('tutorials', __name__)

from app.tutorials import routes
