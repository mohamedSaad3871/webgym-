from flask import render_template, request, redirect, url_for, flash, jsonify, current_app
from app.tutorials import tutorials_bp
from app.models.tutorial import ExerciseTutorial
from app import db
from flask_login import login_required, current_user
from datetime import datetime
import os

@tutorials_bp.route('/')
def index():
    """Main page for exercise tutorials."""
    # Get all muscle groups with their tutorials
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    # Get tutorials for each muscle group
    tutorials_by_group = {}
    for group_en, group_ar in muscle_groups.items():
        tutorials = ExerciseTutorial.query.filter_by(muscle_group=group_en).order_by(ExerciseTutorial.order).all()
        tutorials_by_group[group_en] = {
            'name_ar': group_ar,
            'tutorials': tutorials
        }
    
    return render_template(
        'tutorials/index_dark.html', 
        title='إزاي تلعب التمارين صح | جيم برو العربية',
        tutorials_by_group=tutorials_by_group,
        muscle_groups=muscle_groups
    )

@tutorials_bp.route('/tutorial/<int:tutorial_id>')
def tutorial_detail(tutorial_id):
    """View a specific tutorial."""
    tutorial = ExerciseTutorial.query.get_or_404(tutorial_id)
    
    # Get related tutorials from the same muscle group
    related_tutorials = ExerciseTutorial.query.filter_by(
        muscle_group=tutorial.muscle_group
    ).filter(
        ExerciseTutorial.id != tutorial.id
    ).order_by(ExerciseTutorial.order).limit(4).all()
    
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    current_app.logger.debug(f'Video URL: {tutorial.video_url}')
    current_app.logger.debug(f'Embed URL: {tutorial.embed_url}')

    return render_template(
        'tutorials/tutorial_detail.html', 
        title=f'{tutorial.title} | GymPro Arabic',
        tutorial=tutorial,
        related_tutorials=related_tutorials,
        muscle_group_ar=muscle_groups.get(tutorial.muscle_group, tutorial.muscle_group)
    )

@tutorials_bp.route('/muscle-group/<string:group>')
def muscle_group(group):
    """View tutorials for a specific muscle group."""
    muscle_groups = {
        'chest': 'الصدر',
        'back': 'الظهر',
        'legs': 'الرجل',
        'biceps': 'الباي',
        'triceps': 'التراي',
        'shoulders': 'الكتف',
        'abs': 'البطن'
    }
    
    if group not in muscle_groups:
        flash('مجموعة العضلات غير موجودة', 'danger')
        return redirect(url_for('tutorials.index'))
    
    tutorials = ExerciseTutorial.query.filter_by(muscle_group=group).order_by(ExerciseTutorial.order).all()
    
    return render_template(
        'tutorials/muscle_group.html',
        title=f'{muscle_groups[group]} | GymPro Arabic',
        tutorials=tutorials,
        muscle_group=group,
        muscle_group_ar=muscle_groups[group]
    )
