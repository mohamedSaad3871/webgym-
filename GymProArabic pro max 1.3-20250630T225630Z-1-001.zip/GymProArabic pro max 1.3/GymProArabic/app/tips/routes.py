from flask import render_template, request, redirect, url_for, flash, Blueprint
from datetime import datetime
from app.tips import tips_bp
from app.models.tip import Tip
from app import db
from flask_login import login_required

# Module-level tips data
GENERAL_TIPS_LIST = [
        {
            'id': 1,
            'title': 'تجنب الإصابات أثناء التمرين',
            'content': '''
            <p>الإصابات يمكن أن تعطل تقدمك وتبعدك عن الجيم لفترات طويلة. إليك بعض النصائح لتجنب الإصابات:</p>
            <ul>
                <li>قم بالإحماء المناسب قبل كل تمرين (5-10 دقائق)</li>
                <li>تعلم الأداء الصحيح للتمارين قبل زيادة الأوزان</li>
                <li>زد الأوزان تدريجياً وليس بشكل مفاجئ</li>
                <li>استمع لجسمك وتوقف عند الشعور بألم حاد</li>
                <li>خذ فترات راحة كافية بين التمارين وبين أيام التدريب</li>
                <li>استخدم معدات الحماية المناسبة (أحزمة الظهر، أربطة المعصم، إلخ) عند الحاجة</li>
            </ul>
            ''',
            'category': 'السلامة',
            'image_url': 'img/tips/injury_prevention.jpg'
        },
        {
            'id': 2,
            'title': 'أهمية التسخين قبل التمرين',
            'content': '''
            <p>التسخين ليس مجرد خطوة روتينية يمكن تخطيها، بل هو جزء أساسي من التمرين الفعال والآمن:</p>
            <ul>
                <li>يزيد من تدفق الدم إلى العضلات مما يحسن أدائها</li>
                <li>يرفع درجة حرارة الجسم والعضلات مما يزيد من مرونتها</li>
                <li>يحسن من كفاءة الحركة ويقلل من خطر الإصابة</li>
                <li>يهيئ الجهاز العصبي للتمرين القادم</li>
            </ul>
            <p>يمكن أن يشمل التسخين:</p>
            <ul>
                <li>5-10 دقائق من التمارين الهوائية الخفيفة (مشي سريع، جري خفيف، قفز)</li>
                <li>تمارين حركية ديناميكية (تدوير الذراعين، تأرجح الساقين)</li>
                <li>تمارين خفيفة مشابهة للتمارين الرئيسية التي ستقوم بها</li>
            </ul>
            ''',
            'category': 'تقنيات التمرين',
            'image_url': 'img/tips/warm_up.jpg'
        },
        {
            'id': 3,
            'title': 'الحفاظ على الاستمرارية',
            'content': '''
            <p>الاستمرارية هي المفتاح الأساسي للنجاح في رحلتك الرياضية. إليك بعض النصائح للحفاظ على الاستمرارية:</p>
            <ul>
                <li>ضع أهدافاً واقعية وقابلة للقياس</li>
                <li>أنشئ روتيناً ثابتاً للتمرين والتزم به</li>
                <li>اختر تمارين تستمتع بها وليس فقط تمارين "فعالة"</li>
                <li>تدرب مع صديق أو مجموعة لزيادة المساءلة والتحفيز</li>
                <li>تتبع تقدمك لتشعر بالإنجاز</li>
                <li>كافئ نفسك عند تحقيق الأهداف الصغيرة</li>
                <li>لا تقسو على نفسك إذا فاتك تمرين، فقط عد في اليوم التالي</li>
                <li>نوع في تمارينك لتجنب الملل والركود</li>
            </ul>
            <p>تذكر أن التمرين المنتظم المتوسط الشدة أفضل بكثير من التمرين المتقطع عالي الشدة.</p>
            ''',
            'category': 'تحفيز',
            'image_url': 'img/tips/consistency.jpg'
        },
        {
            'id': 4,
            'title': 'أهمية النوم الكافي للرياضيين',
            'content': '''
            <p>النوم ليس مجرد وقت للراحة، بل هو جزء أساسي من عملية بناء العضلات والتعافي:</p>
            <ul>
                <li>خلال النوم العميق يفرز الجسم هرمون النمو الذي يساعد في إصلاح وبناء العضلات</li>
                <li>النوم الكافي يحسن الأداء الرياضي والتركيز والقوة</li>
                <li>قلة النوم تزيد من هرمونات التوتر وتقلل من قدرة الجسم على التعافي</li>
                <li>النوم الجيد يساعد في تنظيم الشهية وعمليات الأيض</li>
            </ul>
            <p>نصائح لتحسين جودة النوم:</p>
            <ul>
                <li>احصل على 7-9 ساعات من النوم كل ليلة</li>
                <li>حافظ على جدول نوم منتظم</li>
                <li>تجنب الكافيين والشاشات قبل النوم</li>
                <li>اجعل غرفة نومك مظلمة وهادئة وباردة</li>
            </ul>
            ''',
            'category': 'استعادة',
            'image_url': 'img/tips/sleep.jpg'
        },
        {
            'id': 5,
            'title': 'أهمية شرب الماء أثناء التمرين',
            'content': '''
            <p>الترطيب المناسب ضروري للأداء الرياضي الأمثل والصحة العامة:</p>
            <ul>
                <li>يساعد في تنظيم درجة حرارة الجسم أثناء التمرين</li>
                <li>يحسن أداء العضلات ويقلل من التعب</li>
                <li>يساعد في نقل المغذيات إلى العضلات</li>
                <li>يقلل من خطر الإصابة والتشنجات العضلية</li>
                <li>يحسن التركيز والأداء الذهني</li>
            </ul>
            <p>إرشادات للترطيب:</p>
            <ul>
                <li>اشرب 500 مل من الماء قبل التمرين بساعتين</li>
                <li>اشرب 200-300 مل كل 15-20 دقيقة أثناء التمرين</li>
                <li>اشرب 500 مل على الأقل بعد التمرين</li>
                <li>راقب لون البول - يجب أن يكون فاتح اللون</li>
            </ul>
            ''',
            'category': 'تغذية',
            'image_url': 'img/tips/hydration.jpg'
        },
        {
            'id': 6,
            'title': 'أهمية التنوع في التمارين',
            'content': '''
            <p>تنويع التمارين ليس فقط لكسر الملل، بل له فوائد فسيولوجية مهمة:</p>
            <ul>
                <li>يمنع الركود (Plateau) في النتائج</li>
                <li>يستهدف مجموعات عضلية مختلفة ويحسن التوازن العضلي</li>
                <li>يقلل من خطر الإصابات الناتجة عن الاستخدام المفرط</li>
                <li>يحسن المهارات الحركية المختلفة</li>
                <li>يبقي التمرين ممتعاً ويزيد من الالتزام</li>
            </ul>
            <p>طرق لتنويع التمارين:</p>
            <ul>
                <li>تغيير نوع التمرين (مقاومة، هوائي، مرونة)</li>
                <li>تغيير المتغيرات (الوزن، التكرار، المجموعات، فترات الراحة)</li>
                <li>استخدام أدوات مختلفة (أوزان حرة، آلات، كرات، مقاومة الجسم)</li>
                <li>تجربة أساليب تدريب مختلفة (تدريب الفترات، التدريب الدائري، التدريب البليومتري)</li>
            </ul>
            ''',
            'category': 'تقنيات التمرين',
            'image_url': 'img/tips/variety.jpg'
        }
]

# Detailed tips data
DETAILED_TIPS_DATA = {
        1: {
            'id': 1,
            'title': 'تجنب الإصابات أثناء التمرين',
            'content': '''
            <p>الإصابات يمكن أن تعطل تقدمك وتبعدك عن الجيم لفترات طويلة. إليك بعض النصائح لتجنب الإصابات:</p>
            <h3>قبل التمرين</h3>
            <ul>
                <li>قم بالإحماء المناسب قبل كل تمرين (5-10 دقائق)</li>
                <li>تأكد من أن ملابسك وأحذيتك مناسبة للتمرين</li>
                <li>تعرف على كيفية استخدام المعدات بشكل صحيح</li>
                <li>ضع خطة تمرين متوازنة تناسب مستواك</li>
            </ul>
            
            <h3>أثناء التمرين</h3>
            <ul>
                <li>تعلم الأداء الصحيح للتمارين قبل زيادة الأوزان</li>
                <li>زد الأوزان تدريجياً وليس بشكل مفاجئ</li>
                <li>استمع لجسمك وتوقف عند الشعور بألم حاد</li>
                <li>خذ فترات راحة كافية بين المجموعات</li>
                <li>استخدم معدات الحماية المناسبة (أحزمة الظهر، أربطة المعصم، إلخ) عند الحاجة</li>
                <li>اطلب المساعدة عند رفع الأوزان الثقيلة</li>
            </ul>
            
            <h3>بعد التمرين</h3>
            <ul>
                <li>قم بتمارين التهدئة والإطالة</li>
                <li>خذ وقتاً كافياً للتعافي بين جلسات تدريب نفس المجموعة العضلية</li>
                <li>اهتم بالتغذية المناسبة للمساعدة في استعادة العضلات</li>
                <li>احصل على قسط كافٍ من النوم</li>
            </ul>
            
            <h3>علامات تحذيرية يجب الانتباه لها</h3>
            <ul>
                <li>ألم حاد أثناء أو بعد التمرين</li>
                <li>تورم غير طبيعي في المفاصل أو العضلات</li>
                <li>محدودية في حركة المفاصل</li>
                <li>ضعف أو خدر في الأطراف</li>
                <li>ألم مستمر لأكثر من يومين بعد التمرين</li>
            </ul>
            
            <p>تذكر أن الوقاية خير من العلاج، والتقدم البطيء المستمر أفضل من التقدم السريع الذي ينتهي بإصابة!</p>
            ''',
            'category': 'السلامة',
            'image_url': 'img/tips/injury_prevention.jpg',
            'created_at': '2025-05-15'
        },
        # More detailed tips would be here in a real app
}

# استخدام البلوبرنت المعرف مسبقاً بدلاً من إعادة تعريفه
# tips_bp = Blueprint('tips', __name__)

@tips_bp.route('/')
def index():
    """عرض صفحة النصائح الرئيسية"""
    tips = Tip.query.order_by(Tip.created_at.desc()).all()
    if not tips:
        # If no tips in database, use the module-level tips
        tips = [Tip(
            id=tip['id'],
            title=tip['title'],
            content=tip['content'],
            category=tip['category'],
            image_url=tip['image_url']
        ) for tip in GENERAL_TIPS_LIST]
        
    return render_template('tips/index.html',
                         title='نصائح رياضية | GymPro Arabic',
                         tips=tips,
                         now=datetime.utcnow())

@tips_bp.route('/tip/<int:tip_id>')
def tip_detail(tip_id):
    """عرض تفاصيل نصيحة معينة"""
    tip = Tip.query.get(tip_id)
    
    # If tip is not in the database, check if it's in our hardcoded data
    if not tip:
        if tip_id in DETAILED_TIPS_DATA:
            # Use the detailed tip data if available
            tip_data = DETAILED_TIPS_DATA[tip_id]
            tip = Tip(
                id=tip_data['id'],
                title=tip_data['title'],
                content=tip_data['content'],
                category=tip_data['category'],
                image_url=tip_data['image_url'],
                created_at=tip_data.get('created_at')
            )
        else:
            # Check if it's in the general tips list
            for tip_data in GENERAL_TIPS_LIST:
                if tip_data['id'] == tip_id:
                    tip = Tip(
                        id=tip_data['id'],
                        title=tip_data['title'],
                        content=tip_data['content'],
                        category=tip_data['category'],
                        image_url=tip_data['image_url']
                    )
                    break
            
            if not tip:
                # If tip is not found in either list, return 404
                return render_template('errors/404.html'), 404
                
    return render_template('tips/detail.html',
                         title=f'{tip.title} | GymPro Arabic',
                         tip=tip,
                         now=datetime.utcnow())

@tips_bp.route('/beginners')
def beginners():
    """عرض صفحة المبتدئين في التمارين الرياضية"""
    return render_template('tips/beginners/index.html')

@tips_bp.route('/beginners/program')
def beginners_program():
    """عرض صفحة البرنامج التدريبي للمبتدئين"""
    return render_template('tips/beginners/beginners_program.html')
