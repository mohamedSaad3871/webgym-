from flask import render_template, request, redirect, url_for, flash
from app.workout import workout_bp
from app.models.workout import Exercise, Workout, WorkoutExercise, WorkoutPlan, WorkoutDay
from app import db
from flask_login import login_required, current_user
from datetime import datetime

@workout_bp.route('/')
def index():
    """Workout main page."""
    return render_template('workout/index_dark.html', title='التمارين الرياضية | جيم برو العربية', now=datetime.now())

@workout_bp.route('/first-day')
def first_day():
    """First day at the gym guide for beginners."""
    # Sample exercises for first day at the gym
    beginner_exercises = [
        {
            'name': 'المشي على جهاز المشي',
            'description': 'تمرين هوائي للإحماء وتنشيط الدورة الدموية',
            'instructions': 'ابدأ بالمشي لمدة 5-10 دقائق بسرعة معتدلة للإحماء',
            'video_url': 'https://www.youtube.com/embed/tgbNymZ7vqY',
            'image_url': 'treadmill.jpg'
        },
        {
            'name': 'تمرين القرفصاء (Squat)',
            'description': 'تمرين أساسي للجزء السفلي من الجسم يستهدف عضلات الفخذين والأرداف',
            'instructions': '1. قف بشكل مستقيم مع توجيه قدميك للأمام وباعد بينهما بعرض الكتفين\n2. أنزل جسمك للأسفل كأنك تجلس على كرسي\n3. حافظ على ظهرك مستقيماً والركبتين خلف أصابع القدم\n4. ارجع للوضع الأصلي',
            'video_url': 'https://www.youtube.com/embed/aclHkVaku9U',
            'image_url': 'squat.jpg'
        },
        {
            'name': 'تمرين الضغط المعدل (Modified Push-up)',
            'description': 'تمرين للجزء العلوي من الجسم يستهدف عضلات الصدر والكتفين والذراعين',
            'instructions': '1. ابدأ بوضع الركبتين على الأرض واليدين بعرض الكتفين\n2. حافظ على استقامة الجسم من الركبتين إلى الرأس\n3. قم بثني المرفقين لإنزال صدرك نحو الأرض\n4. ادفع جسمك للأعلى للعودة إلى وضع البداية',
            'video_url': 'https://www.youtube.com/embed/MO10KOoQx5E',
            'image_url': 'pushup.jpg'
        },
        {
            'name': 'تمرين السحب (Lat Pulldown)',
            'description': 'تمرين يستهدف عضلات الظهر العريضة والذراعين',
            'instructions': '1. اجلس على جهاز السحب وامسك البار بقبضة عريضة\n2. اسحب البار لأسفل نحو صدرك مع الضغط على عضلات الظهر\n3. أعد البار ببطء إلى الوضع الأصلي',
            'video_url': 'https://www.youtube.com/embed/CAwf7n6Luuc',
            'image_url': 'lat_pulldown.jpg'
        },
        {
            'name': 'تمرين رفع الساقين (Leg Raises)',
            'description': 'تمرين يستهدف عضلات البطن السفلية',
            'instructions': '1. استلق على ظهرك مع وضع يديك بجانب جسمك أو تحت أسفل ظهرك\n2. ارفع ساقيك ببطء إلى وضع عمودي\n3. أنزل ساقيك ببطء بدون أن تلمس الأرض\n4. كرر التمرين',
            'video_url': 'https://www.youtube.com/embed/JB2oyawG9KI',
            'image_url': 'leg_raises.jpg'
        }
    ]
    
    # Tips for beginners
    beginner_tips = [
        'ابدأ بأوزان خفيفة وركز على الأداء الصحيح للتمرين',
        'لا تنس شرب الماء بكميات كافية أثناء التمرين',
        'خذ فترات راحة كافية بين المجموعات (30-60 ثانية)',
        'قم بالإحماء قبل التمرين والتهدئة بعده',
        'استمع لجسمك ولا تتجاهل الألم الحاد'
    ]
    
    return render_template('workout/first_day.html', 
                          title='اليوم الأول في الجيم | جيم برو العربية',
                          exercises=beginner_exercises,
                          tips=beginner_tips,
                          now=datetime.now())

@workout_bp.route('/proper-form')
def proper_form():
    """How to perform exercises with proper form with YouTube videos."""
    exercise_tutorials = [
        {
            'name': 'تمرين القرفصاء (Squat)',
            'muscle_group': 'الساقين والأرداف',
            'description': 'من أهم التمارين الأساسية لبناء القوة وتقوية عضلات الجسم السفلية',
            'benefits': [
                'تقوية عضلات الفخذين والأرداف',
                'تحسين وضعية الجسم والتوازن',
                'زيادة كثافة العظام',
                'حرق سعرات حرارية عالية'
            ],
            'common_mistakes': [
                'ثني الظهر للأمام',
                'رفع الكعبين عن الأرض',
                'عدم النزول لعمق كافٍ',
                'توجيه الركبتين للداخل'
            ],
            'proper_form': [
                'قف بتباعد القدمين بعرض الكتفين',
                'وجه أصابع القدمين للأمام أو بزاوية خفيفة للخارج',
                'أنزل جسمك للأسفل كأنك تجلس على كرسي',
                'حافظ على ظهرك مستقيماً والصدر مرفوعاً',
                'تأكد من أن الركبتين تتبعان اتجاه أصابع القدمين',
                'انزل حتى تصبح الفخذين موازية للأرض أو أقل قليلاً',
                'ادفع بكعبيك للعودة إلى وضع البداية'
            ],
            'video_url': 'https://www.youtube.com/embed/YaXPRqUwItQ',
            'image_url': 'https://images.unsplash.com/photo-1566241142248-11865261e1f9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
        },
        {
            'name': 'تمرين الضغط (Push-up)',
            'muscle_group': 'الصدر والكتفين والذراعين',
            'description': 'تمرين أساسي يستهدف الجزء العلوي من الجسم بوزن الجسم',
            'benefits': [
                'تقوية عضلات الصدر والكتفين والترايسبس',
                'تحسين ثبات الجذع والبطن',
                'سهولة أدائه في أي مكان دون الحاجة لمعدات',
                'تحسين القوة الوظيفية للجسم'
            ],
            'common_mistakes': [
                'ترك الورك يسقط للأسفل',
                'رفع المؤخرة للأعلى كثيراً',
                'عدم النزول لعمق كافٍ',
                'وضع اليدين بشكل غير صحيح'
            ],
            'proper_form': [
                'ابدأ في وضعية الانبطاح المائل مع وضع يديك بعرض أكبر قليلاً من عرض كتفيك',
                'حافظ على استقامة جسمك من الرأس إلى الكعبين',
                'قم بشد عضلات البطن والأرداف للحفاظ على ثبات الجسم',
                'أنزل جسمك ببطء عن طريق ثني المرفقين',
                'حافظ على المرفقين بزاوية 45 درجة من الجسم وليس للخارج',
                'انزل حتى يقترب صدرك من الأرض',
                'ادفع للأعلى بقوة للعودة إلى وضع البداية'
            ],
            'video_url': 'https://www.youtube.com/embed/IODxDxX7oi4',
            'image_url': 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
        },
        {
            'name': 'ديدليفت (Deadlift)',
            'muscle_group': 'الظهر والساقين والأرداف',
            'description': 'تمرين مركب قوي يستهدف العديد من المجموعات العضلية في وقت واحد',
            'benefits': [
                'تقوية عضلات الظهر السفلي والأرداف',
                'تحسين قوة الإمساك باليدين',
                'زيادة إنتاج هرمونات النمو الطبيعية',
                'تحسين وضعية الجسم وتقوية العمود الفقري'
            ],
            'common_mistakes': [
                'تقوس الظهر (حدبة) أثناء الرفع',
                'النظر للأعلى أو للأسفل بدلاً من الأمام',
                'رفع الأكتاف للأذنين',
                'استخدام وزن ثقيل قبل إتقان التقنية'
            ],
            'proper_form': [
                'قف بتباعد القدمين بعرض الوركين والبار فوق منتصف القدم',
                'انحنِ من الوركين وأمسك البار بقبضة متوازية أو متعاكسة',
                'اخفض وركيك واجعل ساقيك بزاوية مناسبة للوصول إلى البار',
                'حافظ على استقامة ظهرك وصدرك مرفوعاً طوال الحركة',
                'ادفع بقدميك ضد الأرض ومد ساقيك ووركيك في نفس الوقت',
                'عند الوقوف، حافظ على استقامة جسمك دون المبالغة في مد الظهر للخلف',
                'أعد البار إلى الأرض بالتحكم في النزول، مع ثني الوركين أولاً ثم الركبتين'
            ],
            'video_url': 'https://www.youtube.com/embed/ytGaGIn3SjE',
            'image_url': 'https://images.unsplash.com/photo-1534368786749-b63e05c92542?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
        },
        {
            'name': 'تمرين البنش برس (Bench Press)',
            'muscle_group': 'الصدر والكتفين والترايسبس',
            'description': 'تمرين قوة أساسي لتنمية عضلات الصدر والجزء العلوي من الجسم',
            'benefits': [
                'تقوية وتضخيم عضلات الصدر',
                'تنمية عضلات الكتفين الأمامية',
                'تقوية عضلات الترايسبس',
                'تحسين القوة العامة للجزء العلوي من الجسم'
            ],
            'common_mistakes': [
                'رفع المؤخرة عن المقعد',
                'عدم إنزال البار لعمق كافٍ',
                'استخدام قبضة واسعة جداً أو ضيقة جداً',
                'عدم استقرار الكتفين على المقعد'
            ],
            'proper_form': [
                'استلق على مقعد مستوٍ مع وضع قدميك بثبات على الأرض',
                'حافظ على ثبات الكتفين على المقعد وأسفل الظهر قريباً من المقعد (قوس طبيعي)',
                'امسك البار بقبضة أوسع قليلاً من عرض الكتفين',
                'أنزل البار ببطء نحو منتصف الصدر (أسفل عضلة الصدر)',
                'اضغط على الصدر قليلاً لإبعاد الكوعين عن الجسم بزاوية 45-70 درجة',
                'ادفع البار للأعلى في خط مستقيم حتى امتداد الذراعين بالكامل',
                'كرر الحركة مع الاحتفاظ بالثبات والتحكم طوال التمرين'
            ],
            'video_url': 'https://www.youtube.com/embed/vcBig73ojpE',
            'image_url': 'https://images.unsplash.com/photo-1534368737481-91314344798f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
        },
        {
            'name': 'تمرين السحب العلوي (Pull-up)',
            'muscle_group': 'الظهر والباي سيبس',
            'description': 'تمرين قوي لعضلات الظهر يعتمد على وزن الجسم',
            'benefits': [
                'تقوية عضلات الظهر العريضة (اللاتس)',
                'تنمية عضلات الباي سيبس',
                'تحسين قوة الإمساك باليدين',
                'تحسين نسبة القوة إلى الوزن'
            ],
            'common_mistakes': [
                'عدم السحب بالكامل للأعلى',
                'استخدام زخم الجسم بدلاً من قوة العضلات',
                'عدم التحكم في النزول',
                'التنفس بشكل غير صحيح'
            ],
            'proper_form': [
                'امسك العقلة بقبضة أوسع من عرض الكتفين والراحتين للأمام',
                'علق جسمك بذراعين ممدودتين بالكامل',
                'شد عضلات الكتفين للخلف وللأسفل قبل بدء السحب',
                'اسحب جسمك للأعلى عن طريق ثني المرفقين وسحب المرفقين للأسفل',
                'استمر في السحب حتى يصل ذقنك فوق مستوى العقلة',
                'أنزل جسمك ببطء وتحكم إلى وضع البداية',
                'كرر الحركة مع الحفاظ على تنشيط عضلات الظهر طوال التمرين'
            ],
            'video_url': 'https://www.youtube.com/embed/eGo4IYlbE5g',
            'image_url': 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80'
        }
    ]
    
    return render_template('workout/proper_form.html',
                          title='كيفية أداء التمارين بشكل صحيح | جيم برو العربية',
                          exercise_tutorials=exercise_tutorials,
                          now=datetime.now())

@workout_bp.route('/plan-generator', methods=['GET', 'POST'])
def plan_generator():
    """Workout plan generator based on user goals and level."""
    if request.method == 'POST':
        try:
            goal = request.form.get('goal')
            level = request.form.get('level')
            days_per_week = int(request.form.get('days_per_week', 3))
            equipment = request.form.get('equipment', 'full_gym')
            time_per_session = request.form.get('time', '60')
            avoid_areas = request.form.getlist('avoid_areas')
            focus_areas = request.form.getlist('focus_areas')
            
            # Generate a sample workout plan
            workout_plan = generate_sample_workout_plan(goal, level, days_per_week)
            
            return render_template('workout/plan_result.html', 
                                  title='خطة التمارين | GymPro Arabic',
                                  goal=goal,
                                  level=level,
                                  days_per_week=days_per_week,
                                  equipment=equipment,
                                  time=time_per_session,
                                  avoid_areas=avoid_areas,
                                  focus_areas=focus_areas,
                                  workout_plan=workout_plan,
                                  now=datetime.now())
            
        except Exception as e:
            flash('يرجى التأكد من إدخال قيم صحيحة: ' + str(e), 'danger')
    
    return render_template('workout/workout_plan.html', title='مولد خطة التمارين | GymPro Arabic', now=datetime.now())

def generate_sample_workout_plan(goal, level, days_per_week):
    """Generate a sample workout plan based on user preferences."""
    # This is a simplified version. In a real app, you would use the database
    # to fetch real exercises and create a balanced workout plan.
    
    # Define workout splits based on days per week
    if days_per_week == 3:
        if goal == 'weight_loss':
            split = ['تمارين الجسم كامل', 'راحة', 'تمارين الجسم كامل', 'راحة', 'تمارين هوائية وتمارين البطن', 'راحة', 'راحة']
        elif goal == 'muscle_gain':
            split = ['تمارين الصدر والكتف والذراعين', 'راحة', 'تمارين الظهر والبطن', 'راحة', 'تمارين الساقين والأرداف', 'راحة', 'راحة']
        else:  # fitness
            split = ['تمارين القوة', 'راحة', 'تمارين اللياقة والهوائية', 'راحة', 'تمارين القوة والبطن', 'راحة', 'راحة']
    elif days_per_week == 4:
        if goal == 'weight_loss':
            split = ['تمارين الجزء العلوي والهوائية', 'تمارين الجزء السفلي والبطن', 'راحة', 'تمارين الجسم كامل', 'تمارين هوائية', 'راحة', 'راحة']
        elif goal == 'muscle_gain':
            split = ['تمارين الصدر والكتف', 'تمارين الظهر والذراعين', 'راحة', 'تمارين الساقين والأرداف', 'تمارين البطن والكتف', 'راحة', 'راحة']
        else:  # fitness
            split = ['تمارين القوة الجزء العلوي', 'تمارين اللياقة والهوائية', 'راحة', 'تمارين القوة الجزء السفلي', 'تمارين وظيفية متنوعة', 'راحة', 'راحة']
    elif days_per_week == 5:
        if goal == 'weight_loss':
            split = ['تمارين الصدر والهوائية', 'تمارين الظهر والبطن', 'تمارين الساقين والأرداف', 'تمارين الكتف والذراعين', 'تمارين هوائية والبطن', 'راحة', 'راحة']
        elif goal == 'muscle_gain':
            split = ['تمارين الصدر', 'تمارين الظهر', 'تمارين الساقين', 'تمارين الكتف', 'تمارين الذراعين والبطن', 'راحة', 'راحة']
        else:  # fitness
            split = ['تمارين القوة الجزء العلوي', 'تمارين اللياقة والهوائية', 'تمارين القوة الجزء السفلي', 'تمارين وظيفية متنوعة', 'تمارين متنوعة والبطن', 'راحة', 'راحة']
    else:  # 6 days
        if goal == 'weight_loss':
            split = ['تمارين الصدر والهوائية', 'تمارين الظهر والبطن', 'تمارين الساقين والأرداف', 'تمارين الكتف والذراعين', 'تمارين هوائية', 'تمارين متنوعة والبطن', 'راحة']
        elif goal == 'muscle_gain':
            split = ['تمارين الصدر', 'تمارين الظهر', 'تمارين الساقين', 'تمارين الكتف', 'تمارين الذراعين', 'تمارين البطن', 'راحة']
        else:  # fitness
            split = ['تمارين القوة الجزء العلوي', 'تمارين اللياقة والهوائية', 'تمارين القوة الجزء السفلي', 'تمارين وظيفية متنوعة', 'تمارين القوة المركزية', 'تمارين متنوعة', 'راحة']
    
    # Sample exercises for different body parts
    exercises = {
        'صدر': [
            {'name': 'بنش برس (Bench Press)', 'sets': 3, 'reps': '8-12'},
            {'name': 'بنش برس مائل (Incline Bench Press)', 'sets': 3, 'reps': '8-12'},
            {'name': 'تمرين الضغط (Push-ups)', 'sets': 3, 'reps': '10-15'},
            {'name': 'فلاي مع دمبل (Dumbbell Flyes)', 'sets': 3, 'reps': '10-12'}
        ],
        'ظهر': [
            {'name': 'بول داون (Lat Pulldown)', 'sets': 3, 'reps': '10-12'},
            {'name': 'صف بالدمبل (Dumbbell Row)', 'sets': 3, 'reps': '8-12'},
            {'name': 'ديدليفت (Deadlift)', 'sets': 3, 'reps': '8-10'},
            {'name': 'بول أب (Pull-ups)', 'sets': 3, 'reps': 'أقصى عدد ممكن'}
        ],
        'ساقين': [
            {'name': 'سكوات (Squats)', 'sets': 4, 'reps': '10-12'},
            {'name': 'ليج برس (Leg Press)', 'sets': 3, 'reps': '10-15'},
            {'name': 'ليج إكستنشن (Leg Extensions)', 'sets': 3, 'reps': '12-15'},
            {'name': 'ليج كيرل (Leg Curls)', 'sets': 3, 'reps': '12-15'}
        ],
        'كتف': [
            {'name': 'شولدر برس (Shoulder Press)', 'sets': 3, 'reps': '8-12'},
            {'name': 'لاتيرال رايز (Lateral Raises)', 'sets': 3, 'reps': '12-15'},
            {'name': 'فرونت رايز (Front Raises)', 'sets': 3, 'reps': '12-15'},
            {'name': 'شراج (Shrugs)', 'sets': 3, 'reps': '12-15'}
        ],
        'ذراعين': [
            {'name': 'بايسبس كيرل (Biceps Curls)', 'sets': 3, 'reps': '10-12'},
            {'name': 'ترايسبس بوش داون (Triceps Pushdown)', 'sets': 3, 'reps': '10-12'},
            {'name': 'هامر كيرل (Hammer Curls)', 'sets': 3, 'reps': '10-12'},
            {'name': 'ترايسبس إكستنشن (Triceps Extension)', 'sets': 3, 'reps': '10-12'}
        ],
        'بطن': [
            {'name': 'كرانش (Crunches)', 'sets': 3, 'reps': '15-20'},
            {'name': 'ليج رايزز (Leg Raises)', 'sets': 3, 'reps': '12-15'},
            {'name': 'روشن تويست (Russian Twists)', 'sets': 3, 'reps': '15-20 لكل جانب'},
            {'name': 'بلانك (Plank)', 'sets': 3, 'reps': '30-60 ثانية'}
        ],
        'هوائية': [
            {'name': 'مشي سريع أو جري', 'sets': 1, 'reps': '20-30 دقيقة'},
            {'name': 'دراجة ثابتة', 'sets': 1, 'reps': '15-20 دقيقة'},
            {'name': 'تمارين هوائية متقطعة (HIIT)', 'sets': 1, 'reps': '15 دقيقة'}
        ]
    }
    
    # Create workout plan
    workout_plan = []
    for i, day_split in enumerate(split):
        day = {
            'day': f'اليوم {i+1}',
            'name': day_split,
            'exercises': []
        }
        
        if 'راحة' not in day_split:
            if 'الجسم كامل' in day_split:
                day['exercises'].extend([exercises['صدر'][0], exercises['ظهر'][0], exercises['ساقين'][0], exercises['كتف'][0], exercises['ذراعين'][0], exercises['بطن'][0]])
            if 'الصدر' in day_split:
                day['exercises'].extend(exercises['صدر'][:3])
            if 'الظهر' in day_split:
                day['exercises'].extend(exercises['ظهر'][:3])
            if 'الساقين' in day_split:
                day['exercises'].extend(exercises['ساقين'][:3])
            if 'الكتف' in day_split:
                day['exercises'].extend(exercises['كتف'][:3])
            if 'الذراعين' in day_split:
                day['exercises'].extend(exercises['ذراعين'][:3])
            if 'البطن' in day_split:
                day['exercises'].extend(exercises['بطن'][:3])
            if 'هوائية' in day_split:
                day['exercises'].extend([exercises['هوائية'][0]])
            if 'القوة' in day_split:
                if 'العلوي' in day_split:
                    day['exercises'].extend([exercises['صدر'][0], exercises['ظهر'][0], exercises['كتف'][0], exercises['ذراعين'][0]])
                elif 'السفلي' in day_split:
                    day['exercises'].extend(exercises['ساقين'])
                else:
                    day['exercises'].extend([exercises['صدر'][0], exercises['ظهر'][0], exercises['ساقين'][0]])
            if 'اللياقة' in day_split or 'وظيفية' in day_split:
                day['exercises'].extend([exercises['هوائية'][2], exercises['بطن'][3]])
        
        workout_plan.append(day)
    
    return workout_plan
