from flask import Blueprint

workout_bp = Blueprint('workout', __name__)

from app.workout import routes
