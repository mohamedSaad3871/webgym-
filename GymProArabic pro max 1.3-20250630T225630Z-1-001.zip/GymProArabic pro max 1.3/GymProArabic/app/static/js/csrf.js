/**
 * إعداد CSRF tokens لطلبات AJAX
 * 
 * يقوم هذا الملف بإعداد jQuery AJAX لإرسال CSRF token تلقائيًا مع كل طلب
 * ويتعامل أيضًا مع حالات خطأ CSRF
 */

// استخراج CSRF token من العنصر meta أو من ملفات تعريف الارتباط
function getCsrfToken() {
    // محاولة الحصول على الرمز من العنصر meta
    var token = $('meta[name="csrf-token"]').attr('content');
    
    // إذا لم يتم العثور على الرمز، حاول الحصول عليه من ملفات تعريف الارتباط
    if (!token) {
        token = getCookie('csrf_token');
    }
    
    return token;
}

// وظيفة مساعدة للحصول على قيمة ملف تعريف ارتباط محدد
function getCookie(name) {
    var cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].trim();
            // هل يبدأ ملف تعريف الارتباط بالاسم الذي نبحث عنه؟
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// إعداد jQuery AJAX لإرسال CSRF token تلقائيًا
$(function() {
    // إضافة رمز CSRF تلقائيًا لجميع طلبات AJAX
    $.ajaxSetup({
        beforeSend: function(xhr, settings) {
            // لا ترسل الرمز مع طلبات GET
            if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type)) {
                var token = getCsrfToken();
                if (token) {
                    xhr.setRequestHeader("X-CSRFToken", token);
                }
            }
        }
    });

    // التعامل مع أخطاء CSRF العامة
    $(document).ajaxError(function(event, xhr, settings, error) {
        if (xhr.status === 400 && xhr.responseJSON && xhr.responseJSON.csrf_error) {
            // في حالة حدوث خطأ CSRF، نعرض رسالة الخطأ ونوجه المستخدم إلى تحديث الصفحة
            Swal.fire({
                title: 'خطأ في تأمين النموذج',
                text: xhr.responseJSON.error || 'انتهت صلاحية الجلسة. يرجى تحديث الصفحة وإعادة المحاولة.',
                icon: 'error',
                confirmButtonText: 'تحديث الصفحة',
                allowOutsideClick: false
            }).then(function() {
                // تحديث الصفحة عند النقر على الزر
                window.location.reload();
            });
        }
    });
});

// CSRF Protection
document.addEventListener('DOMContentLoaded', function() {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    
    // Add CSRF token to all forms that don't have it
    document.querySelectorAll('form').forEach(form => {
        if (!form.querySelector('input[name="csrf_token"]')) {
            const csrfInput = document.createElement('input');
            csrfInput.type = 'hidden';
            csrfInput.name = 'csrf_token';
            csrfInput.value = csrfToken;
            form.appendChild(csrfInput);
        }
    });
    
    // Add CSRF token to fetch requests
    const originalFetch = window.fetch;
    window.fetch = function() {
        let [resource, config] = arguments;
        if(config === undefined) {
            config = {};
        }
        if(config.headers === undefined) {
            config.headers = {};
        }
        // Don't add CSRF token to GET requests
        if (config.method && !['GET', 'HEAD', 'OPTIONS', 'TRACE'].includes(config.method.toUpperCase())) {
            config.headers['X-CSRFToken'] = csrfToken;
        }
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        return originalFetch(resource, config);
    };

    // Add CSRF token to axios requests if axios is present
    if (window.axios) {
        axios.interceptors.request.use(function(config) {
            if (!['GET', 'HEAD', 'OPTIONS', 'TRACE'].includes(config.method.toUpperCase())) {
                config.headers['X-CSRFToken'] = csrfToken;
            }
            config.headers['X-Requested-With'] = 'XMLHttpRequest';
            return config;
        });
    }

    // Add CSRF token to jQuery AJAX requests if jQuery is present
    if (window.jQuery) {
        $.ajaxSetup({
            beforeSend: function(xhr, settings) {
                if (!/^(GET|HEAD|OPTIONS|TRACE)$/i.test(settings.type)) {
                    xhr.setRequestHeader("X-CSRFToken", csrfToken);
                }
                xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
            }
        });
    }
});