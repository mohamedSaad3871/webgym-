/**
 * GymProArabic - Mobile Fixes
 * JavaScript fixes for mobile-specific issues
 */

document.addEventListener('DOMContentLoaded', function() {
    // Fix for navbar on mobile
    fixMobileNavbar();
    
    // Fix for input fields on mobile
    fixMobileInputs();
    
    // Fix for tables on mobile
    makeTablesMobileResponsive();
    
    // Fix for videos on mobile
    makeVideosResponsive();
    
    // Add tap highlight fix
    fixTapHighlight();
    
    // Fix for accordions on mobile
    fixMobileAccordions();
    
    // Fix for large images on mobile
    lazyLoadImages();
    
    // Add back-to-top button
    addBackToTopButton();
});

/**
 * Fix navbar on mobile devices
 */
function fixMobileNavbar() {
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (!navbarToggler || !navbarCollapse) return;
    
    // Fix for navbar taking up too much space
    navbarCollapse.style.maxHeight = (window.innerHeight - 80) + 'px';
    
    // Update max height on resize
    window.addEventListener('resize', function() {
        navbarCollapse.style.maxHeight = (window.innerHeight - 80) + 'px';
    });
    
    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        if (
            navbarCollapse.classList.contains('show') &&
            !navbarToggler.contains(e.target) &&
            !navbarCollapse.contains(e.target)
        ) {
            // Use Bootstrap's collapse API to hide the menu
            const bsCollapse = new bootstrap.Collapse(navbarCollapse);
            bsCollapse.hide();
        }
    });
    
    // Fix for scrolling issues when navbar is open
    navbarCollapse.addEventListener('show.bs.collapse', function() {
        document.body.classList.add('navbar-open');
        document.body.style.overflow = 'hidden';
    });
    
    navbarCollapse.addEventListener('hide.bs.collapse', function() {
        document.body.classList.remove('navbar-open');
        document.body.style.overflow = '';
    });
}

/**
 * Fix input fields on mobile devices
 */
function fixMobileInputs() {
    // Fix for number inputs
    const numberInputs = document.querySelectorAll('input[type="number"]');
    
    numberInputs.forEach(input => {
        // Add inputmode attribute for better mobile keyboard
        input.setAttribute('inputmode', input.step && input.step.includes('.') ? 'decimal' : 'numeric');
        
        // Fix zoom issues on focus
        input.addEventListener('focus', function() {
            // Add a slight delay to allow keyboard to appear
            setTimeout(() => {
                const viewportMeta = document.querySelector('meta[name="viewport"]');
                
                if (viewportMeta) {
                    viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0');
                    
                    // Reset after blur
                    input.addEventListener('blur', function onBlur() {
                        viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0');
                        input.removeEventListener('blur', onBlur);
                    });
                }
            }, 300);
        });
    });
    
    // Better scroll into view for inputs
    const formInputs = document.querySelectorAll('input, select, textarea');
    
    formInputs.forEach(input => {
        input.addEventListener('focus', function() {
            if (window.innerWidth < 768) {
                // Smooth scroll to input with offset
                setTimeout(() => {
                    const rect = this.getBoundingClientRect();
                    const offset = rect.top - 120;
                    
                    if (offset > 0) {
                        window.scrollBy({
                            top: offset,
                            behavior: 'smooth'
                        });
                    }
                }, 300);
            }
        });
    });
}

/**
 * Make tables responsive on mobile
 */
function makeTablesMobileResponsive() {
    const tables = document.querySelectorAll('table:not(.table-responsive)');
    
    tables.forEach(table => {
        // Add responsive wrapper if not already wrapped
        if (table.parentElement.className.indexOf('table-responsive') === -1) {
            const wrapper = document.createElement('div');
            wrapper.className = 'table-responsive';
            table.parentNode.insertBefore(wrapper, table);
            wrapper.appendChild(table);
        }
        
        // For tables that should be cards on mobile
        if (table.classList.contains('table-mobile-cards')) {
            const headerCells = table.querySelectorAll('thead th');
            const headerTexts = Array.from(headerCells).map(th => th.textContent);
            
            const rows = table.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const cells = row.querySelectorAll('td');
                
                cells.forEach((cell, index) => {
                    if (headerTexts[index]) {
                        cell.setAttribute('data-label', headerTexts[index]);
                    }
                });
            });
        }
    });
}

/**
 * Make videos responsive on mobile
 */
function makeVideosResponsive() {
    const videos = document.querySelectorAll('iframe[src*="youtube"], iframe[src*="vimeo"], video');
    
    videos.forEach(video => {
        // Skip if already wrapped
        if (video.parentElement.className.indexOf('responsive-video') !== -1) {
            return;
        }
        
        // Create responsive wrapper
        const wrapper = document.createElement('div');
        wrapper.className = 'responsive-video';
        
        // Replace video with wrapper
        video.parentNode.insertBefore(wrapper, video);
        wrapper.appendChild(video);
    });
}

/**
 * Fix tap highlight on mobile
 */
function fixTapHighlight() {
    const tappableElements = document.querySelectorAll('a, button, .nav-link, .btn, .card');
    
    tappableElements.forEach(element => {
        element.style.webkitTapHighlightColor = 'rgba(0,0,0,0)';
        
        // Add active state for touch feedback
        element.addEventListener('touchstart', function() {
            this.classList.add('tap-active');
        }, { passive: true });
        
        element.addEventListener('touchend', function() {
            this.classList.remove('tap-active');
        }, { passive: true });
    });
}

/**
 * Fix accordions on mobile
 */
function fixMobileAccordions() {
    const accordionButtons = document.querySelectorAll('.accordion-button');
    
    accordionButtons.forEach(button => {
        // Ensure minimum touch target size
        button.style.minHeight = '44px';
        
        // Improve accordion scrolling
        button.addEventListener('click', function() {
            // Only scroll if accordion is expanding
            if (this.classList.contains('collapsed')) {
                setTimeout(() => {
                    const rect = this.getBoundingClientRect();
                    
                    // Only scroll if button is not fully visible
                    if (rect.top < 0 || rect.bottom > window.innerHeight) {
                        this.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                }, 350); // Wait for animation
            }
        });
    });
}

/**
 * Lazy load images
 */
function lazyLoadImages() {
    // Use native lazy loading where supported
    document.querySelectorAll('img').forEach(img => {
        if (!img.hasAttribute('loading')) {
            img.setAttribute('loading', 'lazy');
        }
    });
    
    // Use IntersectionObserver for images with data-src
    const lazyImages = document.querySelectorAll('img[data-src]');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    const src = img.getAttribute('data-src');
                    
                    if (src) {
                        img.src = src;
                        img.removeAttribute('data-src');
                        observer.unobserve(img);
                    }
                }
            });
        });
        
        lazyImages.forEach(img => {
            imageObserver.observe(img);
        });
    } else {
        // Fallback for browsers without IntersectionObserver
        lazyImages.forEach(img => {
            const src = img.getAttribute('data-src');
            if (src) {
                img.src = src;
                img.removeAttribute('data-src');
            }
        });
    }
}

/**
 * Add back to top button
 */
function addBackToTopButton() {
    // Create button if it doesn't exist
    if (!document.querySelector('.back-to-top')) {
        const backToTopButton = document.createElement('button');
        backToTopButton.className = 'back-to-top';
        backToTopButton.innerHTML = '<i class="fas fa-arrow-up"></i>';
        backToTopButton.setAttribute('aria-label', 'العودة إلى أعلى الصفحة');
        backToTopButton.setAttribute('title', 'العودة إلى أعلى الصفحة');
        document.body.appendChild(backToTopButton);
        
        // Show button when scrolling down
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopButton.classList.add('show');
            } else {
                backToTopButton.classList.remove('show');
            }
        });
        
        // Scroll to top when clicked
        backToTopButton.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
}

/**
 * Fix viewport issues (zoom and scaling)
 */
function fixViewport() {
    // Add viewport meta tag if missing
    if (!document.querySelector('meta[name="viewport"]')) {
        const viewportMeta = document.createElement('meta');
        viewportMeta.setAttribute('name', 'viewport');
        viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0');
        document.head.appendChild(viewportMeta);
    }
    
    // Fix for iOS orientation change zoom bug
    window.addEventListener('orientationchange', function() {
        const viewportMeta = document.querySelector('meta[name="viewport"]');
        
        if (viewportMeta) {
            viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0');
            
            setTimeout(function() {
                viewportMeta.setAttribute('content', 'width=device-width, initial-scale=1.0');
            }, 300);
        }
    });
}

// Initialize viewport fixes
fixViewport(); 