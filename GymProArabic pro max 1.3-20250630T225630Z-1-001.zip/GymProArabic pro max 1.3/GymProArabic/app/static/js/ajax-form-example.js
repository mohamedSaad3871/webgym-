/**
 * مثال على استخدام AJAX مع CSRF token
 */

$(document).ready(function() {
    
    // مثال على نموذج تسجيل الاشتراك في النشرة البريدية
    $('#newsletter-form').on('submit', function(e) {
        e.preventDefault();
        
        var email = $('#newsletter-email').val();
        
        // إرسال طلب AJAX
        $.ajax({
            url: '/subscribe',
            type: 'POST',
            data: {
                email: email
            },
            success: function(response) {
                // إذا نجح الطلب
                Swal.fire({
                    title: 'تم الاشتراك بنجاح!',
                    text: 'شكراً لاشتراكك في نشرتنا البريدية',
                    icon: 'success',
                    confirmButtonText: 'حسناً'
                });
                
                // تفريغ حقل البريد الإلكتروني
                $('#newsletter-email').val('');
            },
            error: function(xhr, status, error) {
                // إذا فشل الطلب
                var errorMessage = 'حدث خطأ أثناء الاشتراك، يرجى المحاولة مرة أخرى';
                
                // إذا كان هناك رسالة خطأ محددة من الخادم
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error;
                }
                
                Swal.fire({
                    title: 'خطأ',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonText: 'حسناً'
                });
            }
        });
    });
    
    // مثال على نموذج تعليق
    $('#comment-form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = {
            content: $('#comment-content').val(),
            article_id: $('#article-id').val()
        };
        
        // إرسال طلب AJAX
        $.ajax({
            url: '/comments/add',
            type: 'POST',
            data: formData,
            success: function(response) {
                // إذا نجح الطلب
                if (response.success) {
                    // إضافة التعليق الجديد إلى القائمة
                    var newComment = `
                        <div class="comment">
                            <div class="comment-header">
                                <strong>${response.comment.username}</strong>
                                <span>${response.comment.created_at}</span>
                            </div>
                            <div class="comment-body">
                                ${response.comment.content}
                            </div>
                        </div>
                    `;
                    
                    $('#comments-list').append(newComment);
                    
                    // تفريغ حقل التعليق
                    $('#comment-content').val('');
                    
                    // عرض رسالة نجاح
                    Swal.fire({
                        title: 'تم إضافة التعليق',
                        text: 'تمت إضافة تعليقك بنجاح',
                        icon: 'success',
                        confirmButtonText: 'حسناً',
                        timer: 1500
                    });
                }
            },
            error: function(xhr, status, error) {
                // إذا فشل الطلب
                var errorMessage = 'حدث خطأ أثناء إضافة التعليق، يرجى المحاولة مرة أخرى';
                
                // إذا كان هناك رسالة خطأ محددة من الخادم
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error;
                }
                
                Swal.fire({
                    title: 'خطأ',
                    text: errorMessage,
                    icon: 'error',
                    confirmButtonText: 'حسناً'
                });
            }
        });
    });
    
}); 