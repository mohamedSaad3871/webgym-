// Client-side validation for calculators
document.addEventListener('DOMContentLoaded', function() {
    // BMR Calculator Validation
    const bmrForm = document.getElementById('bmr-form');
    if (bmrForm) {
        bmrForm.addEventListener('submit', function(e) {
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value);
            const age = parseInt(document.getElementById('age').value);
            let isValid = true;
            let message = '';

            if (weight < 20 || weight > 300) {
                message = 'الرجاء إدخال وزن صحيح بين 20 و 300 كجم';
                isValid = false;
            }
            else if (height < 100 || height > 250) {
                message = 'الرجاء إدخال طول صحيح بين 100 و 250 سم';
                isValid = false;
            }
            else if (age < 5 || age > 120) {
                message = 'الرجاء إدخال عمر صحيح بين 5 و 120 سنة';
                isValid = false;
            }

            if (!isValid) {
                e.preventDefault();
                // Create or update alert message
                let alert = document.querySelector('.alert');
                if (!alert) {
                    alert = document.createElement('div');
                    alert.className = 'alert alert-error';
                    bmrForm.insertBefore(alert, bmrForm.firstChild);
                }
                alert.textContent = message;
            }
        });
    }

    // BMI Calculator Validation
    const bmiForm = document.querySelector('form[action*="bmi"]');
    if (bmiForm) {
        bmiForm.addEventListener('submit', function(e) {
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value);
            let isValid = true;
            let message = '';

            if (weight < 20 || weight > 300) {
                message = 'الرجاء إدخال وزن صحيح بين 20 و 300 كجم';
                isValid = false;
            }
            else if (height < 100 || height > 250) {
                message = 'الرجاء إدخال طول صحيح بين 100 و 250 سم';
                isValid = false;
            }

            if (!isValid) {
                e.preventDefault();
                // Create or update alert message
                let alert = document.querySelector('.alert');
                if (!alert) {
                    alert = document.createElement('div');
                    alert.className = 'alert alert-error';
                    bmiForm.insertBefore(alert, bmiForm.firstChild);
                }
                alert.textContent = message;
            }
        });
    }
});
