// Main JavaScript for GymPro Arabic

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dark mode
    initDarkMode();
    
    // Initialize mobile navigation
    initMobileNavigation();
    
    // Initialize RTL support
    initRTLSupport();

    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Add smooth scrolling to all links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // BMI Calculator
    const bmiForm = document.getElementById('bmi-form');
    if (bmiForm) {
        bmiForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value) / 100; // Convert cm to m
            
            if (weight > 0 && height > 0) {
                const bmi = weight / (height * height);
                const resultElement = document.getElementById('bmi-result');
                
                let category = '';
                if (bmi < 18.5) {
                    category = 'نقص في الوزن';
                } else if (bmi < 25) {
                    category = 'وزن طبيعي';
                } else if (bmi < 30) {
                    category = 'زيادة في الوزن';
                } else if (bmi < 35) {
                    category = 'سمنة درجة أولى';
                } else if (bmi < 40) {
                    category = 'سمنة درجة ثانية';
                } else {
                    category = 'سمنة مفرطة';
                }
                
                resultElement.innerHTML = `
                    <h3>نتيجة حساب مؤشر كتلة الجسم</h3>
                    <p class="display-4 text-primary">${bmi.toFixed(2)}</p>
                    <p class="lead">التصنيف: <strong>${category}</strong></p>
                `;
                
                resultElement.classList.remove('d-none');
                resultElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    // TDEE Calculator
    const tdeeForm = document.getElementById('tdee-form');
    if (tdeeForm) {
        tdeeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value);
            const age = parseInt(document.getElementById('age').value);
            const gender = document.querySelector('input[name="gender"]:checked').value;
            const activity = document.getElementById('activity').value;
            
            if (weight > 0 && height > 0 && age > 0) {
                // Calculate BMR using Mifflin-St Jeor Equation
                let bmr;
                if (gender === 'male') {
                    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
                } else {
                    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
                }
                
                // Activity multipliers
                const activityMultipliers = {
                    'sedentary': 1.2,
                    'light': 1.375,
                    'moderate': 1.55,
                    'active': 1.725,
                    'very_active': 1.9
                };
                
                const tdee = bmr * activityMultipliers[activity];
                const resultElement = document.getElementById('tdee-result');
                
                // Calculate weight loss and gain calories
                const weightLossMild = tdee - 250;
                const weightLossModerate = tdee - 500;
                const weightGainMild = tdee + 250;
                const weightGainModerate = tdee + 500;
                
                resultElement.innerHTML = `
                    <h3>نتيجة حساب السعرات الحرارية اليومية</h3>
                    <p class="display-4 text-primary">${Math.round(tdee)}</p>
                    <p class="lead">هذا هو عدد السعرات الحرارية التي يحتاجها جسمك للحفاظ على وزنك الحالي.</p>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card mb-3">
                                <div class="card-header bg-danger text-white">
                                    <h5 class="mb-0">لفقدان الوزن</h5>
                                </div>
                                <div class="card-body">
                                    <p>فقدان وزن خفيف (0.25 كجم/أسبوع): <strong>${Math.round(weightLossMild)}</strong> سعرة حرارية</p>
                                    <p>فقدان وزن معتدل (0.5 كجم/أسبوع): <strong>${Math.round(weightLossModerate)}</strong> سعرة حرارية</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card mb-3">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0">لزيادة الوزن</h5>
                                </div>
                                <div class="card-body">
                                    <p>زيادة وزن خفيفة (0.25 كجم/أسبوع): <strong>${Math.round(weightGainMild)}</strong> سعرة حرارية</p>
                                    <p>زيادة وزن معتدلة (0.5 كجم/أسبوع): <strong>${Math.round(weightGainModerate)}</strong> سعرة حرارية</p>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                resultElement.classList.remove('d-none');
                resultElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    // BMR Calculator
    const bmrForm = document.getElementById('bmr-form');
    if (bmrForm) {
        bmrForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value);
            const age = parseInt(document.getElementById('age').value);
            const gender = document.querySelector('input[name="gender"]:checked').value;
            
            if (weight > 0 && height > 0 && age > 0) {
                // Calculate BMR using Mifflin-St Jeor Equation
                let bmr;
                if (gender === 'male') {
                    bmr = 10 * weight + 6.25 * height - 5 * age + 5;
                } else {
                    bmr = 10 * weight + 6.25 * height - 5 * age - 161;
                }
                
                const resultElement = document.getElementById('bmr-result');
                
                resultElement.innerHTML = `
                    <h3>نتيجة حساب معدل الأيض الأساسي</h3>
                    <p class="display-4 text-primary">${Math.round(bmr)}</p>
                    <p class="lead">هذا هو عدد السعرات الحرارية التي يحتاجها جسمك للحفاظ على وظائفه الأساسية في حالة الراحة التامة.</p>
                `;
                
                resultElement.classList.remove('d-none');
                resultElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    }

    // Weight Loss Plan Generator
    const weightLossPlanForm = document.getElementById('weight-loss-plan-form');
    if (weightLossPlanForm) {
        weightLossPlanForm.addEventListener('submit', function(e) {
            // Form is submitted normally to the server for processing
            // This is just for any client-side validation if needed
            const weight = parseFloat(document.getElementById('weight').value);
            const height = parseFloat(document.getElementById('height').value);
            const age = parseInt(document.getElementById('age').value);
            
            if (!(weight > 0 && height > 0 && age > 0)) {
                e.preventDefault();
                alert('يرجى إدخال قيم صحيحة للوزن والطول والعمر');
            }
        });
    }

    // Meal Generator
    const mealGeneratorForm = document.getElementById('meal-generator-form');
    if (mealGeneratorForm) {
        mealGeneratorForm.addEventListener('submit', function(e) {
            // Form is submitted normally to the server for processing
            // This is just for any client-side validation if needed
            const calories = parseInt(document.getElementById('calories').value);
            
            if (!(calories > 0)) {
                e.preventDefault();
                alert('يرجى إدخال قيمة صحيحة للسعرات الحرارية');
            }
        });
    }

    // Workout Plan Generator
    const workoutPlanForm = document.getElementById('workout-plan-form');
    if (workoutPlanForm) {
        workoutPlanForm.addEventListener('submit', function(e) {
            // Form is submitted normally to the server for processing
            // This is just for any client-side validation if needed
        });
    }

    // Contact Form Validation
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();
            
            if (!name || !email || !message) {
                e.preventDefault();
                alert('يرجى ملء جميع الحقول المطلوبة');
            }
        });
    }

    // Add animation to elements when they come into view
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.animate-on-scroll');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const windowHeight = window.innerHeight;
            
            if (elementPosition < windowHeight - 50) {
                element.classList.add('fade-in');
                element.classList.remove('animate-on-scroll');
            }
        });
    };
    
    // Run animation check on scroll
    window.addEventListener('scroll', animateOnScroll);
    
    // Run animation check on page load
    animateOnScroll();
});

/**
 * Initialize dark mode functionality
 */
function initDarkMode() {
    // Create dark mode toggle button if it doesn't exist
    if (!document.querySelector('.dark-mode-toggle')) {
        const darkModeToggle = document.createElement('button');
        darkModeToggle.className = 'dark-mode-toggle';
        darkModeToggle.setAttribute('aria-label', 'تبديل الوضع المظلم');
        darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        document.body.appendChild(darkModeToggle);
    }

    const darkModeToggle = document.querySelector('.dark-mode-toggle');
    const prefersDarkScheme = window.matchMedia('(prefers-color-scheme: dark)');
    
    // Check for saved theme preference or use the system preference
    const currentTheme = localStorage.getItem('theme');
    
    // If the user has explicitly chosen a theme, use it
    if (currentTheme) {
        document.body.classList.toggle('dark-mode', currentTheme === 'dark');
        updateDarkModeIcon();
    } else {
        // Otherwise, use the system preference
        if (prefersDarkScheme.matches) {
            document.body.classList.add('dark-mode');
            updateDarkModeIcon();
        }
    }

    // Add event listener to the dark mode toggle
    if (darkModeToggle) {
        darkModeToggle.addEventListener('click', function() {
            document.body.classList.toggle('dark-mode');
            updateDarkModeIcon();
            
            // Save the preference to localStorage
            if (document.body.classList.contains('dark-mode')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        });
    }

    // Function to update the dark mode toggle icon
    function updateDarkModeIcon() {
        if (darkModeToggle) {
            if (document.body.classList.contains('dark-mode')) {
                darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
            } else {
                darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>';
            }
        }
    }

    // Listen for changes in the system color scheme preference
    prefersDarkScheme.addEventListener('change', e => {
        // Only apply if the user hasn't set a preference
        if (!localStorage.getItem('theme')) {
            if (e.matches) {
                document.body.classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
            }
            updateDarkModeIcon();
        }
    });
}

/**
 * Initialize mobile navigation
 */
function initMobileNavigation() {
    // Use Bootstrap's built-in collapse functionality for mobile navigation
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    // Close mobile menu when clicking on nav links (on mobile)
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth <= 992 && navbarCollapse.classList.contains('show')) {
                // Use Bootstrap's collapse API to hide the menu
                const bsCollapse = new bootstrap.Collapse(navbarCollapse);
                bsCollapse.hide();
            }
        });
    });
    
    // Add event listener to collapse navbar when shown
    if (navbarCollapse) {
        navbarCollapse.addEventListener('show.bs.collapse', function() {
            document.body.classList.add('js-navbar-mobile-open');
        });
        
        navbarCollapse.addEventListener('hide.bs.collapse', function() {
            document.body.classList.remove('js-navbar-mobile-open');
        });
    }
}

/**
 * Initialize RTL support
 */
function initRTLSupport() {
    // Set RTL direction on the HTML element
    document.documentElement.setAttribute('dir', 'rtl');
    
    // Add a class to identify RTL layout
    document.body.classList.add('rtl');
    
    // Handle any dynamic RTL adjustments if needed
    const isRTL = document.documentElement.getAttribute('dir') === 'rtl';
    
    // Apply RTL specific adjustments if needed
    if (isRTL) {
        // Any specific RTL adjustments can be added here
        const dropdowns = document.querySelectorAll('.dropdown-menu');
        dropdowns.forEach(dropdown => {
            dropdown.classList.add('dropdown-menu-end');
        });
    }
}

/**
 * Initialize lazy loading for images
 */
function initLazyLoading() {
    const lazyImages = document.querySelectorAll('.lazy-load');
    
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const image = entry.target;
                    const src = image.getAttribute('data-src');
                    
                    if (src) {
                        image.src = src;
                        image.classList.add('loaded');
                        observer.unobserve(image);
                    }
                }
            });
        });
        
        lazyImages.forEach(image => {
            imageObserver.observe(image);
        });
    } else {
        // Fallback for browsers that don't support IntersectionObserver
        lazyImages.forEach(image => {
            const src = image.getAttribute('data-src');
            if (src) {
                image.src = src;
                image.classList.add('loaded');
            }
        });
    }
}

// Call the lazy loading initialization once the page is loaded
window.addEventListener('load', initLazyLoading);