/**
 * Interactive Fitness Calculators in Arabic
 * 
 * This script provides functionality for:
 * 1. BMI Calculator (حاسبة مؤشر كتلة الجسم)
 * 2. TDEE Calculator (حاسبة السعرات الحرارية اليومية)
 * 3. Ideal Weight Calculator (حاسبة الوزن المثالي)
 * 4. Fat Burning Calculator (حاسبة السعرات الحرارية لحرق الدهون)
 */

document.addEventListener('DOMContentLoaded', function() {
    // ======================================================
    // BMI Calculator (حاسبة مؤشر كتلة الجسم)
    // ======================================================
    const bmiForm = document.getElementById('bmiForm');
    const bmiResult = document.getElementById('bmiResult');
    const bmiValue = document.getElementById('bmiValue');
    const bmiCategory = document.getElementById('bmiCategory');
    const bmiMarker = document.getElementById('bmiMarker');
    const bmiExplanation = document.getElementById('bmiExplanation');
    
    if (bmiForm) {
        bmiForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // الحصول على قيم الوزن والطول
            const weight = parseFloat(document.getElementById('bmiWeight').value);
            const height = parseFloat(document.getElementById('bmiHeight').value) / 100; // تحويل السنتيمتر إلى متر
            
            // التحقق من صحة البيانات المدخلة
            if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
                alert('الرجاء إدخال قيم صحيحة للوزن والطول');
                return;
            }
            
            // حساب مؤشر كتلة الجسم: الوزن (كجم) / (الطول (م) * الطول (م))
            const bmi = weight / (height * height);
            const roundedBmi = Math.round(bmi * 10) / 10; // تقريب الناتج لرقم عشري واحد
            
            // تحديد الفئة بناءً على قيمة مؤشر كتلة الجسم
            let category, categoryClass, explanation;
            
            if (bmi < 18.5) {
                category = 'نقص في الوزن';
                categoryClass = 'category-underweight';
                explanation = 'مؤشر كتلة الجسم لديك أقل من المعدل الطبيعي. قد تحتاج إلى زيادة وزنك بطريقة صحية من خلال نظام غذائي متوازن وغني بالسعرات الحرارية.';
            } else if (bmi >= 18.5 && bmi < 25) {
                category = 'وزن طبيعي';
                categoryClass = 'category-normal';
                explanation = 'مؤشر كتلة الجسم لديك ضمن المعدل الطبيعي. حافظ على وزنك الحالي من خلال نظام غذائي متوازن ونشاط بدني منتظم.';
            } else if (bmi >= 25 && bmi < 30) {
                category = 'زيادة في الوزن';
                categoryClass = 'category-overweight';
                explanation = 'مؤشر كتلة الجسم لديك يشير إلى زيادة في الوزن. يُنصح بتقليل السعرات الحرارية وزيادة النشاط البدني للوصول إلى الوزن المثالي.';
            } else {
                category = 'سمنة';
                categoryClass = 'category-obese';
                explanation = 'مؤشر كتلة الجسم لديك يشير إلى السمنة. يُنصح باستشارة أخصائي تغذية أو طبيب لوضع خطة لإنقاص الوزن بطريقة صحية وآمنة.';
            }
            
            // تحديد موضع المؤشر على مقياس مؤشر كتلة الجسم (النسبة المئوية من العرض)
            const markerPosition = Math.min(Math.max((bmi / 40) * 100, 0), 100);
            
            // عرض النتائج
            bmiValue.textContent = roundedBmi;
            bmiCategory.textContent = category;
            bmiCategory.className = 'result-category ' + categoryClass;
            bmiMarker.style.left = markerPosition + '%';
            bmiExplanation.innerHTML = `<p>${explanation}</p>`;
            
            // إظهار قسم النتائج
            bmiResult.style.display = 'block';
            
            // التمرير إلى النتائج
            bmiResult.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
    
    // ======================================================
    // TDEE Calculator (حاسبة السعرات الحرارية اليومية)
    // ======================================================
    const tdeeForm = document.getElementById('tdeeForm');
    const tdeeResult = document.getElementById('tdeeResult');
    const bmrValue = document.getElementById('bmrValue');
    const tdeeValue = document.getElementById('tdeeValue');
    const maintainValue = document.getElementById('maintainValue');
    const loseValue = document.getElementById('loseValue');
    
    if (tdeeForm) {
        tdeeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // الحصول على القيم المدخلة
            const weight = parseFloat(document.getElementById('tdeeWeight').value);
            const height = parseFloat(document.getElementById('tdeeHeight').value);
            const age = parseInt(document.getElementById('tdeeAge').value);
            const gender = document.querySelector('input[name="tdeeGender"]:checked').value;
            const activity = document.getElementById('tdeeActivity').value;
            
            // التحقق من صحة البيانات المدخلة
            if (isNaN(weight) || weight <= 0 || isNaN(height) || height <= 0 || isNaN(age) || age <= 0) {
                alert('الرجاء إدخال قيم صحيحة للوزن والطول والعمر');
                return;
            }
            
            // طباعة القيم للتشخيص
            console.log('TDEE Calculator Values:', { weight, height, age, gender, activity });
            
            // حساب معدل الأيض الأساسي (BMR) باستخدام معادلة Mifflin-St Jeor
            let bmr;
            if (gender === 'male') {
                bmr = 10 * weight + 6.25 * height - 5 * age + 5;
            } else {
                bmr = 10 * weight + 6.25 * height - 5 * age - 161;
            }
            
            // معاملات النشاط لحساب إجمالي السعرات الحرارية اليومية (TDEE)
            const activityMultipliers = {
                'sedentary': 1.2,      // قليل الحركة
                'light': 1.375,        // نشاط خفيف
                'moderate': 1.55,      // نشاط متوسط
                'active': 1.725,       // نشاط عالي
                'very_active': 1.9     // نشاط مكثف
            };
            
            // حساب إجمالي السعرات الحرارية اليومية (TDEE)
            const tdee = bmr * activityMultipliers[activity];
            
            // تقريب النتائج إلى أعداد صحيحة
            const roundedBmr = Math.round(bmr);
            const roundedTdee = Math.round(tdee);
            
            // حساب السعرات للمحافظة على الوزن وخسارة الوزن
            const maintain = roundedTdee;
            const lose = Math.round(tdee - 500); // نقص 500 سعرة لخسارة حوالي 0.5 كجم أسبوعياً
            
            // طباعة النتائج للتشخيص
            console.log('TDEE Results:', { bmr: roundedBmr, tdee: roundedTdee, maintain, lose });
            
            // عرض النتائج
            bmrValue.textContent = roundedBmr;
            tdeeValue.textContent = roundedTdee;
            maintainValue.textContent = maintain;
            loseValue.textContent = lose;
            
            // إظهار قسم النتائج
            tdeeResult.style.display = 'block';
            
            // التمرير إلى النتائج
            tdeeResult.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // إضافة مؤثرات بسيطة لجذب الانتباه للنتائج
            setTimeout(() => {
                document.querySelectorAll('#tdeeResult .result-value').forEach(el => {
                    el.style.transition = 'transform 0.3s ease-in-out';
                    el.style.transform = 'scale(1.1)';
                    setTimeout(() => {
                        el.style.transform = 'scale(1)';
                    }, 300);
                });
            }, 300);
        });
    }
    
    // ======================================================
    // Ideal Weight Calculator (حاسبة الوزن المثالي)
    // ======================================================
    const idealWeightForm = document.getElementById('idealWeightForm');
    const idealWeightResult = document.getElementById('idealWeightResult');
    const idealWeightValue = document.getElementById('idealWeightValue');
    const idealWeightMin = document.getElementById('idealWeightMin');
    const idealWeightMax = document.getElementById('idealWeightMax');
    
    if (idealWeightForm) {
        idealWeightForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // الحصول على القيم المدخلة
            const height = parseFloat(document.getElementById('idealHeight').value);
            const gender = document.querySelector('input[name="idealGender"]:checked').value;
            
            // التحقق من صحة البيانات المدخلة
            if (isNaN(height) || height <= 0) {
                alert('الرجاء إدخال قيمة صحيحة للطول');
                return;
            }
            
            // حساب الوزن المثالي باستخدام معادلة Devine
            let idealWeight;
            if (gender === 'male') {
                // للرجال: 50 + 2.3 × (الطول بالإنش - 60)
                const heightInInches = height / 2.54;
                idealWeight = 50 + 2.3 * (heightInInches - 60);
            } else {
                // للنساء: 45.5 + 2.3 × (الطول بالإنش - 60)
                const heightInInches = height / 2.54;
                idealWeight = 45.5 + 2.3 * (heightInInches - 60);
            }
            
            // حساب النطاق المثالي (±10%)
            const minWeight = idealWeight * 0.9;
            const maxWeight = idealWeight * 1.1;
            
            // تقريب النتائج
            const roundedIdealWeight = Math.round(idealWeight);
            const roundedMinWeight = Math.round(minWeight);
            const roundedMaxWeight = Math.round(maxWeight);
            
            // عرض النتائج
            idealWeightValue.textContent = roundedIdealWeight;
            idealWeightMin.textContent = roundedMinWeight;
            idealWeightMax.textContent = roundedMaxWeight;
            
            // إظهار قسم النتائج
            idealWeightResult.style.display = 'block';
            
            // التمرير إلى النتائج
            idealWeightResult.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
    
    // ======================================================
    // Fat Burning Calculator (حاسبة السعرات الحرارية لحرق الدهون)
    // ======================================================
    const fatBurningForm = document.getElementById('fatBurningForm');
    const fatBurningResult = document.getElementById('fatBurningResult');
    const caloriesBurnedValue = document.getElementById('caloriesBurnedValue');
    const hourlyBurnRate = document.getElementById('hourlyBurnRate');
    const fatEquivalent = document.getElementById('fatEquivalent');
    const burningExplanation = document.getElementById('burningExplanation');
    
    if (fatBurningForm) {
        fatBurningForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // الحصول على القيم المدخلة
            const weight = parseFloat(document.getElementById('burningWeight').value);
            const activity = document.getElementById('burningActivity').value;
            const duration = parseInt(document.getElementById('burningDuration').value);
            const intensity = document.getElementById('burningIntensity').value;
            
            // التحقق من صحة البيانات المدخلة
            if (isNaN(weight) || !activity || isNaN(duration) || !intensity) {
                alert('الرجاء إدخال جميع البيانات المطلوبة بشكل صحيح');
                return;
            }
            
            // معدلات حرق السعرات لكل نشاط (سعرة/كجم/ساعة) حسب الشدة
            const burnRates = {
                'walking': { 'low': 3, 'moderate': 4.5, 'high': 6 },
                'jogging': { 'low': 7, 'moderate': 9, 'high': 11 },
                'running': { 'low': 10, 'moderate': 13, 'high': 16 },
                'cycling': { 'low': 4, 'moderate': 7, 'high': 10 },
                'swimming': { 'low': 6, 'moderate': 8, 'high': 10 },
                'weight_training': { 'low': 3, 'moderate': 5, 'high': 7 },
                'hiit': { 'low': 8, 'moderate': 12, 'high': 16 },
                'yoga': { 'low': 2, 'moderate': 3, 'high': 4 },
                'aerobics': { 'low': 5, 'moderate': 7, 'high': 9 }
            };
            
            // أسماء الأنشطة بالعربية للعرض
            const activityNames = {
                'walking': 'المشي العادي',
                'jogging': 'الجري الخفيف',
                'running': 'الجري السريع',
                'cycling': 'ركوب الدراجة',
                'swimming': 'السباحة',
                'weight_training': 'تمارين الأثقال',
                'hiit': 'تمارين عالية الكثافة (HIIT)',
                'yoga': 'اليوجا',
                'aerobics': 'تمارين هوائية'
            };
            
            // حساب السعرات المحروقة
            const hourlyRate = burnRates[activity][intensity] * weight;
            const caloriesBurned = hourlyRate * (duration / 60);
            
            // تقريب النتائج
            const roundedCaloriesBurned = Math.round(caloriesBurned);
            const roundedHourlyRate = Math.round(hourlyRate);
            
            // حساب ما يعادل من الدهون (1 جرام دهون = 9 سعرات حرارية)
            const fatGrams = caloriesBurned / 9;
            const roundedFatGrams = Math.round(fatGrams * 10) / 10;
            
            // إعداد الشرح
            let explanation = `<p>خلال ${duration} دقيقة من ${activityNames[activity]} بشدة `;
            
            if (intensity === 'low') {
                explanation += 'منخفضة';
            } else if (intensity === 'moderate') {
                explanation += 'متوسطة';
            } else {
                explanation += 'عالية';
            }
            
            explanation += `، يمكنك حرق حوالي ${roundedCaloriesBurned} سعرة حرارية.</p>`;
            explanation += `<p>هذا يعادل حرق حوالي ${roundedFatGrams} جرام من الدهون.</p>`;
            explanation += `<p>للحصول على أفضل النتائج، يُنصح بممارسة هذا النشاط بانتظام مع اتباع نظام غذائي متوازن.</p>`;
            
            // عرض النتائج
            caloriesBurnedValue.textContent = roundedCaloriesBurned;
            hourlyBurnRate.textContent = roundedHourlyRate;
            fatEquivalent.textContent = roundedFatGrams;
            burningExplanation.innerHTML = explanation;
            
            // إظهار قسم النتائج
            fatBurningResult.style.display = 'block';
            
            // التمرير إلى النتائج
            fatBurningResult.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }
    
    // ======================================================
    // Input Validation (التحقق من صحة البيانات المدخلة)
    // ======================================================
    
    // التحقق من إدخال أرقام فقط في حقول الإدخال الرقمية
    const numericInputs = document.querySelectorAll('input[type="number"]');
    
    numericInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            // إزالة أي أحرف غير رقمية
            this.value = this.value.replace(/[^0-9.]/g, '');
            
            // التأكد من عدم وجود أكثر من نقطة عشرية واحدة
            if (this.value.split('.').length > 2) {
                this.value = this.value.slice(0, this.value.lastIndexOf('.'));
            }
        });
    });
});
