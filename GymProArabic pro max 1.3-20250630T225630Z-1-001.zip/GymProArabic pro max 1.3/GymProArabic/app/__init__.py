from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_wtf.csrf import CSRFProtect, CSRFError
import os
from dotenv import load_dotenv
from datetime import datetime, timedelta

# Load environment variables
load_dotenv()

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
migrate = Migrate()
csrf = CSRFProtect()

def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__, template_folder='templates')
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default-gym-pro-arabic-key')
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///gym_pro.db')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Enhanced Security Configuration
    app.config['SESSION_COOKIE_SECURE'] = False  # Set to True in production with HTTPS
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=60)
    app.config['WTF_CSRF_ENABLED'] = True
    app.config['WTF_CSRF_SECRET_KEY'] = os.environ.get('WTF_CSRF_SECRET_KEY', 'csrf-key-for-gymproarabic')
    app.config['WTF_CSRF_TIME_LIMIT'] = 3600
    app.config['WTF_CSRF_SSL_STRICT'] = False  # Set to True in production
    app.config['WTF_CSRF_CHECK_DEFAULT'] = True
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)
    csrf.init_app(app)
    
    @app.context_processor
    def inject_now():
        return {'now': datetime.utcnow()}
    
    @app.before_request
    def before_request():
        """تنفيذ قبل كل طلب للتأكد من سلامة الجلسة."""
        if not request.is_secure and not app.debug:  # تحقق مما إذا كان التطبيق في وضع الإنتاج
            url = request.url.replace('http://', 'https://', 1)
            return redirect(url)

    # Login manager configuration
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'يرجى تسجيل الدخول للوصول إلى هذه الصفحة'
    login_manager.login_message_category = 'info'
    
    # CSRF error handler with detailed logging
    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):
        app.logger.warning(f'CSRF Error: {e.description} | URL: {request.url} | Method: {request.method}')
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'error': 'CSRF validation failed',
                'message': 'يرجى تحديث الصفحة والمحاولة مرة أخرى',
                'code': 400
            }), 400
        return render_template('csrf_error.html',
                            reason=e.description,
                            title='خطأ في تأمين النموذج | GymPro Arabic'), 400

    # Setup user loader function
    from app.models.user import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Register blueprints
    with app.app_context():
        from app.main import main_bp
        from app.auth import auth_bp
        from app.admin import admin_bp
        from app.calculators import calculators_bp
        from app.diet import diet_bp
        from app.workout import workout_bp
        from app.supplements import supplements_bp
        from app.tips import tips_bp
        from app.tutorials import tutorials_bp
        
        app.register_blueprint(main_bp)
        app.register_blueprint(auth_bp, url_prefix='/auth')
        app.register_blueprint(admin_bp, url_prefix='/admin')
        app.register_blueprint(calculators_bp, url_prefix='/calculators')
        app.register_blueprint(diet_bp, url_prefix='/diet')
        app.register_blueprint(workout_bp, url_prefix='/workout')
        app.register_blueprint(supplements_bp, url_prefix='/supplements')
        app.register_blueprint(tips_bp, url_prefix='/tips')
        app.register_blueprint(tutorials_bp, url_prefix='/tutorials')
        
        # Create database tables
        db.create_all()
        
        # Register error handlers
        @app.errorhandler(404)
        def page_not_found(e):
            """Handle 404 errors with a custom page"""
            return render_template('errors/404.html', now=datetime.now()), 404
        
        return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
