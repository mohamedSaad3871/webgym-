from app import create_app
from app.models.user import User

app = create_app()

with app.app_context():
    users = User.query.all()
    print("List of users in the system:")
    print("-" * 40)
    for user in users:
        print(f"ID: {user.id}")
        print(f"Username: {user.username}")
        print(f"Email: {user.email}")
        print(f"Admin: {'Yes' if user.is_admin else 'No'}")
        print("-" * 40)
    
    if not users:
        print("No users found in the database!")
